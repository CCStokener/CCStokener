
class Java_168{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/245.java, start: 199, end: 219 */
protected void mergeModelBase_Properties(ModelBase target,
                                         ModelBase source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    Properties merged = new Properties();
    if (sourceDominant) {
        merged.putAll(target.getProperties());
        putAll(merged, source.getProperties(),
               CHILD_DIRECTORY_PROPERTY);
    } else {
        putAll(merged, source.getProperties(),
               CHILD_DIRECTORY_PROPERTY);
        merged.putAll(target.getProperties());
    }
    target.setProperties(merged);
    target.setLocation(
        "properties",
        InputLocation.merge(target.getLocation("properties"),
                            source.getLocation("properties"),
                            sourceDominant));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1760, end: 1777 */
protected void mergeContributor_Properties(Contributor target,
                                           Contributor source,
                                           boolean sourceDominant,
                                           Map<Object, Object> context) {
    Properties merged = new Properties();
    if (sourceDominant) {
        merged.putAll(target.getProperties());
        merged.putAll(source.getProperties());
    } else {
        merged.putAll(source.getProperties());
        merged.putAll(target.getProperties());
    }
    target.setProperties(merged);
    target.setLocation("properties",
                       InputLocation.merge(target.getLocation("properties"),
                                           source.getLocation("properties"),
                                           sourceDominant));
}

}
    