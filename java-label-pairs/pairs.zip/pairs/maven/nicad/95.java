
class Java_95{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 322, end: 345 */
protected void mergeModel_MailingLists(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    List<MailingList> src = source.getMailingLists();
    if (!src.isEmpty()) {
        List<MailingList> tgt = target.getMailingLists();
        Map<Object, MailingList> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (MailingList element : tgt) {
            Object key = getMailingListKey(element);
            merged.put(key, element);
        }

        for (MailingList element : src) {
            Object key = getMailingListKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setMailingLists(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 575, end: 599 */
protected void
mergeModelBase_PluginRepositories(ModelBase target, ModelBase source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    List<Repository> src = source.getPluginRepositories();
    if (!src.isEmpty()) {
        List<Repository> tgt = target.getPluginRepositories();
        Map<Object, Repository> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Repository element : tgt) {
            Object key = getRepositoryKey(element);
            merged.put(key, element);
        }

        for (Repository element : src) {
            Object key = getRepositoryKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setPluginRepositories(new ArrayList<>(merged.values()));
    }
}

}
    