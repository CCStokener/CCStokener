
class Java_43{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1621, end: 1633 */
protected void mergeMailingList_OtherArchives(MailingList target,
                                              MailingList source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    List<String> src = source.getOtherArchives();
    if (!src.isEmpty()) {
        List<String> tgt = target.getOtherArchives();
        List<String> merged = new ArrayList<>(tgt.size() + src.size());
        merged.addAll(tgt);
        merged.addAll(src);
        target.setOtherArchives(merged);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2230, end: 2241 */
protected void mergeBuildBase_Filters(BuildBase target, BuildBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<String> src = source.getFilters();
    if (!src.isEmpty()) {
        List<String> tgt = target.getFilters();
        List<String> merged = new ArrayList<>(tgt.size() + src.size());
        merged.addAll(tgt);
        merged.addAll(src);
        target.setFilters(merged);
    }
}

}
    