
class Java_187{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 347, end: 370 */
protected void mergeModel_Developers(Model target, Model source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Developer> src = source.getDevelopers();
    if (!src.isEmpty()) {
        List<Developer> tgt = target.getDevelopers();
        Map<Object, Developer> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Developer element : tgt) {
            Object key = getDeveloperKey(element);
            merged.put(key, element);
        }

        for (Developer element : src) {
            Object key = getDeveloperKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setDevelopers(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2108, end: 2131 */
protected void mergeBuild_Extensions(Build target, Build source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Extension> src = source.getExtensions();
    if (!src.isEmpty()) {
        List<Extension> tgt = target.getExtensions();
        Map<Object, Extension> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Extension element : tgt) {
            Object key = getExtensionKey(element);
            merged.put(key, element);
        }

        for (Extension element : src) {
            Object key = getExtensionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExtensions(new ArrayList<>(merged.values()));
    }
}

}
    