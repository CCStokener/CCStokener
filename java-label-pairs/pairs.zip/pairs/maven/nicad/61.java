
class Java_61{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/730.java, start: 839, end: 851 */
public boolean equals(Object other) {
    if (other == this) {
        return true;
    } else if (!(other instanceof MavenProject)) {
        return false;
    }

    MavenProject that = (MavenProject)other;

    return eq(getArtifactId(), that.getArtifactId()) &&
        eq(getGroupId(), that.getGroupId()) &&
        eq(getVersion(), that.getVersion());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/146.java, start: 43, end: 55 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof InversionArtifactFilter)) {
        return false;
    }

    InversionArtifactFilter other = (InversionArtifactFilter)obj;

    return toInvert.equals(other.toInvert);
}

}
    