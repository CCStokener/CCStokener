
class Java_175{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 616, end: 628 */
protected void mergeModelBase_Reporting(ModelBase target, ModelBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    Reporting src = source.getReporting();
    if (src != null) {
        Reporting tgt = target.getReporting();
        if (tgt == null) {
            tgt = new Reporting();
            target.setReporting(tgt);
        }
        mergeReporting(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 875, end: 888 */
protected void mergeRepository_Releases(Repository target,
                                        Repository source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    RepositoryPolicy src = source.getReleases();
    if (src != null) {
        RepositoryPolicy tgt = target.getReleases();
        if (tgt == null) {
            tgt = new RepositoryPolicy();
            target.setReleases(tgt);
        }
        mergeRepositoryPolicy(tgt, src, sourceDominant, context);
    }
}

}
    