
class Java_161{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/902.java, start: 273, end: 287 */
public void forkStarted(ExecutionEvent event) {
    if (logger.isInfoEnabled()) {
        logger.info("");

        MessageBuilder buffer = buffer().strong(">>> ");
        append(buffer, event.getMojoExecution());
        buffer.strong(" > ");
        appendForkInfo(buffer,
                       event.getMojoExecution().getMojoDescriptor());
        append(buffer, event.getProject());
        buffer.strong(" >>>");

        logger.info(buffer.toString());
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/902.java, start: 298, end: 314 */
public void forkSucceeded(ExecutionEvent event) {
    if (logger.isInfoEnabled()) {
        logger.info("");

        MessageBuilder buffer = buffer().strong("<<< ");
        append(buffer, event.getMojoExecution());
        buffer.strong(" < ");
        appendForkInfo(buffer,
                       event.getMojoExecution().getMojoDescriptor());
        append(buffer, event.getProject());
        buffer.strong(" <<<");

        logger.info(buffer.toString());

        logger.info("");
    }
}

}
    