
class Java_114{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 333, end: 349 */
protected void mergeBuildBase_Filters(BuildBase target, BuildBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<String> src = source.getFilters();
    if (!src.isEmpty()) {
        List<String> tgt = target.getFilters();
        Set<String> excludes = new LinkedHashSet<>(tgt);
        List<String> merged = new ArrayList<>(tgt.size() + src.size());
        merged.addAll(tgt);
        for (String s : src) {
            if (!excludes.contains(s)) {
                merged.add(s);
            }
        }
        target.setFilters(merged);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1621, end: 1633 */
protected void mergeMailingList_OtherArchives(MailingList target,
                                              MailingList source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    List<String> src = source.getOtherArchives();
    if (!src.isEmpty()) {
        List<String> tgt = target.getOtherArchives();
        List<String> merged = new ArrayList<>(tgt.size() + src.size());
        merged.addAll(tgt);
        merged.addAll(src);
        target.setOtherArchives(merged);
    }
}

}
    