
class Java_183{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 150, end: 166 */
public void
testResolveDependencyThrowsUnresolvableModelExceptionWhenNoMatchingVersionFound()
    throws Exception {
    final Dependency dependency = new Dependency();
    dependency.setGroupId("org.apache");
    dependency.setArtifactId("apache");
    dependency.setVersion("[2.0,2.1)");

    try {
        this.newModelResolver().resolveModel(dependency);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "No versions matched the requested dependency version range '[2.0,2.1)'",
            e.getMessage());
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/477.java, start: 46, end: 61 */
public void testResolveParentThrowsUnresolvableModelExceptionWhenNotFound()
    throws Exception {
    final Parent parent = new Parent();
    parent.setGroupId("ut.simple");
    parent.setArtifactId("artifact");
    parent.setVersion("0");

    try {
        this.newModelResolver().resolveModel(parent);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertNotNull(e.getMessage());
        assertTrue(e.getMessage().startsWith(
            "Could not find artifact ut.simple:artifact:pom:0 in repo"));
    }
}

}
    