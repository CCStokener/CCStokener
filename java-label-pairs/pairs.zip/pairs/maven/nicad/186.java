
class Java_186{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 659, end: 685 */
public void testOrderOfMergedPluginDependenciesWithPluginManagement()
    throws Exception {
    PomTestWrapper pom =
        buildPom("merged-plugin-class-path-order/w-plugin-mgmt/sub");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/dependencies")).size());
    assertEquals(
        "c", pom.getValue("build/plugins[1]/dependencies[1]/artifactId"));
    assertEquals("1",
                 pom.getValue("build/plugins[1]/dependencies[1]/version"));
    assertEquals(
        "a", pom.getValue("build/plugins[1]/dependencies[2]/artifactId"));
    assertEquals("2",
                 pom.getValue("build/plugins[1]/dependencies[2]/version"));
    assertEquals(
        "b", pom.getValue("build/plugins[1]/dependencies[3]/artifactId"));
    assertEquals("1",
                 pom.getValue("build/plugins[1]/dependencies[3]/version"));
    assertEquals(
        "e", pom.getValue("build/plugins[1]/dependencies[4]/artifactId"));
    assertEquals("1",
                 pom.getValue("build/plugins[1]/dependencies[4]/version"));
    assertEquals(
        "d", pom.getValue("build/plugins[1]/dependencies[5]/artifactId"));
    assertEquals("1",
                 pom.getValue("build/plugins[1]/dependencies[5]/version"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 723, end: 748 */
public void testAppendArtifactIdOfParentAndChildToInheritedUrls()
    throws Exception {
    PomTestWrapper pom = buildPom("url-inheritance/another-parent/sub");
    assertEquals("http://parent.url/ap/child", pom.getValue("url"));
    assertEquals("http://parent.url/org", pom.getValue("organization/url"));
    assertEquals("http://parent.url/license.txt",
                 pom.getValue("licenses[1]/url"));
    assertEquals("http://parent.url/viewvc/ap/child",
                 pom.getValue("scm/url"));
    assertEquals("http://parent.url/scm/ap/child",
                 pom.getValue("scm/connection"));
    assertEquals("https://parent.url/scm/ap/child",
                 pom.getValue("scm/developerConnection"));
    assertEquals("http://parent.url/issues",
                 pom.getValue("issueManagement/url"));
    assertEquals("http://parent.url/ci", pom.getValue("ciManagement/url"));
    assertEquals("http://parent.url/dist",
                 pom.getValue("distributionManagement/repository/url"));
    assertEquals(
        "http://parent.url/snaps",
        pom.getValue("distributionManagement/snapshotRepository/url"));
    assertEquals("http://parent.url/site/ap/child",
                 pom.getValue("distributionManagement/site/url"));
    assertEquals("http://parent.url/download",
                 pom.getValue("distributionManagement/downloadUrl"));
}

}
    