
class Java_34{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/597.java, start: 78, end: 87 */
public boolean equals(Object obj) {
    if (obj == this) {
        return true;
    } else if (obj == null || !getClass().equals(obj.getClass())) {
        return false;
    }

    WagonExcluder that = (WagonExcluder)obj;
    return coreArtifact == that.coreArtifact;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/148.java, start: 65, end: 77 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof OrArtifactFilter)) {
        return false;
    }

    OrArtifactFilter other = (OrArtifactFilter)obj;

    return filters.equals(other.filters);
}

}
    