
class Java_28{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 601, end: 614 */
protected void
mergeModelBase_DistributionManagement(ModelBase target, ModelBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    DistributionManagement src = source.getDistributionManagement();
    if (src != null) {
        DistributionManagement tgt = target.getDistributionManagement();
        if (tgt == null) {
            tgt = new DistributionManagement();
            target.setDistributionManagement(tgt);
        }
        mergeDistributionManagement(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2303, end: 2315 */
protected void mergePluginConfiguration_PluginManagement(
    PluginConfiguration target, PluginConfiguration source,
    boolean sourceDominant, Map<Object, Object> context) {
    PluginManagement src = source.getPluginManagement();
    if (src != null) {
        PluginManagement tgt = target.getPluginManagement();
        if (tgt == null) {
            tgt = new PluginManagement();
            target.setPluginManagement(tgt);
        }
        mergePluginManagement(tgt, src, sourceDominant, context);
    }
}

}
    