
class Java_33{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/790.java, start: 66, end: 79 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    // make sure IncludesArtifactFilter is not equal ExcludesArtifactFilter!
    if (obj == null || getClass() != obj.getClass()) {
        return false;
    }

    IncludesArtifactFilter other = (IncludesArtifactFilter)obj;

    return patterns.equals(other.patterns);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/147.java, start: 42, end: 54 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof TypeArtifactFilter)) {
        return false;
    }

    TypeArtifactFilter other = (TypeArtifactFilter)obj;

    return type.equals(other.type);
}

}
    