
class Java_169{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/786.java, start: 96, end: 108 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CumulativeScopeArtifactFilter)) {
        return false;
    }

    CumulativeScopeArtifactFilter that = (CumulativeScopeArtifactFilter)obj;

    return scopes.equals(that.scopes);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/785.java, start: 71, end: 83 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof AndArtifactFilter)) {
        return false;
    }

    AndArtifactFilter other = (AndArtifactFilter)obj;

    return filters.equals(other.filters);
}

}
    