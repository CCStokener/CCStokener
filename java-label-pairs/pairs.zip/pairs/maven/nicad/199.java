
class Java_199{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/730.java, start: 1379, end: 1401 */
public List<Dependency> getTestDependencies() {
    Set<Artifact> artifacts = getArtifacts();

    if ((artifacts == null) || artifacts.isEmpty()) {
        return Collections.emptyList();
    }

    List<Dependency> list = new ArrayList<>(artifacts.size());

    for (Artifact a : getArtifacts()) {
        Dependency dependency = new Dependency();

        dependency.setArtifactId(a.getArtifactId());
        dependency.setGroupId(a.getGroupId());
        dependency.setVersion(a.getVersion());
        dependency.setScope(a.getScope());
        dependency.setType(a.getType());
        dependency.setClassifier(a.getClassifier());

        list.add(dependency);
    }
    return list;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/730.java, start: 1488, end: 1513 */
public List<Dependency> getSystemDependencies() {
    Set<Artifact> artifacts = getArtifacts();

    if ((artifacts == null) || artifacts.isEmpty()) {
        return Collections.emptyList();
    }

    List<Dependency> list = new ArrayList<>(artifacts.size());

    for (Artifact a : getArtifacts()) {
        // TODO let the scope handler deal with this
        if (Artifact.SCOPE_SYSTEM.equals(a.getScope())) {
            Dependency dependency = new Dependency();

            dependency.setArtifactId(a.getArtifactId());
            dependency.setGroupId(a.getGroupId());
            dependency.setVersion(a.getVersion());
            dependency.setScope(a.getScope());
            dependency.setType(a.getType());
            dependency.setClassifier(a.getClassifier());

            list.add(dependency);
        }
    }
    return list;
}

}
    