
class Java_96{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/790.java, start: 66, end: 79 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    // make sure IncludesArtifactFilter is not equal ExcludesArtifactFilter!
    if (obj == null || getClass() != obj.getClass()) {
        return false;
    }

    IncludesArtifactFilter other = (IncludesArtifactFilter)obj;

    return patterns.equals(other.patterns);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/765.java, start: 78, end: 93 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return pomHash == other.pomHash &&
        artifactEquals(artifact, other.artifact) &&
        resolveManagedVersions == other.resolveManagedVersions &&
        repositoriesEquals(repositories, other.repositories);
}

}
    