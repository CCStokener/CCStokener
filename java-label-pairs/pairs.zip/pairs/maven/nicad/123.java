
class Java_123{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1134, end: 1159 */
protected void mergeDependency_Exclusions(Dependency target,
                                          Dependency source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    List<Exclusion> src = source.getExclusions();
    if (!src.isEmpty()) {
        List<Exclusion> tgt = target.getExclusions();

        Map<Object, Exclusion> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Exclusion element : tgt) {
            Object key = getExclusionKey(element);
            merged.put(key, element);
        }

        for (Exclusion element : src) {
            Object key = getExclusionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExclusions(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2268, end: 2292 */
protected void mergeBuildBase_TestResources(BuildBase target,
                                            BuildBase source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    List<Resource> src = source.getTestResources();
    if (!src.isEmpty()) {
        List<Resource> tgt = target.getTestResources();
        Map<Object, Resource> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Resource element : tgt) {
            Object key = getResourceKey(element);
            merged.put(key, element);
        }

        for (Resource element : src) {
            Object key = getResourceKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setTestResources(new ArrayList<>(merged.values()));
    }
}

}
    