
class Java_20{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/609.java, start: 52, end: 127 */
public static Profile
convertToSettingsProfile(org.apache.maven.model.Profile modelProfile) {
    Profile profile = new Profile();

    profile.setId(modelProfile.getId());

    org.apache.maven.model.Activation modelActivation =
        modelProfile.getActivation();

    if (modelActivation != null) {
        Activation activation = new Activation();

        activation.setActiveByDefault(modelActivation.isActiveByDefault());

        activation.setJdk(modelActivation.getJdk());

        org.apache.maven.model.ActivationProperty modelProp =
            modelActivation.getProperty();

        if (modelProp != null) {
            ActivationProperty prop = new ActivationProperty();
            prop.setName(modelProp.getName());
            prop.setValue(modelProp.getValue());
            activation.setProperty(prop);
        }

        org.apache.maven.model.ActivationOS modelOs =
            modelActivation.getOs();

        if (modelOs != null) {
            ActivationOS os = new ActivationOS();

            os.setArch(modelOs.getArch());
            os.setFamily(modelOs.getFamily());
            os.setName(modelOs.getName());
            os.setVersion(modelOs.getVersion());

            activation.setOs(os);
        }

        ActivationFile modelFile = modelActivation.getFile();

        if (modelFile != null) {
            org.apache.maven.settings.ActivationFile file =
                new org.apache.maven.settings.ActivationFile();

            file.setExists(modelFile.getExists());
            file.setMissing(modelFile.getMissing());

            activation.setFile(file);
        }

        profile.setActivation(activation);
    }

    profile.setProperties(modelProfile.getProperties());

    List<org.apache.maven.model.Repository> repos =
        modelProfile.getRepositories();
    if (repos != null) {
        for (org.apache.maven.model.Repository repo : repos) {
            profile.addRepository(convertToSettingsRepository(repo));
        }
    }

    List<org.apache.maven.model.Repository> pluginRepos =
        modelProfile.getPluginRepositories();
    if (pluginRepos != null) {
        for (org.apache.maven.model.Repository pluginRepo : pluginRepos) {
            profile.addPluginRepository(
                convertToSettingsRepository(pluginRepo));
        }
    }

    return profile;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/116.java, start: 33, end: 112 */
public static Profile convertFromProfileXmlProfile(
    org.apache.maven.profiles.Profile profileXmlProfile) {
    Profile profile = new Profile();

    profile.setId(profileXmlProfile.getId());

    profile.setSource("profiles.xml");

    org.apache.maven.profiles.Activation profileActivation =
        profileXmlProfile.getActivation();

    if (profileActivation != null) {
        Activation activation = new Activation();

        activation.setActiveByDefault(
            profileActivation.isActiveByDefault());

        activation.setJdk(profileActivation.getJdk());

        org.apache.maven.profiles.ActivationProperty profileProp =
            profileActivation.getProperty();

        if (profileProp != null) {
            ActivationProperty prop = new ActivationProperty();

            prop.setName(profileProp.getName());
            prop.setValue(profileProp.getValue());

            activation.setProperty(prop);
        }

        ActivationOS profileOs = profileActivation.getOs();

        if (profileOs != null) {
            org.apache.maven.model.ActivationOS os =
                new org.apache.maven.model.ActivationOS();

            os.setArch(profileOs.getArch());
            os.setFamily(profileOs.getFamily());
            os.setName(profileOs.getName());
            os.setVersion(profileOs.getVersion());

            activation.setOs(os);
        }

        org.apache.maven.profiles.ActivationFile profileFile =
            profileActivation.getFile();

        if (profileFile != null) {
            ActivationFile file = new ActivationFile();

            file.setExists(profileFile.getExists());
            file.setMissing(profileFile.getMissing());

            activation.setFile(file);
        }

        profile.setActivation(activation);
    }

    profile.setProperties(profileXmlProfile.getProperties());

    List repos = profileXmlProfile.getRepositories();
    if (repos != null) {
        for (Object repo : repos) {
            profile.addRepository(convertFromProfileXmlRepository(
                (org.apache.maven.profiles.Repository)repo));
        }
    }

    List pluginRepos = profileXmlProfile.getPluginRepositories();
    if (pluginRepos != null) {
        for (Object pluginRepo : pluginRepos) {
            profile.addPluginRepository(convertFromProfileXmlRepository(
                (org.apache.maven.profiles.Repository)pluginRepo));
        }
    }

    return profile;
}

}
    