
class Java_181{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/736.java, start: 74, end: 88 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)obj;

    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) && version.equals(that.version) &&
        tag.equals(that.tag);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/604.java, start: 100, end: 117 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)o;

    return CacheUtils.pluginEquals(plugin, that.plugin) &&
        eq(workspace, that.workspace) &&
        eq(localRepo, that.localRepo) &&
        CacheUtils.repositoriesEquals(repositories,
                                      that.repositories) &&
        eq(filter, that.filter);
}

}
    