
class Java_147{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/839.java, start: 56, end: 70 */
private Plugin newPlugin(String artifactId, String... goals) {
    Plugin plugin = new Plugin();

    plugin.setGroupId("org.apache.maven.plugins");
    plugin.setArtifactId(artifactId);

    for (String goal : goals) {
        PluginExecution pluginExecution = new PluginExecution();
        pluginExecution.setId("default-" + goal);
        pluginExecution.addGoal(goal);
        plugin.addExecution(pluginExecution);
    }

    return plugin;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/221.java, start: 80, end: 94 */
private Plugin newPlugin(String artifactId, String... goals) {
    Plugin plugin = new Plugin();

    plugin.setGroupId("org.apache.maven.plugins");
    plugin.setArtifactId(artifactId);

    for (String goal : goals) {
        PluginExecution pluginExecution = new PluginExecution();
        pluginExecution.setId("default-" + goal);
        pluginExecution.addGoal(goal);
        plugin.addExecution(pluginExecution);
    }

    return plugin;
}

}
    