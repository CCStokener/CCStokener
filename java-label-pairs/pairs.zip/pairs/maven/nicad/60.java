
class Java_60{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 111, end: 124 */
protected void mergeModel_Organization(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    Organization src = source.getOrganization();
    if (src != null) {
        Organization tgt = target.getOrganization();
        if (tgt == null) {
            tgt = new Organization();
            tgt.setLocation("", src.getLocation(""));
            target.setOrganization(tgt);
            mergeOrganization(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 283, end: 295 */
protected void mergeModel_Organization(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    Organization src = source.getOrganization();
    if (src != null) {
        Organization tgt = target.getOrganization();
        if (tgt == null) {
            tgt = new Organization();
            target.setOrganization(tgt);
        }
        mergeOrganization(tgt, src, sourceDominant, context);
    }
}

}
    