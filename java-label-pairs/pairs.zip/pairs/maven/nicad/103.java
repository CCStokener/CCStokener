
class Java_103{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 489, end: 519 */
protected void mergePlugin_Executions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<PluginExecution> src = source.getExecutions();
    if (!src.isEmpty()) {
        List<PluginExecution> tgt = target.getExecutions();
        Map<Object, PluginExecution> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (PluginExecution element : src) {
            if (sourceDominant ||
                (element.getInherited() != null ? element.isInherited()
                                                : source.isInherited())) {
                Object key = getPluginExecutionKey(element);
                merged.put(key, element);
            }
        }

        for (PluginExecution element : tgt) {
            Object key = getPluginExecutionKey(element);
            PluginExecution existing = merged.get(key);
            if (existing != null) {
                mergePluginExecution(element, existing, sourceDominant,
                                     context);
            }
            merged.put(key, element);
        }

        target.setExecutions(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2243, end: 2266 */
protected void mergeBuildBase_Resources(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    List<Resource> src = source.getResources();
    if (!src.isEmpty()) {
        List<Resource> tgt = target.getResources();
        Map<Object, Resource> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Resource element : tgt) {
            Object key = getResourceKey(element);
            merged.put(key, element);
        }

        for (Resource element : src) {
            Object key = getResourceKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setResources(new ArrayList<>(merged.values()));
    }
}

}
    