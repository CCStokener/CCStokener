
class Java_173{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 373, end: 386 */
protected void mergeDistributionManagement_Repository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getRepository();
        if (sourceDominant || tgt == null) {
            tgt = new DeploymentRepository();
            tgt.setLocation("", src.getLocation(""));
            target.setRepository(tgt);
            mergeDeploymentRepository(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 389, end: 402 */
protected void mergeDistributionManagement_SnapshotRepository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getSnapshotRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getSnapshotRepository();
        if (sourceDominant || tgt == null) {
            tgt = new DeploymentRepository();
            tgt.setLocation("", src.getLocation(""));
            target.setSnapshotRepository(tgt);
            mergeDeploymentRepository(tgt, src, sourceDominant, context);
        }
    }
}

}
    