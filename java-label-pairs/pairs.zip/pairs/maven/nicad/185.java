
class Java_185{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/848.java, start: 28, end: 44 */
public void testCalculateProjectBuilds() throws Exception {
    LifecycleTaskSegmentCalculator lifecycleTaskSegmentCalculator =
        getTaskSegmentCalculator();
    BuildListCalculator buildListCalculator = new BuildListCalculator();
    final MavenSession session =
        ProjectDependencyGraphStub.getMavenSession();
    List<TaskSegment> taskSegments =
        lifecycleTaskSegmentCalculator.calculateTaskSegments(session);
    final ProjectBuildList buildList =
        buildListCalculator.calculateProjectBuilds(session, taskSegments);
    final ProjectBuildList segments =
        buildList.getByTaskSegment(taskSegments.get(0));
    assertEquals("Stub data contains 3 segments", 3, taskSegments.size());
    assertEquals("Stub data contains 6 items", 6, segments.size());
    final ProjectSegment build = segments.get(0);
    assertNotNull(build);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/846.java, start: 32, end: 49 */
public void testCalculateProjectBuilds() throws Exception {
    LifecycleTaskSegmentCalculator lifecycleTaskSegmentCalculator =
        getTaskSegmentCalculator();
    BuildListCalculator buildListCalculator = new BuildListCalculator();
    final MavenSession session =
        ProjectDependencyGraphStub.getMavenSession();
    List<TaskSegment> taskSegments =
        lifecycleTaskSegmentCalculator.calculateTaskSegments(session);

    final ProjectBuildList buildList =
        buildListCalculator.calculateProjectBuilds(session, taskSegments);
    final ProjectBuildList segments =
        buildList.getByTaskSegment(taskSegments.get(0));
    assertEquals("Stub data contains 3 segments", 3, taskSegments.size());
    assertEquals("Stub data contains 6 items", 6, segments.size());
    final ProjectSegment build = segments.get(0);
    assertNotNull(build);
}

}
    