
class Java_112{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/787.java, start: 61, end: 73 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof ExclusionSetFilter)) {
        return false;
    }

    ExclusionSetFilter other = (ExclusionSetFilter)obj;

    return excludes.equals(other.excludes);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/588.java, start: 115, end: 134 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)o;

    return parentRealm == that.parentRealm &&
        CacheUtils.pluginEquals(plugin, that.plugin) &&
        eq(workspace, that.workspace) &&
        eq(localRepo, that.localRepo) &&
        CacheUtils.repositoriesEquals(this.repositories,
                                      that.repositories) &&
        eq(filter, that.filter) &&
        eq(foreignImports, that.foreignImports);
}

}
    