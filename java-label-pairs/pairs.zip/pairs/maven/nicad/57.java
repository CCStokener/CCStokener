
class Java_57{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/765.java, start: 78, end: 93 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return pomHash == other.pomHash &&
        artifactEquals(artifact, other.artifact) &&
        resolveManagedVersions == other.resolveManagedVersions &&
        repositoriesEquals(repositories, other.repositories);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/732.java, start: 60, end: 72 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return extensionRealms.equals(other.extensionRealms);
}

}
    