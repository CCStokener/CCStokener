
class Java_17{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 575, end: 599 */
protected void
mergeModelBase_PluginRepositories(ModelBase target, ModelBase source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    List<Repository> src = source.getPluginRepositories();
    if (!src.isEmpty()) {
        List<Repository> tgt = target.getPluginRepositories();
        Map<Object, Repository> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Repository element : tgt) {
            Object key = getRepositoryKey(element);
            merged.put(key, element);
        }

        for (Repository element : src) {
            Object key = getRepositoryKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setPluginRepositories(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2108, end: 2131 */
protected void mergeBuild_Extensions(Build target, Build source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Extension> src = source.getExtensions();
    if (!src.isEmpty()) {
        List<Extension> tgt = target.getExtensions();
        Map<Object, Extension> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Extension element : tgt) {
            Object key = getExtensionKey(element);
            merged.put(key, element);
        }

        for (Extension element : src) {
            Object key = getExtensionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExtensions(new ArrayList<>(merged.values()));
    }
}

}
    