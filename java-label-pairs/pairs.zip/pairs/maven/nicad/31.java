
class Java_31{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/787.java, start: 61, end: 73 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof ExclusionSetFilter)) {
        return false;
    }

    ExclusionSetFilter other = (ExclusionSetFilter)obj;

    return excludes.equals(other.excludes);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/591.java, start: 83, end: 97 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return ids.equals(other.ids) && files.equals(other.files) &&
        timestamps.equals(other.timestamps) &&
        sizes.equals(other.sizes);
}

}
    