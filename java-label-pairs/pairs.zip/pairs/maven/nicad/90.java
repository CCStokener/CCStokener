
class Java_90{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/597.java, start: 78, end: 87 */
public boolean equals(Object obj) {
    if (obj == this) {
        return true;
    } else if (obj == null || !getClass().equals(obj.getClass())) {
        return false;
    }

    WagonExcluder that = (WagonExcluder)obj;
    return coreArtifact == that.coreArtifact;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/146.java, start: 43, end: 55 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof InversionArtifactFilter)) {
        return false;
    }

    InversionArtifactFilter other = (InversionArtifactFilter)obj;

    return toInvert.equals(other.toInvert);
}

}
    