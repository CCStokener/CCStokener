
class Java_35{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/785.java, start: 71, end: 83 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof AndArtifactFilter)) {
        return false;
    }

    AndArtifactFilter other = (AndArtifactFilter)obj;

    return filters.equals(other.filters);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/148.java, start: 65, end: 77 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof OrArtifactFilter)) {
        return false;
    }

    OrArtifactFilter other = (OrArtifactFilter)obj;

    return filters.equals(other.filters);
}

}
    