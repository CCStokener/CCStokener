
class Java_53{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 111, end: 124 */
protected void mergeModel_Organization(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    Organization src = source.getOrganization();
    if (src != null) {
        Organization tgt = target.getOrganization();
        if (tgt == null) {
            tgt = new Organization();
            tgt.setLocation("", src.getLocation(""));
            target.setOrganization(tgt);
            mergeOrganization(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 143, end: 156 */
protected void mergeModel_CiManagement(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    CiManagement src = source.getCiManagement();
    if (src != null) {
        CiManagement tgt = target.getCiManagement();
        if (tgt == null) {
            tgt = new CiManagement();
            tgt.setLocation("", src.getLocation(""));
            target.setCiManagement(tgt);
            mergeCiManagement(tgt, src, sourceDominant, context);
        }
    }
}

}
    