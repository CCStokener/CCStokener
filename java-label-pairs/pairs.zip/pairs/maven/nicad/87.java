
class Java_87{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/257.java, start: 110, end: 122 */
private boolean determineArchMatch(String arch) {
    String test = arch;
    boolean reverse = false;

    if (test.startsWith("!")) {
        reverse = true;
        test = test.substring(1);
    }

    boolean result = Os.isArch(test);

    return reverse ? !result : result;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/257.java, start: 138, end: 150 */
private boolean determineFamilyMatch(String family) {
    String test = family;
    boolean reverse = false;

    if (test.startsWith("!")) {
        reverse = true;
        test = test.substring(1);
    }

    boolean result = Os.isFamily(test);

    return reverse ? !result : result;
}

}
    