
class Java_68{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/393.java, start: 97, end: 144 */
public void testVersionComparing() {
    assertVersionEqual("1", "1");
    assertVersionOlder("1", "2");
    assertVersionOlder("1.5", "2");
    assertVersionOlder("1", "2.5");
    assertVersionEqual("1", "1.0");
    assertVersionEqual("1", "1.0.0");
    assertVersionOlder("1.0", "1.1");
    assertVersionOlder("1.1", "1.2");
    assertVersionOlder("1.0.0", "1.1");
    assertVersionOlder("1.1", "1.2.0");

    assertVersionOlder("1.1.2.alpha1", "1.1.2");
    assertVersionOlder("1.1.2.alpha1", "1.1.2.beta1");
    assertVersionOlder("1.1.2.beta1", "1.2");

    assertVersionOlder("1.0-alpha-1", "1.0");
    assertVersionOlder("1.0-alpha-1", "1.0-alpha-2");
    assertVersionOlder("1.0-alpha-2", "1.0-alpha-15");
    assertVersionOlder("1.0-alpha-1", "1.0-beta-1");

    assertVersionOlder("1.0-beta-1", "1.0-SNAPSHOT");
    assertVersionOlder("1.0-SNAPSHOT", "1.0");
    assertVersionOlder("1.0-alpha-1-SNAPSHOT", "1.0-alpha-1");

    assertVersionOlder("1.0", "1.0-1");
    assertVersionOlder("1.0-1", "1.0-2");
    assertVersionEqual("2.0-0", "2.0");
    assertVersionOlder("2.0", "2.0-1");
    assertVersionOlder("2.0.0", "2.0-1");
    assertVersionOlder("2.0-1", "2.0.1");

    assertVersionOlder("2.0.1-klm", "2.0.1-lmn");
    assertVersionOlder("2.0.1", "2.0.1-xyz");
    assertVersionOlder("2.0.1-xyz-1", "2.0.1-1-xyz");

    assertVersionOlder("2.0.1", "2.0.1-123");
    assertVersionOlder("2.0.1-xyz", "2.0.1-123");

    assertVersionOlder("1.2.3-10000000000", "1.2.3-10000000001");
    assertVersionOlder("1.2.3-1", "1.2.3-10000000001");
    assertVersionOlder(
        "2.3.0-v200706262000",
        "2.3.0-v200706262130"); // org.eclipse:emf:2.3.0-v200706262000
    // org.eclipse.wst.common_core.feature_2.0.0.v200706041905-7C78EK9E_EkMNfNOd2d8qq
    assertVersionOlder("2.0.0.v200706041905-7C78EK9E_EkMNfNOd2d8qq",
                       "2.0.0.v200706041906-7C78EK9E_EkMNfNOd2d8qq");
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/392.java, start: 117, end: 163 */
public void testVersionsEqual() {
    newComparable("1.0-alpha");
    checkVersionsEqual("1", "1");
    checkVersionsEqual("1", "1.0");
    checkVersionsEqual("1", "1.0.0");
    checkVersionsEqual("1.0", "1.0.0");
    checkVersionsEqual("1", "1-0");
    checkVersionsEqual("1", "1.0-0");
    checkVersionsEqual("1.0", "1.0-0");
    // no separator between number and character
    checkVersionsEqual("1a", "1-a");
    checkVersionsEqual("1a", "1.0-a");
    checkVersionsEqual("1a", "1.0.0-a");
    checkVersionsEqual("1.0a", "1-a");
    checkVersionsEqual("1.0.0a", "1-a");
    checkVersionsEqual("1x", "1-x");
    checkVersionsEqual("1x", "1.0-x");
    checkVersionsEqual("1x", "1.0.0-x");
    checkVersionsEqual("1.0x", "1-x");
    checkVersionsEqual("1.0.0x", "1-x");

    // aliases
    checkVersionsEqual("1ga", "1");
    checkVersionsEqual("1final", "1");
    checkVersionsEqual("1cr", "1rc");

    // special "aliases" a, b and m for alpha, beta and milestone
    checkVersionsEqual("1a1", "1-alpha-1");
    checkVersionsEqual("1b2", "1-beta-2");
    checkVersionsEqual("1m3", "1-milestone-3");

    // case insensitive
    checkVersionsEqual("1X", "1x");
    checkVersionsEqual("1A", "1a");
    checkVersionsEqual("1B", "1b");
    checkVersionsEqual("1M", "1m");
    checkVersionsEqual("1Ga", "1");
    checkVersionsEqual("1GA", "1");
    checkVersionsEqual("1Final", "1");
    checkVersionsEqual("1FinaL", "1");
    checkVersionsEqual("1FINAL", "1");
    checkVersionsEqual("1Cr", "1Rc");
    checkVersionsEqual("1cR", "1rC");
    checkVersionsEqual("1m3", "1Milestone3");
    checkVersionsEqual("1m3", "1MileStone3");
    checkVersionsEqual("1m3", "1MILESTONE3");
}

}
    