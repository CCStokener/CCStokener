
class Java_39{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/765.java, start: 78, end: 93 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return pomHash == other.pomHash &&
        artifactEquals(artifact, other.artifact) &&
        resolveManagedVersions == other.resolveManagedVersions &&
        repositoriesEquals(repositories, other.repositories);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/737.java, start: 69, end: 82 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)obj;

    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) && version.equals(that.version);
}

}
    