
class Java_11{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 440, end: 453 */
protected void mergeModel_Prerequisites(Model target, Model source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    Prerequisites src = source.getPrerequisites();
    if (src != null) {
        Prerequisites tgt = target.getPrerequisites();
        if (tgt == null) {
            tgt = new Prerequisites();
            tgt.setMaven(null);
            target.setPrerequisites(tgt);
        }
        mergePrerequisites(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 601, end: 614 */
protected void
mergeModelBase_DistributionManagement(ModelBase target, ModelBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    DistributionManagement src = source.getDistributionManagement();
    if (src != null) {
        DistributionManagement tgt = target.getDistributionManagement();
        if (tgt == null) {
            tgt = new DistributionManagement();
            target.setDistributionManagement(tgt);
        }
        mergeDistributionManagement(tgt, src, sourceDominant, context);
    }
}

}
    