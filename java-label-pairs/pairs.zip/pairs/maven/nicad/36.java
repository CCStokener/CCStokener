
class Java_36{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/408.java, start: 106, end: 120 */
public DefaultSettingsBuildingRequest
setSystemProperties(Properties systemProperties) {
    if (systemProperties != null) {
        this.systemProperties = new Properties();
        synchronized (systemProperties) { // avoid concurrentmodification if
                                          // someone else sets/removes an
                                          // unrelated system property
            this.systemProperties.putAll(systemProperties);
        }
    } else {
        this.systemProperties = null;
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/292.java, start: 250, end: 264 */
public DefaultModelBuildingRequest
setSystemProperties(Properties systemProperties) {
    if (systemProperties != null) {
        this.systemProperties = new Properties();
        synchronized (systemProperties) { // avoid concurrentmodification if
                                          // someone else sets/removes an
                                          // unrelated system property
            this.systemProperties.putAll(systemProperties);
        }
    } else {
        this.systemProperties = null;
    }

    return this;
}

}
    