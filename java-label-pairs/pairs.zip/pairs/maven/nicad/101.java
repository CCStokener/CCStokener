
class Java_101{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/765.java, start: 78, end: 93 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return pomHash == other.pomHash &&
        artifactEquals(artifact, other.artifact) &&
        resolveManagedVersions == other.resolveManagedVersions &&
        repositoriesEquals(repositories, other.repositories);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/146.java, start: 43, end: 55 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof InversionArtifactFilter)) {
        return false;
    }

    InversionArtifactFilter other = (InversionArtifactFilter)obj;

    return toInvert.equals(other.toInvert);
}

}
    