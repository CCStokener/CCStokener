
class Java_189{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 469, end: 492 */
protected void mergeModel_Profiles(Model target, Model source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    List<Profile> src = source.getProfiles();
    if (!src.isEmpty()) {
        List<Profile> tgt = target.getProfiles();
        Map<Object, Profile> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Profile element : tgt) {
            Object key = getProfileKey(element);
            merged.put(key, element);
        }

        for (Profile element : src) {
            Object key = getProfileKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setProfiles(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1903, end: 1927 */
protected void mergeCiManagement_Notifiers(CiManagement target,
                                           CiManagement source,
                                           boolean sourceDominant,
                                           Map<Object, Object> context) {
    List<Notifier> src = source.getNotifiers();
    if (!src.isEmpty()) {
        List<Notifier> tgt = target.getNotifiers();
        Map<Object, Notifier> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Notifier element : tgt) {
            Object key = getNotifierKey(element);
            merged.put(key, element);
        }

        for (Notifier element : src) {
            Object key = getNotifierKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setNotifiers(new ArrayList<>(merged.values()));
    }
}

}
    