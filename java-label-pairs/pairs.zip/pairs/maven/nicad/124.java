
class Java_124{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 494, end: 508 */
protected void mergeModelBase(ModelBase target, ModelBase source,
                              boolean sourceDominant,
                              Map<Object, Object> context) {
    mergeModelBase_DistributionManagement(target, source, sourceDominant,
                                          context);
    mergeModelBase_Modules(target, source, sourceDominant, context);
    mergeModelBase_Repositories(target, source, sourceDominant, context);
    mergeModelBase_PluginRepositories(target, source, sourceDominant,
                                      context);
    mergeModelBase_Dependencies(target, source, sourceDominant, context);
    mergeModelBase_Reporting(target, source, sourceDominant, context);
    mergeModelBase_DependencyManagement(target, source, sourceDominant,
                                        context);
    mergeModelBase_Properties(target, source, sourceDominant, context);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1017, end: 1029 */
protected void mergeDependency(Dependency target, Dependency source,
                               boolean sourceDominant,
                               Map<Object, Object> context) {
    mergeDependency_GroupId(target, source, sourceDominant, context);
    mergeDependency_ArtifactId(target, source, sourceDominant, context);
    mergeDependency_Version(target, source, sourceDominant, context);
    mergeDependency_Type(target, source, sourceDominant, context);
    mergeDependency_Classifier(target, source, sourceDominant, context);
    mergeDependency_Scope(target, source, sourceDominant, context);
    mergeDependency_SystemPath(target, source, sourceDominant, context);
    mergeDependency_Optional(target, source, sourceDominant, context);
    mergeDependency_Exclusions(target, source, sourceDominant, context);
}

}
    