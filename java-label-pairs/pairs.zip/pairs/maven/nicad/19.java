
class Java_19{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/791.java, start: 49, end: 61 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof ScopeArtifactFilter)) {
        return false;
    }

    ScopeArtifactFilter other = (ScopeArtifactFilter)obj;

    return equals(scope, other.scope);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/787.java, start: 61, end: 73 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof ExclusionSetFilter)) {
        return false;
    }

    ExclusionSetFilter other = (ExclusionSetFilter)obj;

    return excludes.equals(other.excludes);
}

}
    