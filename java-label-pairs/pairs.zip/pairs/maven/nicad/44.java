
class Java_44{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/477.java, start: 123, end: 139 */
public void
testResolveDependencyThrowsUnresolvableModelExceptionWhenNotFound()
    throws Exception {
    final Dependency dependency = new Dependency();
    dependency.setGroupId("ut.simple");
    dependency.setArtifactId("artifact");
    dependency.setVersion("0");

    try {
        this.newModelResolver().resolveModel(dependency);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertNotNull(e.getMessage());
        assertTrue(e.getMessage().startsWith(
            "Could not find artifact ut.simple:artifact:pom:0 in repo"));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/477.java, start: 141, end: 157 */
public void
testResolveDependencyThrowsUnresolvableModelExceptionWhenNoMatchingVersionFound()
    throws Exception {
    final Dependency dependency = new Dependency();
    dependency.setGroupId("ut.simple");
    dependency.setArtifactId("artifact");
    dependency.setVersion("[2.0,2.1)");

    try {
        this.newModelResolver().resolveModel(dependency);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "No versions matched the requested dependency version range '[2.0,2.1)'",
            e.getMessage());
    }
}

}
    