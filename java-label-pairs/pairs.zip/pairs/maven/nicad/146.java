
class Java_146{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/313.java, start: 94, end: 121 */
protected void mergePlugin_Executions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<PluginExecution> src = source.getExecutions();
    if (!src.isEmpty()) {
        List<PluginExecution> tgt = target.getExecutions();

        Map<Object, PluginExecution> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (PluginExecution element : src) {
            Object key = getPluginExecutionKey(element);
            merged.put(key, element.clone());
        }

        for (PluginExecution element : tgt) {
            Object key = getPluginExecutionKey(element);
            PluginExecution existing = merged.get(key);
            if (existing != null) {
                mergePluginExecution(element, existing, sourceDominant,
                                     context);
            }
            merged.put(key, element);
        }

        target.setExecutions(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2419, end: 2442 */
protected void mergePlugin_Dependencies(Plugin target, Plugin source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    List<Dependency> src = source.getDependencies();
    if (!src.isEmpty()) {
        List<Dependency> tgt = target.getDependencies();
        Map<Object, Dependency> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Dependency element : tgt) {
            Object key = getDependencyKey(element);
            merged.put(key, element);
        }

        for (Dependency element : src) {
            Object key = getDependencyKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setDependencies(new ArrayList<>(merged.values()));
    }
}

}
    