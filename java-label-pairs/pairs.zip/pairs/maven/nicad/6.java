
class Java_6{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 347, end: 370 */
protected void mergeModel_Developers(Model target, Model source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Developer> src = source.getDevelopers();
    if (!src.isEmpty()) {
        List<Developer> tgt = target.getDevelopers();
        Map<Object, Developer> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Developer element : tgt) {
            Object key = getDeveloperKey(element);
            merged.put(key, element);
        }

        for (Developer element : src) {
            Object key = getDeveloperKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setDevelopers(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1371, end: 1394 */
protected void mergeDependencyManagement_Dependencies(
    DependencyManagement target, DependencyManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    List<Dependency> src = source.getDependencies();
    if (!src.isEmpty()) {
        List<Dependency> tgt = target.getDependencies();
        Map<Object, Dependency> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Dependency element : tgt) {
            Object key = getDependencyKey(element);
            merged.put(key, element);
        }

        for (Dependency element : src) {
            Object key = getDependencyKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setDependencies(new ArrayList<>(merged.values()));
    }
}

}
    