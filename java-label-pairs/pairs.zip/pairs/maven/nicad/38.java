
class Java_38{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/459.java, start: 88, end: 100 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }
    if (null == obj || !getClass().equals(obj.getClass())) {
        return false;
    }

    Key that = (Key)obj;
    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) && version.equals(that.version) &&
        tag.equals(that.tag);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/451.java, start: 534, end: 550 */
public boolean equals(Object obj) {
    if (obj == this) {
        return true;
    } else if (obj == null || !getClass().equals(obj.getClass())) {
        return false;
    }

    Key that = (Key)obj;
    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) &&
        classifier.equals(that.classifier) &&
        extension.equals(that.extension) &&
        version.equals(that.version) && context.equals(that.context) &&
        localRepo.equals(that.localRepo) &&
        CacheUtils.eq(workspace, that.workspace) &&
        CacheUtils.repositoriesEquals(repositories, that.repositories);
}

}
    