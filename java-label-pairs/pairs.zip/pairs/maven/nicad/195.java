
class Java_195{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 322, end: 345 */
protected void mergeModel_MailingLists(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    List<MailingList> src = source.getMailingLists();
    if (!src.isEmpty()) {
        List<MailingList> tgt = target.getMailingLists();
        Map<Object, MailingList> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (MailingList element : tgt) {
            Object key = getMailingListKey(element);
            merged.put(key, element);
        }

        for (MailingList element : src) {
            Object key = getMailingListKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setMailingLists(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2108, end: 2131 */
protected void mergeBuild_Extensions(Build target, Build source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Extension> src = source.getExtensions();
    if (!src.isEmpty()) {
        List<Extension> tgt = target.getExtensions();
        Map<Object, Extension> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Extension element : tgt) {
            Object key = getExtensionKey(element);
            merged.put(key, element);
        }

        for (Extension element : src) {
            Object key = getExtensionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExtensions(new ArrayList<>(merged.values()));
    }
}

}
    