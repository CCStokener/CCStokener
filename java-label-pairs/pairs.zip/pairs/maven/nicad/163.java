
class Java_163{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 426, end: 438 */
protected void mergeModel_CiManagement(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    CiManagement src = source.getCiManagement();
    if (src != null) {
        CiManagement tgt = target.getCiManagement();
        if (tgt == null) {
            tgt = new CiManagement();
            target.setCiManagement(tgt);
        }
        mergeCiManagement(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 440, end: 453 */
protected void mergeModel_Prerequisites(Model target, Model source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    Prerequisites src = source.getPrerequisites();
    if (src != null) {
        Prerequisites tgt = target.getPrerequisites();
        if (tgt == null) {
            tgt = new Prerequisites();
            tgt.setMaven(null);
            target.setPrerequisites(tgt);
        }
        mergePrerequisites(tgt, src, sourceDominant, context);
    }
}

}
    