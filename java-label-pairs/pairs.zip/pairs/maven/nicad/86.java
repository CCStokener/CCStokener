
class Java_86{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 314, end: 334 */
public void testBasedir() throws Exception {
    Model model = new Model();
    model.setVersion("3.8.1");
    model.setArtifactId("foo");

    Repository repository = new Repository();

    repository.setUrl("file://localhost/${basedir}/temp-repo");

    model.addRepository(repository);

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, null, createModelBuildingRequest(context), collector);
    assertProblemFree(collector);

    assertEquals("file://localhost/myBasedir/temp-repo",
                 (out.getRepositories().get(0)).getUrl());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 336, end: 356 */
public void testBaseUri() throws Exception {
    Model model = new Model();
    model.setVersion("3.8.1");
    model.setArtifactId("foo");

    Repository repository = new Repository();

    repository.setUrl("${project.baseUri}/temp-repo");

    model.addRepository(repository);

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, null, createModelBuildingRequest(context), collector);
    assertProblemFree(collector);

    assertEquals("myBaseUri/temp-repo",
                 (out.getRepositories().get(0)).getUrl());
}

}
    