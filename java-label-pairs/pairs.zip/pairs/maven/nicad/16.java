
class Java_16{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 111, end: 124 */
protected void mergeModel_Organization(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    Organization src = source.getOrganization();
    if (src != null) {
        Organization tgt = target.getOrganization();
        if (tgt == null) {
            tgt = new Organization();
            tgt.setLocation("", src.getLocation(""));
            target.setOrganization(tgt);
            mergeOrganization(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 455, end: 467 */
protected void mergeModel_Build(Model target, Model source,
                                boolean sourceDominant,
                                Map<Object, Object> context) {
    Build src = source.getBuild();
    if (src != null) {
        Build tgt = target.getBuild();
        if (tgt == null) {
            tgt = new Build();
            target.setBuild(tgt);
        }
        mergeBuild(tgt, src, sourceDominant, context);
    }
}

}
    