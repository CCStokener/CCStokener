
class Java_48{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/347.java, start: 60, end: 81 */
public void testInterpolateStringArray() throws Exception {
    Model model = new Model();

    Properties p = new Properties();
    p.setProperty("key", "value");
    p.setProperty("key2", "value2");

    String[] values = {"${key}", "${key2}"};

    StringSearchModelInterpolator interpolator =
        (StringSearchModelInterpolator)createInterpolator();

    ModelBuildingRequest config = createModelBuildingRequest(p);

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    interpolator.interpolateObject(values, model, new File("."), config,
                                   collector);
    assertProblemFree(collector);

    assertEquals("value", values[0]);
    assertEquals("value2", values[1]);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/347.java, start: 89, end: 112 */
public void testInterpolateObjectWithStringArrayField() throws Exception {
    Model model = new Model();

    Properties p = new Properties();
    p.setProperty("key", "value");
    p.setProperty("key2", "value2");

    String[] values = {"${key}", "${key2}"};

    ObjectWithStringArrayField obj = new ObjectWithStringArrayField(values);

    StringSearchModelInterpolator interpolator =
        (StringSearchModelInterpolator)createInterpolator();

    ModelBuildingRequest config = createModelBuildingRequest(p);

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    interpolator.interpolateObject(obj, model, new File("."), config,
                                   collector);
    assertProblemFree(collector);

    assertEquals("value", obj.values[0]);
    assertEquals("value2", obj.values[1]);
}

}
    