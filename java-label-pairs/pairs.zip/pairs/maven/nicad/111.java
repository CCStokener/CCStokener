
class Java_111{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/732.java, start: 60, end: 72 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return extensionRealms.equals(other.extensionRealms);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/451.java, start: 534, end: 550 */
public boolean equals(Object obj) {
    if (obj == this) {
        return true;
    } else if (obj == null || !getClass().equals(obj.getClass())) {
        return false;
    }

    Key that = (Key)obj;
    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) &&
        classifier.equals(that.classifier) &&
        extension.equals(that.extension) &&
        version.equals(that.version) && context.equals(that.context) &&
        localRepo.equals(that.localRepo) &&
        CacheUtils.eq(workspace, that.workspace) &&
        CacheUtils.repositoriesEquals(repositories, that.repositories);
}

}
    