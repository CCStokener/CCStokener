
class Java_85{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/258.java, start: 160, end: 175 */
public boolean presentInConfig(Profile profile,
                               ProfileActivationContext context,
                               ModelProblemCollector problems) {
    Activation activation = profile.getActivation();

    if (activation == null) {
        return false;
    }

    ActivationFile file = activation.getFile();

    if (file == null) {
        return false;
    }
    return true;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/254.java, start: 101, end: 116 */
public boolean presentInConfig(Profile profile,
                               ProfileActivationContext context,
                               ModelProblemCollector problems) {
    Activation activation = profile.getActivation();

    if (activation == null) {
        return false;
    }

    ActivationProperty property = activation.getProperty();

    if (property == null) {
        return false;
    }
    return true;
}

}
    