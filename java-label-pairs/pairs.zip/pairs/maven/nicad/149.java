
class Java_149{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 405, end: 418 */
protected void mergeDistributionManagement_Site(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    Site src = source.getSite();
    if (src != null) {
        Site tgt = target.getSite();
        if (sourceDominant || tgt == null) {
            tgt = new Site();
            tgt.setLocation("", src.getLocation(""));
            target.setSite(tgt);
            mergeSite(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 616, end: 628 */
protected void mergeModelBase_Reporting(ModelBase target, ModelBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    Reporting src = source.getReporting();
    if (src != null) {
        Reporting tgt = target.getReporting();
        if (tgt == null) {
            tgt = new Reporting();
            target.setReporting(tgt);
        }
        mergeReporting(tgt, src, sourceDominant, context);
    }
}

}
    