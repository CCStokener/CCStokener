
class Java_55{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 143, end: 156 */
protected void mergeModel_CiManagement(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    CiManagement src = source.getCiManagement();
    if (src != null) {
        CiManagement tgt = target.getCiManagement();
        if (tgt == null) {
            tgt = new CiManagement();
            tgt.setLocation("", src.getLocation(""));
            target.setCiManagement(tgt);
            mergeCiManagement(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 389, end: 402 */
protected void mergeDistributionManagement_SnapshotRepository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getSnapshotRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getSnapshotRepository();
        if (sourceDominant || tgt == null) {
            tgt = new DeploymentRepository();
            tgt.setLocation("", src.getLocation(""));
            target.setSnapshotRepository(tgt);
            mergeDeploymentRepository(tgt, src, sourceDominant, context);
        }
    }
}

}
    