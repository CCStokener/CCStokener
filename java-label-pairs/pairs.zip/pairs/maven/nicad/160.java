
class Java_160{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 411, end: 424 */
protected void mergeModel_Scm(Model target, Model source,
                              boolean sourceDominant,
                              Map<Object, Object> context) {
    Scm src = source.getScm();
    if (src != null) {
        Scm tgt = target.getScm();
        if (tgt == null) {
            tgt = new Scm();
            tgt.setTag(null);
            target.setScm(tgt);
        }
        mergeScm(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 455, end: 467 */
protected void mergeModel_Build(Model target, Model source,
                                boolean sourceDominant,
                                Map<Object, Object> context) {
    Build src = source.getBuild();
    if (src != null) {
        Build tgt = target.getBuild();
        if (tgt == null) {
            tgt = new Build();
            target.setBuild(tgt);
        }
        mergeBuild(tgt, src, sourceDominant, context);
    }
}

}
    