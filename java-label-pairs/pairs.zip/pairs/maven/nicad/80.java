
class Java_80{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/886.java, start: 155, end: 168 */
public void testMatchingArtifactIdsDifferentGroupIds()
    throws CycleDetectedException, DuplicateProjectException {
    List<MavenProject> projects = new ArrayList<>();
    MavenProject project1 = createProject("groupId1", "artifactId", "1.0");
    projects.add(project1);
    MavenProject project2 = createProject("groupId2", "artifactId", "1.0");
    projects.add(project2);
    project1.getDependencies().add(createDependency(project2));

    projects = new ProjectSorter(projects).getSortedProjects();

    assertEquals(project2, projects.get(0));
    assertEquals(project1, projects.get(1));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/886.java, start: 170, end: 183 */
public void testMatchingGroupIdsDifferentArtifactIds()
    throws CycleDetectedException, DuplicateProjectException {
    List<MavenProject> projects = new ArrayList<>();
    MavenProject project1 = createProject("groupId", "artifactId1", "1.0");
    projects.add(project1);
    MavenProject project2 = createProject("groupId", "artifactId2", "1.0");
    projects.add(project2);
    project1.getDependencies().add(createDependency(project2));

    projects = new ProjectSorter(projects).getSortedProjects();

    assertEquals(project2, projects.get(0));
    assertEquals(project1, projects.get(1));
}

}
    