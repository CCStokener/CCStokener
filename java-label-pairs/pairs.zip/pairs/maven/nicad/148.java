
class Java_148{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/592.java, start: 166, end: 184 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)obj;

    return eq(this.artifactId, that.artifactId) &&
        eq(this.groupId, that.groupId) &&
        eq(this.version, that.version) &&
        eq(this.localRepo, that.localRepo) &&
        eq(this.workspace, that.workspace) &&
        CacheUtils.repositoriesEquals(this.repositories,
                                      that.repositories);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/591.java, start: 83, end: 97 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return ids.equals(other.ids) && files.equals(other.files) &&
        timestamps.equals(other.timestamps) &&
        sizes.equals(other.sizes);
}

}
    