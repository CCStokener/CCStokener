
class Java_93{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/849.java, start: 55, end: 69 */
private Plugin newPlugin(String artifactId, String... goals) {
    Plugin plugin = new Plugin();

    plugin.setGroupId("org.apache.maven.plugins");
    plugin.setArtifactId(artifactId);

    for (String goal : goals) {
        PluginExecution pluginExecution = new PluginExecution();
        pluginExecution.setId("default-" + goal);
        pluginExecution.addGoal(goal);
        plugin.addExecution(pluginExecution);
    }

    return plugin;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/215.java, start: 57, end: 71 */
private Plugin newPlugin(String artifactId, String... goals) {
    Plugin plugin = new Plugin();

    plugin.setGroupId("org.apache.maven.plugins");
    plugin.setArtifactId(artifactId);

    for (String goal : goals) {
        PluginExecution pluginExecution = new PluginExecution();
        pluginExecution.setId("default-" + goal);
        pluginExecution.addGoal(goal);
        plugin.addExecution(pluginExecution);
    }

    return plugin;
}

}
    