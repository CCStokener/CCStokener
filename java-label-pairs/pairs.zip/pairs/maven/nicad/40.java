
class Java_40{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 601, end: 614 */
protected void
mergeModelBase_DistributionManagement(ModelBase target, ModelBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    DistributionManagement src = source.getDistributionManagement();
    if (src != null) {
        DistributionManagement tgt = target.getDistributionManagement();
        if (tgt == null) {
            tgt = new DistributionManagement();
            target.setDistributionManagement(tgt);
        }
        mergeDistributionManagement(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 630, end: 643 */
protected void
mergeModelBase_DependencyManagement(ModelBase target, ModelBase source,
                                    boolean sourceDominant,
                                    Map<Object, Object> context) {
    DependencyManagement src = source.getDependencyManagement();
    if (src != null) {
        DependencyManagement tgt = target.getDependencyManagement();
        if (tgt == null) {
            tgt = new DependencyManagement();
            target.setDependencyManagement(tgt);
        }
        mergeDependencyManagement(tgt, src, sourceDominant, context);
    }
}

}
    