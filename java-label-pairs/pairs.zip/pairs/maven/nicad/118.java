
class Java_118{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 347, end: 370 */
protected void mergeModel_Developers(Model target, Model source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Developer> src = source.getDevelopers();
    if (!src.isEmpty()) {
        List<Developer> tgt = target.getDevelopers();
        Map<Object, Developer> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Developer element : tgt) {
            Object key = getDeveloperKey(element);
            merged.put(key, element);
        }

        for (Developer element : src) {
            Object key = getDeveloperKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setDevelopers(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1903, end: 1927 */
protected void mergeCiManagement_Notifiers(CiManagement target,
                                           CiManagement source,
                                           boolean sourceDominant,
                                           Map<Object, Object> context) {
    List<Notifier> src = source.getNotifiers();
    if (!src.isEmpty()) {
        List<Notifier> tgt = target.getNotifiers();
        Map<Object, Notifier> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Notifier element : tgt) {
            Object key = getNotifierKey(element);
            merged.put(key, element);
        }

        for (Notifier element : src) {
            Object key = getNotifierKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setNotifiers(new ArrayList<>(merged.values()));
    }
}

}
    