
class Java_69{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 522, end: 539 */
protected void mergePluginExecution_Goals(PluginExecution target,
                                          PluginExecution source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    List<String> src = source.getGoals();
    if (!src.isEmpty()) {
        List<String> tgt = target.getGoals();
        Set<String> excludes = new LinkedHashSet<>(tgt);
        List<String> merged = new ArrayList<>(tgt.size() + src.size());
        merged.addAll(tgt);
        for (String s : src) {
            if (!excludes.contains(s)) {
                merged.add(s);
            }
        }
        target.setGoals(merged);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 510, end: 521 */
protected void mergeModelBase_Modules(ModelBase target, ModelBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<String> src = source.getModules();
    if (!src.isEmpty()) {
        List<String> tgt = target.getModules();
        List<String> merged = new ArrayList<>(tgt.size() + src.size());
        merged.addAll(tgt);
        merged.addAll(src);
        target.setModules(merged);
    }
}

}
    