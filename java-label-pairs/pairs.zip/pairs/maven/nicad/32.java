
class Java_32{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 188, end: 210 */
public void
testShouldNotThrowExceptionOnReferenceToValueContainingNakedExpression()
    throws Exception {
    Model model = new Model();

    Scm scm = new Scm();
    scm.setConnection("${test}/somepath");

    model.setScm(scm);

    model.addProperty("test", "test");

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, new File("."), createModelBuildingRequest(context),
        collector);

    assertProblemFree(collector);

    assertEquals("test/somepath", out.getScm().getConnection());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 383, end: 403 */
public void testEnvarExpressionThatEvaluatesToNullReturnsTheLiteralString()
    throws Exception {
    Model model = new Model();

    Properties modelProperties = new Properties();

    modelProperties.setProperty("outputDirectory", "${env.DOES_NOT_EXIST}");

    model.setProperties(modelProperties);

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, new File("."), createModelBuildingRequest(context),
        collector);
    assertProblemFree(collector);

    assertEquals(out.getProperties().getProperty("outputDirectory"),
                 "${env.DOES_NOT_EXIST}");
}

}
    