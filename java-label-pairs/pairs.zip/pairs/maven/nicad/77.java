
class Java_77{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/732.java, start: 60, end: 72 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return extensionRealms.equals(other.extensionRealms);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/604.java, start: 100, end: 117 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)o;

    return CacheUtils.pluginEquals(plugin, that.plugin) &&
        eq(workspace, that.workspace) &&
        eq(localRepo, that.localRepo) &&
        CacheUtils.repositoriesEquals(repositories,
                                      that.repositories) &&
        eq(filter, that.filter);
}

}
    