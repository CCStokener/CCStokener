
class Java_152{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/195.java, start: 106, end: 131 */
public void testShouldNotActivateReversalOfPresentSystemProperty()
    throws Exception {
    Profile syspropActivated = new Profile();
    syspropActivated.setId("syspropActivated");

    Activation syspropActivation = new Activation();

    ActivationProperty syspropProperty = new ActivationProperty();
    syspropProperty.setName("!java.version");

    syspropActivation.setProperty(syspropProperty);

    syspropActivated.setActivation(syspropActivation);

    Properties props = System.getProperties();

    ProfileManager profileManager =
        new DefaultProfileManager(getContainer(), props);

    profileManager.addProfile(syspropActivated);

    List active = profileManager.getActiveProfiles();

    assertNotNull(active);
    assertEquals(0, active.size());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/195.java, start: 163, end: 190 */
public void testShouldOverrideAndDeactivateActiveProfile()
    throws Exception {
    Profile syspropActivated = new Profile();
    syspropActivated.setId("syspropActivated");

    Activation syspropActivation = new Activation();

    ActivationProperty syspropProperty = new ActivationProperty();
    syspropProperty.setName("java.version");

    syspropActivation.setProperty(syspropProperty);

    syspropActivated.setActivation(syspropActivation);

    Properties props = System.getProperties();

    ProfileManager profileManager =
        new DefaultProfileManager(getContainer(), props);

    profileManager.addProfile(syspropActivated);

    profileManager.explicitlyDeactivate("syspropActivated");

    List active = profileManager.getActiveProfiles();

    assertNotNull(active);
    assertEquals(0, active.size());
}

}
    