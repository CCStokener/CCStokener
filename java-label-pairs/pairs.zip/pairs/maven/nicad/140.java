
class Java_140{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/381.java, start: 50, end: 62 */
public VersionRange cloneOf() {
    List<Restriction> copiedRestrictions = null;

    if (restrictions != null) {
        copiedRestrictions = new ArrayList<>();

        if (!restrictions.isEmpty()) {
            copiedRestrictions.addAll(restrictions);
        }
    }

    return new VersionRange(recommendedVersion, copiedRestrictions);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/369.java, start: 171, end: 183 */
private static <T> List<T> copyList(List<T> original) {
    List<T> copy = null;

    if (original != null) {
        copy = new ArrayList<>();

        if (!original.isEmpty()) {
            copy.addAll(original);
        }
    }

    return copy;
}

}
    