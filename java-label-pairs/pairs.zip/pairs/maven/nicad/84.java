
class Java_84{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 297, end: 320 */
protected void mergeModel_Licenses(Model target, Model source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    List<License> src = source.getLicenses();
    if (!src.isEmpty()) {
        List<License> tgt = target.getLicenses();
        Map<Object, License> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (License element : tgt) {
            Object key = getLicenseKey(element);
            merged.put(key, element);
        }

        for (License element : src) {
            Object key = getLicenseKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setLicenses(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1229, end: 1252 */
protected void mergeReporting_Plugins(Reporting target, Reporting source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<ReportPlugin> src = source.getPlugins();
    if (!src.isEmpty()) {
        List<ReportPlugin> tgt = target.getPlugins();
        Map<Object, ReportPlugin> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (ReportPlugin element : tgt) {
            Object key = getReportPluginKey(element);
            merged.put(key, element);
        }

        for (ReportPlugin element : src) {
            Object key = getReportPluginKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setPlugins(new ArrayList<>(merged.values()));
    }
}

}
    