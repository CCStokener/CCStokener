
class Java_116{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 469, end: 492 */
protected void mergeModel_Profiles(Model target, Model source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    List<Profile> src = source.getProfiles();
    if (!src.isEmpty()) {
        List<Profile> tgt = target.getProfiles();
        Map<Object, Profile> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Profile element : tgt) {
            Object key = getProfileKey(element);
            merged.put(key, element);
        }

        for (Profile element : src) {
            Object key = getProfileKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setProfiles(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2444, end: 2468 */
protected void mergePlugin_Executions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<PluginExecution> src = source.getExecutions();
    if (!src.isEmpty()) {
        List<PluginExecution> tgt = target.getExecutions();

        Map<Object, PluginExecution> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (PluginExecution element : tgt) {
            Object key = getPluginExecutionKey(element);
            merged.put(key, element);
        }

        for (PluginExecution element : src) {
            Object key = getPluginExecutionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExecutions(new ArrayList<>(merged.values()));
    }
}

}
    