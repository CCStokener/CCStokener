
class Java_136{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2108, end: 2131 */
protected void mergeBuild_Extensions(Build target, Build source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Extension> src = source.getExtensions();
    if (!src.isEmpty()) {
        List<Extension> tgt = target.getExtensions();
        Map<Object, Extension> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Extension element : tgt) {
            Object key = getExtensionKey(element);
            merged.put(key, element);
        }

        for (Extension element : src) {
            Object key = getExtensionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExtensions(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2419, end: 2442 */
protected void mergePlugin_Dependencies(Plugin target, Plugin source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    List<Dependency> src = source.getDependencies();
    if (!src.isEmpty()) {
        List<Dependency> tgt = target.getDependencies();
        Map<Object, Dependency> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Dependency element : tgt) {
            Object key = getDependencyKey(element);
            merged.put(key, element);
        }

        for (Dependency element : src) {
            Object key = getDependencyKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setDependencies(new ArrayList<>(merged.values()));
    }
}

}
    