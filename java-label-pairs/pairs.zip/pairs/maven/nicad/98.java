
class Java_98{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/689.java, start: 76, end: 87 */
public void onEvent(Object event) {
    if (eventSpies.isEmpty()) {
        return;
    }
    for (EventSpy eventSpy : eventSpies) {
        try {
            eventSpy.onEvent(event);
        } catch (Exception | LinkageError e) {
            logError("notify", e, eventSpy);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/689.java, start: 89, end: 100 */
public void close() {
    if (eventSpies.isEmpty()) {
        return;
    }
    for (EventSpy eventSpy : eventSpies) {
        try {
            eventSpy.close();
        } catch (Exception | LinkageError e) {
            logError("close", e, eventSpy);
        }
    }
}

}
    