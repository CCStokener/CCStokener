
class Java_7{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/427.java, start: 152, end: 167 */
public void testValidateUniqueProfileId() throws Exception {
    Settings settings = new Settings();
    Profile profile1 = new Profile();
    profile1.setId("test");
    settings.addProfile(profile1);
    Profile profile2 = new Profile();
    profile2.setId("test");
    settings.addProfile(profile2);

    SimpleProblemCollector problems = new SimpleProblemCollector();
    validator.validate(settings, problems);
    assertEquals(1, problems.messages.size());
    assertContains(
        problems.messages.get(0),
        "'profiles.profile.id' must be unique but found duplicate profile with id test");
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/427.java, start: 192, end: 207 */
public void testValidateUniqueProxyId() throws Exception {
    Settings settings = new Settings();
    Proxy proxy = new Proxy();
    String id = null;
    proxy.setId(id);
    proxy.setHost("www.example.com");
    settings.addProxy(proxy);
    settings.addProxy(proxy);

    SimpleProblemCollector problems = new SimpleProblemCollector();
    validator.validate(settings, problems);
    assertEquals(1, problems.messages.size());
    assertContains(problems.messages.get(0),
                   "'proxies.proxy.id' must be unique"
                       + " but found duplicate proxy with id " + id);
}

}
    