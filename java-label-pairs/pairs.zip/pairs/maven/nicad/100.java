
class Java_100{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 111, end: 124 */
protected void mergeModel_Organization(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    Organization src = source.getOrganization();
    if (src != null) {
        Organization tgt = target.getOrganization();
        if (tgt == null) {
            tgt = new Organization();
            tgt.setLocation("", src.getLocation(""));
            target.setOrganization(tgt);
            mergeOrganization(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 679, end: 691 */
protected void mergeDistributionManagement_Repository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getRepository();
        if (tgt == null) {
            tgt = new DeploymentRepository();
            target.setRepository(tgt);
        }
        mergeDeploymentRepository(tgt, src, sourceDominant, context);
    }
}

}
    