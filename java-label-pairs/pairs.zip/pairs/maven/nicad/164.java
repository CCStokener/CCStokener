
class Java_164{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/890.java, start: 55, end: 77 */
public Set<Plugin>
getPluginsBoundByDefaultToAllLifecycles(String packaging) {
    Set<Plugin> plugins;

    // NOTE: The upper-case packaging name is intentional, that's a special
    // hinting mode used for certain tests
    if ("JAR".equals(packaging)) {
        plugins = new LinkedHashSet<>();

        plugins.add(
            newPlugin("maven-compiler-plugin", "compile", "testCompile"));
        plugins.add(newPlugin("maven-resources-plugin", "resources",
                              "testResources"));
        plugins.add(newPlugin("maven-surefire-plugin", "test"));
        plugins.add(newPlugin("maven-jar-plugin", "jar"));
        plugins.add(newPlugin("maven-install-plugin", "install"));
        plugins.add(newPlugin("maven-deploy-plugin", "deploy"));
    } else {
        plugins = Collections.emptySet();
    }

    return plugins;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/839.java, start: 32, end: 54 */
public Set<Plugin>
getPluginsBoundByDefaultToAllLifecycles(String packaging) {
    Set<Plugin> plugins;

    // NOTE: The upper-case packaging name is intentional, that's a special
    // hinting mode used for certain tests
    if ("JAR".equals(packaging)) {
        plugins = new LinkedHashSet<>();

        plugins.add(
            newPlugin("maven-compiler-plugin", "compile", "testCompile"));
        plugins.add(newPlugin("maven-resources-plugin", "resources",
                              "testResources"));
        plugins.add(newPlugin("maven-surefire-plugin", "test"));
        plugins.add(newPlugin("maven-jar-plugin", "jar"));
        plugins.add(newPlugin("maven-install-plugin", "install"));
        plugins.add(newPlugin("maven-deploy-plugin", "deploy"));
    } else {
        plugins = Collections.emptySet();
    }

    return plugins;
}

}
    