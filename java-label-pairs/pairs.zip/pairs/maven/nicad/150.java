
class Java_150{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 132, end: 148 */
public void
testResolveDependencyThrowsUnresolvableModelExceptionWhenNotFound()
    throws Exception {
    final Dependency dependency = new Dependency();
    dependency.setGroupId("org.apache");
    dependency.setArtifactId("apache");
    dependency.setVersion("0");

    try {
        this.newModelResolver().resolveModel(dependency);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertNotNull(e.getMessage());
        assertTrue(e.getMessage().startsWith(
            "Could not find artifact org.apache:apache:pom:0 in central"));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/477.java, start: 63, end: 79 */
public void
testResolveParentThrowsUnresolvableModelExceptionWhenNoMatchingVersionFound()
    throws Exception {
    final Parent parent = new Parent();
    parent.setGroupId("ut.simple");
    parent.setArtifactId("artifact");
    parent.setVersion("[2.0,2.1)");

    try {
        this.newModelResolver().resolveModel(parent);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "No versions matched the requested parent version range '[2.0,2.1)'",
            e.getMessage());
    }
}

}
    