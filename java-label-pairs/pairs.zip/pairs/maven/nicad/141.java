
class Java_141{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/489.java, start: 110, end: 125 */
private void injectDefaultRepositories(MavenExecutionRequest request)
    throws MavenExecutionRequestPopulationException {
    Set<String> definedRepositories =
        repositorySystem.getRepoIds(request.getRemoteRepositories());

    if (!definedRepositories.contains(
            RepositorySystem.DEFAULT_REMOTE_REPO_ID)) {
        try {
            request.addRemoteRepository(
                repositorySystem.createDefaultRemoteRepository(request));
        } catch (Exception e) {
            throw new MavenExecutionRequestPopulationException(
                "Cannot create default remote repository.", e);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/489.java, start: 127, end: 142 */
private void injectDefaultPluginRepositories(MavenExecutionRequest request)
    throws MavenExecutionRequestPopulationException {
    Set<String> definedRepositories = repositorySystem.getRepoIds(
        request.getPluginArtifactRepositories());

    if (!definedRepositories.contains(
            RepositorySystem.DEFAULT_REMOTE_REPO_ID)) {
        try {
            request.addPluginArtifactRepository(
                repositorySystem.createDefaultRemoteRepository(request));
        } catch (Exception e) {
            throw new MavenExecutionRequestPopulationException(
                "Cannot create default remote repository.", e);
        }
    }
}

}
    