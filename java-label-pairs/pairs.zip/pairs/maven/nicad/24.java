
class Java_24{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1229, end: 1252 */
protected void mergeReporting_Plugins(Reporting target, Reporting source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<ReportPlugin> src = source.getPlugins();
    if (!src.isEmpty()) {
        List<ReportPlugin> tgt = target.getPlugins();
        Map<Object, ReportPlugin> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (ReportPlugin element : tgt) {
            Object key = getReportPluginKey(element);
            merged.put(key, element);
        }

        for (ReportPlugin element : src) {
            Object key = getReportPluginKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setPlugins(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2108, end: 2131 */
protected void mergeBuild_Extensions(Build target, Build source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Extension> src = source.getExtensions();
    if (!src.isEmpty()) {
        List<Extension> tgt = target.getExtensions();
        Map<Object, Extension> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Extension element : tgt) {
            Object key = getExtensionKey(element);
            merged.put(key, element);
        }

        for (Extension element : src) {
            Object key = getExtensionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExtensions(new ArrayList<>(merged.values()));
    }
}

}
    