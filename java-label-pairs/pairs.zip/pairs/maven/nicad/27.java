
class Java_27{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 679, end: 691 */
protected void mergeDistributionManagement_Repository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getRepository();
        if (tgt == null) {
            tgt = new DeploymentRepository();
            target.setRepository(tgt);
        }
        mergeDeploymentRepository(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 693, end: 705 */
protected void mergeDistributionManagement_SnapshotRepository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getSnapshotRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getSnapshotRepository();
        if (tgt == null) {
            tgt = new DeploymentRepository();
            target.setSnapshotRepository(tgt);
        }
        mergeDeploymentRepository(tgt, src, sourceDominant, context);
    }
}

}
    