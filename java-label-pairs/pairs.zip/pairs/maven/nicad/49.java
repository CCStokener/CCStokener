
class Java_49{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/828.java, start: 36, end: 66 */
public void testMissingRequiredStringArrayTypeParameter() {
    MojoDescriptor mojoDescriptor = new MojoDescriptor();
    mojoDescriptor.setGoal("goal");
    PluginDescriptor pluginDescriptor = new PluginDescriptor();
    pluginDescriptor.setGoalPrefix("goalPrefix");
    pluginDescriptor.setArtifactId("artifactId");
    mojoDescriptor.setPluginDescriptor(pluginDescriptor);

    Parameter parameter = new Parameter();
    parameter.setType("java.lang.String[]");
    parameter.setName("toAddresses");

    parameter.setRequired(true);

    PluginParameterException exception = new PluginParameterException(
        mojoDescriptor, Collections.singletonList(parameter));

    assertEquals(
        "One or more required plugin parameters are invalid/missing for 'goalPrefix:goal'\n"
            + "\n"
            +
            "[0] Inside the definition for plugin 'artifactId', specify the following:\n"
            + "\n"
            + "<configuration>\n"
            + "  ...\n"
            + "  <toAddresses>\n"
            + "    <item>VALUE</item>\n"
            + "  </toAddresses>\n"
            + "</configuration>.\n",
        exception.buildDiagnosticMessage());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/828.java, start: 68, end: 98 */
public void testMissingRequiredCollectionTypeParameter() {
    MojoDescriptor mojoDescriptor = new MojoDescriptor();
    mojoDescriptor.setGoal("goal");
    PluginDescriptor pluginDescriptor = new PluginDescriptor();
    pluginDescriptor.setGoalPrefix("goalPrefix");
    pluginDescriptor.setArtifactId("artifactId");
    mojoDescriptor.setPluginDescriptor(pluginDescriptor);

    Parameter parameter = new Parameter();
    parameter.setType("java.util.List");
    parameter.setName("toAddresses");

    parameter.setRequired(true);

    PluginParameterException exception = new PluginParameterException(
        mojoDescriptor, Collections.singletonList(parameter));

    assertEquals(
        "One or more required plugin parameters are invalid/missing for 'goalPrefix:goal'\n"
            + "\n"
            +
            "[0] Inside the definition for plugin 'artifactId', specify the following:\n"
            + "\n"
            + "<configuration>\n"
            + "  ...\n"
            + "  <toAddresses>\n"
            + "    <item>VALUE</item>\n"
            + "  </toAddresses>\n"
            + "</configuration>.\n",
        exception.buildDiagnosticMessage());
}

}
    