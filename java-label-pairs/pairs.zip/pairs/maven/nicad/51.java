
class Java_51{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2243, end: 2266 */
protected void mergeBuildBase_Resources(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    List<Resource> src = source.getResources();
    if (!src.isEmpty()) {
        List<Resource> tgt = target.getResources();
        Map<Object, Resource> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Resource element : tgt) {
            Object key = getResourceKey(element);
            merged.put(key, element);
        }

        for (Resource element : src) {
            Object key = getResourceKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setResources(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2268, end: 2292 */
protected void mergeBuildBase_TestResources(BuildBase target,
                                            BuildBase source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    List<Resource> src = source.getTestResources();
    if (!src.isEmpty()) {
        List<Resource> tgt = target.getTestResources();
        Map<Object, Resource> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Resource element : tgt) {
            Object key = getResourceKey(element);
            merged.put(key, element);
        }

        for (Resource element : src) {
            Object key = getResourceKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setTestResources(new ArrayList<>(merged.values()));
    }
}

}
    