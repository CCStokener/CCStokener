
class Java_122{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 452, end: 467 */
protected void mergeScm_Connection(Scm target, Scm source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getConnection();
    if (src != null) {
        if (sourceDominant) {
            target.setConnection(src);
            target.setLocation("connection",
                               source.getLocation("connection"));
        } else if (target.getConnection() == null) {
            target.setConnection(extrapolateChildUrl(src, context));
            target.setLocation("connection",
                               source.getLocation("connection"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 470, end: 486 */
protected void mergeScm_DeveloperConnection(Scm target, Scm source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    String src = source.getDeveloperConnection();
    if (src != null) {
        if (sourceDominant) {
            target.setDeveloperConnection(src);
            target.setLocation("developerConnection",
                               source.getLocation("developerConnection"));
        } else if (target.getDeveloperConnection() == null) {
            target.setDeveloperConnection(
                extrapolateChildUrl(src, context));
            target.setLocation("developerConnection",
                               source.getLocation("developerConnection"));
        }
    }
}

}
    