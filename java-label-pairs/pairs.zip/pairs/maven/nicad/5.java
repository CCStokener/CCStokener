
class Java_5{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 575, end: 599 */
protected void
mergeModelBase_PluginRepositories(ModelBase target, ModelBase source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    List<Repository> src = source.getPluginRepositories();
    if (!src.isEmpty()) {
        List<Repository> tgt = target.getPluginRepositories();
        Map<Object, Repository> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Repository element : tgt) {
            Object key = getRepositoryKey(element);
            merged.put(key, element);
        }

        for (Repository element : src) {
            Object key = getRepositoryKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setPluginRepositories(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2444, end: 2468 */
protected void mergePlugin_Executions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<PluginExecution> src = source.getExecutions();
    if (!src.isEmpty()) {
        List<PluginExecution> tgt = target.getExecutions();

        Map<Object, PluginExecution> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (PluginExecution element : tgt) {
            Object key = getPluginExecutionKey(element);
            merged.put(key, element);
        }

        for (PluginExecution element : src) {
            Object key = getPluginExecutionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExecutions(new ArrayList<>(merged.values()));
    }
}

}
    