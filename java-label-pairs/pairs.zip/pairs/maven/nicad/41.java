
class Java_41{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/245.java, start: 290, end: 303 */
protected void mergePlugin(Plugin target, Plugin source,
                           boolean sourceDominant,
                           Map<Object, Object> context) {
    if (source.isInherited()) {
        mergeConfigurationContainer(target, source, sourceDominant,
                                    context);
    }
    mergePlugin_GroupId(target, source, sourceDominant, context);
    mergePlugin_ArtifactId(target, source, sourceDominant, context);
    mergePlugin_Version(target, source, sourceDominant, context);
    mergePlugin_Extensions(target, source, sourceDominant, context);
    mergePlugin_Dependencies(target, source, sourceDominant, context);
    mergePlugin_Executions(target, source, sourceDominant, context);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1654, end: 1666 */
protected void mergeContributor(Contributor target, Contributor source,
                                boolean sourceDominant,
                                Map<Object, Object> context) {
    mergeContributor_Name(target, source, sourceDominant, context);
    mergeContributor_Email(target, source, sourceDominant, context);
    mergeContributor_Url(target, source, sourceDominant, context);
    mergeContributor_Organization(target, source, sourceDominant, context);
    mergeContributor_OrganizationUrl(target, source, sourceDominant,
                                     context);
    mergeContributor_Timezone(target, source, sourceDominant, context);
    mergeContributor_Roles(target, source, sourceDominant, context);
    mergeContributor_Properties(target, source, sourceDominant, context);
}

}
    