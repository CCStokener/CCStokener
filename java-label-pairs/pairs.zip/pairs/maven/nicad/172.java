
class Java_172{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 383, end: 403 */
public void testEnvarExpressionThatEvaluatesToNullReturnsTheLiteralString()
    throws Exception {
    Model model = new Model();

    Properties modelProperties = new Properties();

    modelProperties.setProperty("outputDirectory", "${env.DOES_NOT_EXIST}");

    model.setProperties(modelProperties);

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, new File("."), createModelBuildingRequest(context),
        collector);
    assertProblemFree(collector);

    assertEquals(out.getProperties().getProperty("outputDirectory"),
                 "${env.DOES_NOT_EXIST}");
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 405, end: 425 */
public void testExpressionThatEvaluatesToNullReturnsTheLiteralString()
    throws Exception {
    Model model = new Model();

    Properties modelProperties = new Properties();

    modelProperties.setProperty("outputDirectory", "${DOES_NOT_EXIST}");

    model.setProperties(modelProperties);

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, new File("."), createModelBuildingRequest(context),
        collector);
    assertProblemFree(collector);

    assertEquals(out.getProperties().getProperty("outputDirectory"),
                 "${DOES_NOT_EXIST}");
}

}
    