
class Java_125{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 322, end: 345 */
protected void mergeModel_MailingLists(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    List<MailingList> src = source.getMailingLists();
    if (!src.isEmpty()) {
        List<MailingList> tgt = target.getMailingLists();
        Map<Object, MailingList> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (MailingList element : tgt) {
            Object key = getMailingListKey(element);
            merged.put(key, element);
        }

        for (MailingList element : src) {
            Object key = getMailingListKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setMailingLists(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2268, end: 2292 */
protected void mergeBuildBase_TestResources(BuildBase target,
                                            BuildBase source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    List<Resource> src = source.getTestResources();
    if (!src.isEmpty()) {
        List<Resource> tgt = target.getTestResources();
        Map<Object, Resource> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Resource element : tgt) {
            Object key = getResourceKey(element);
            merged.put(key, element);
        }

        for (Resource element : src) {
            Object key = getResourceKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setTestResources(new ArrayList<>(merged.values()));
    }
}

}
    