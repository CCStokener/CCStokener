
class Java_12{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/737.java, start: 69, end: 82 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)obj;

    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) && version.equals(that.version);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/147.java, start: 42, end: 54 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof TypeArtifactFilter)) {
        return false;
    }

    TypeArtifactFilter other = (TypeArtifactFilter)obj;

    return type.equals(other.type);
}

}
    