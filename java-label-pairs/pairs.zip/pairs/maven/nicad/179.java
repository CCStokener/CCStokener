
class Java_179{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/269.java, start: 827, end: 844 */
private boolean validateId(String fieldName, ModelProblemCollector problems,
                           Severity severity, Version version, String id,
                           String sourceHint,
                           InputLocationTracker tracker) {
    if (!validateStringNotEmpty(fieldName, problems, severity, version, id,
                                sourceHint, tracker)) {
        return false;
    } else {
        boolean match = ID_REGEX.matcher(id).matches();
        if (!match) {
            addViolation(problems, severity, version, fieldName, sourceHint,
                         "with value '" + id +
                             "' does not match a valid id pattern.",
                         tracker);
        }
        return match;
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/269.java, start: 846, end: 864 */
private boolean validateIdWithWildcards(String fieldName,
                                        ModelProblemCollector problems,
                                        Severity severity, Version version,
                                        String id, String sourceHint,
                                        InputLocationTracker tracker) {
    if (!validateStringNotEmpty(fieldName, problems, severity, version, id,
                                sourceHint, tracker)) {
        return false;
    } else {
        boolean match = ID_WITH_WILDCARDS_REGEX.matcher(id).matches();
        if (!match) {
            addViolation(problems, severity, version, fieldName, sourceHint,
                         "with value '" + id +
                             "' does not match a valid id pattern.",
                         tracker);
        }
        return match;
    }
}

}
    