
class Java_94{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/113.java, start: 61, end: 77 */
private boolean determineVersionMatch(String version) {
    String test = version;
    boolean reverse = false;

    if (test.startsWith("!")) {
        reverse = true;
        test = test.substring(1);
    }

    boolean result = Os.isVersion(test);

    if (reverse) {
        return !result;
    } else {
        return result;
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/113.java, start: 97, end: 113 */
private boolean determineNameMatch(String name) {
    String test = name;
    boolean reverse = false;

    if (test.startsWith("!")) {
        reverse = true;
        test = test.substring(1);
    }

    boolean result = Os.isName(test);

    if (reverse) {
        return !result;
    } else {
        return result;
    }
}

}
    