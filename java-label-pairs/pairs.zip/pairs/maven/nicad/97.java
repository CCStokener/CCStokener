
class Java_97{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/888.java, start: 206, end: 218 */
public void testBuildParentVersionRangeLocallyWithoutChildVersion()
    throws Exception {
    File f1 = getTestFile(
        "src/test/resources/projects/parent-version-range-local-child-without-version/child/pom.xml");

    try {
        getProject(f1);
        fail("Expected 'ProjectBuildingException' not thrown.");
    } catch (final ProjectBuildingException e) {
        assertNotNull(e.getMessage());
        assertTrue(e.getMessage().contains("Version must be a constant"));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/888.java, start: 286, end: 299 */
public void
testBuildParentVersionRangeExternallyWithChildVersionExpression()
    throws Exception {
    File f1 = getTestFile(
        "src/test/resources/projects/parent-version-range-external-child-version-expression/pom.xml");

    try {
        this.getProjectFromRemoteRepository(f1);
        fail("Expected 'ProjectBuildingException' not thrown.");
    } catch (final ProjectBuildingException e) {
        assertNotNull(e.getMessage());
        assertTrue(e.getMessage().contains("Version must be a constant"));
    }
}

}
    