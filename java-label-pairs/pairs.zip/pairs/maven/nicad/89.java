
class Java_89{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 707, end: 719 */
protected void mergeDistributionManagement_Site(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    Site src = source.getSite();
    if (src != null) {
        Site tgt = target.getSite();
        if (tgt == null) {
            tgt = new Site();
            target.setSite(tgt);
        }
        mergeSite(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2303, end: 2315 */
protected void mergePluginConfiguration_PluginManagement(
    PluginConfiguration target, PluginConfiguration source,
    boolean sourceDominant, Map<Object, Object> context) {
    PluginManagement src = source.getPluginManagement();
    if (src != null) {
        PluginManagement tgt = target.getPluginManagement();
        if (tgt == null) {
            tgt = new PluginManagement();
            target.setPluginManagement(tgt);
        }
        mergePluginManagement(tgt, src, sourceDominant, context);
    }
}

}
    