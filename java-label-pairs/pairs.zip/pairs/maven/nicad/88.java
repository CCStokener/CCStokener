
class Java_88{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/696.java, start: 718, end: 752 */
static boolean matchesLayout(String repoLayout, String mirrorLayout) {
    boolean result = false;

    // simple checks first to short circuit processing below.
    if (StringUtils.isEmpty(mirrorLayout) ||
        WILDCARD.equals(mirrorLayout)) {
        result = true;
    } else if (mirrorLayout.equals(repoLayout)) {
        result = true;
    } else {
        // process the list
        String[] layouts = mirrorLayout.split(",");
        for (String layout : layouts) {
            // see if this is a negative match
            if (layout.length() > 1 && layout.startsWith("!")) {
                if (layout.substring(1).equals(repoLayout)) {
                    // explicitly exclude. Set result and stop processing.
                    result = false;
                    break;
                }
            }
            // check for exact match
            else if (layout.equals(repoLayout)) {
                result = true;
                break;
            } else if (WILDCARD.equals(layout)) {
                result = true;
                // don't stop processing in case a future segment explicitly
                // excludes this repo
            }
        }
    }

    return result;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/69.java, start: 148, end: 182 */
static boolean matchesLayout(String repoLayout, String mirrorLayout) {
    boolean result = false;

    // simple checks first to short circuit processing below.
    if (StringUtils.isEmpty(mirrorLayout) ||
        WILDCARD.equals(mirrorLayout)) {
        result = true;
    } else if (mirrorLayout.equals(repoLayout)) {
        result = true;
    } else {
        // process the list
        String[] layouts = mirrorLayout.split(",");
        for (String layout : layouts) {
            // see if this is a negative match
            if (layout.length() > 1 && layout.startsWith("!")) {
                if (layout.substring(1).equals(repoLayout)) {
                    // explicitly exclude. Set result and stop processing.
                    result = false;
                    break;
                }
            }
            // check for exact match
            else if (layout.equals(repoLayout)) {
                result = true;
                break;
            } else if (WILDCARD.equals(layout)) {
                result = true;
                // don't stop processing in case a future segment explicitly
                // excludes this repo
            }
        }
    }

    return result;
}

}
    