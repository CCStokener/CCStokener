
class Java_153{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 72, end: 88 */
public void
testResolveParentThrowsUnresolvableModelExceptionWhenNoMatchingVersionFound()
    throws Exception {
    final Parent parent = new Parent();
    parent.setGroupId("org.apache");
    parent.setArtifactId("apache");
    parent.setVersion("[2.0,2.1)");

    try {
        this.newModelResolver().resolveModel(parent);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "No versions matched the requested parent version range '[2.0,2.1)'",
            e.getMessage());
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/477.java, start: 159, end: 175 */
public void
testResolveDependencyThrowsUnresolvableModelExceptionWhenUsingRangesWithoutUpperBound()
    throws Exception {
    final Dependency dependency = new Dependency();
    dependency.setGroupId("ut.simple");
    dependency.setArtifactId("artifact");
    dependency.setVersion("[1.0,)");

    try {
        this.newModelResolver().resolveModel(dependency);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "The requested dependency version range '[1.0,)' does not specify an upper bound",
            e.getMessage());
    }
}

}
    