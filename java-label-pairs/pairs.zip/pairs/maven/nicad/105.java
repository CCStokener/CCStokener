
class Java_105{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/466.java, start: 67, end: 83 */
public Collection<? extends Metadata>
prepare(Collection<? extends Artifact> artifacts) {
    for (Artifact artifact : artifacts) {
        if (artifact.isSnapshot()) {
            Object key = RemoteSnapshotMetadata.getKey(artifact);
            RemoteSnapshotMetadata snapshotMetadata = snapshots.get(key);
            if (snapshotMetadata == null) {
                snapshotMetadata =
                    new RemoteSnapshotMetadata(artifact, legacyFormat);
                snapshots.put(key, snapshotMetadata);
            }
            snapshotMetadata.bind(artifact);
        }
    }

    return snapshots.values();
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/452.java, start: 50, end: 66 */
public Collection<? extends Metadata>
prepare(Collection<? extends Artifact> artifacts) {
    for (Artifact artifact : artifacts) {
        if (artifact.isSnapshot()) {
            Object key = LocalSnapshotMetadata.getKey(artifact);
            LocalSnapshotMetadata snapshotMetadata = snapshots.get(key);
            if (snapshotMetadata == null) {
                snapshotMetadata =
                    new LocalSnapshotMetadata(artifact, legacyFormat);
                snapshots.put(key, snapshotMetadata);
            }
            snapshotMetadata.bind(artifact);
        }
    }

    return Collections.emptyList();
}

}
    