
class Java_0{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/113.java, start: 79, end: 95 */
private boolean determineArchMatch(String arch) {
    String test = arch;
    boolean reverse = false;

    if (test.startsWith("!")) {
        reverse = true;
        test = test.substring(1);
    }

    boolean result = Os.isArch(test);

    if (reverse) {
        return !result;
    } else {
        return result;
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/113.java, start: 115, end: 131 */
private boolean determineFamilyMatch(String family) {
    String test = family;
    boolean reverse = false;

    if (test.startsWith("!")) {
        reverse = true;
        test = test.substring(1);
    }

    boolean result = Os.isFamily(test);

    if (reverse) {
        return !result;
    } else {
        return result;
    }
}

}
    