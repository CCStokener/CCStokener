
class Java_115{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 542, end: 572 */
protected void mergeReportPlugin_ReportSets(ReportPlugin target,
                                            ReportPlugin source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    List<ReportSet> src = source.getReportSets();
    if (!src.isEmpty()) {
        List<ReportSet> tgt = target.getReportSets();
        Map<Object, ReportSet> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (ReportSet rset : src) {
            if (sourceDominant ||
                (rset.getInherited() != null ? rset.isInherited()
                                             : source.isInherited())) {
                Object key = getReportSetKey(rset);
                merged.put(key, rset);
            }
        }

        for (ReportSet element : tgt) {
            Object key = getReportSetKey(element);
            ReportSet existing = merged.get(key);
            if (existing != null) {
                mergeReportSet(element, existing, sourceDominant, context);
            }
            merged.put(key, element);
        }

        target.setReportSets(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2243, end: 2266 */
protected void mergeBuildBase_Resources(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    List<Resource> src = source.getResources();
    if (!src.isEmpty()) {
        List<Resource> tgt = target.getResources();
        Map<Object, Resource> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Resource element : tgt) {
            Object key = getResourceKey(element);
            merged.put(key, element);
        }

        for (Resource element : src) {
            Object key = getResourceKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setResources(new ArrayList<>(merged.values()));
    }
}

}
    