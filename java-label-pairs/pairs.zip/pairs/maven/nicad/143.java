
class Java_143{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 601, end: 614 */
protected void
mergeModelBase_DistributionManagement(ModelBase target, ModelBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    DistributionManagement src = source.getDistributionManagement();
    if (src != null) {
        DistributionManagement tgt = target.getDistributionManagement();
        if (tgt == null) {
            tgt = new DistributionManagement();
            target.setDistributionManagement(tgt);
        }
        mergeDistributionManagement(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 890, end: 903 */
protected void mergeRepository_Snapshots(Repository target,
                                         Repository source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    RepositoryPolicy src = source.getSnapshots();
    if (src != null) {
        RepositoryPolicy tgt = target.getSnapshots();
        if (tgt == null) {
            tgt = new RepositoryPolicy();
            target.setSnapshots(tgt);
        }
        mergeRepositoryPolicy(tgt, src, sourceDominant, context);
    }
}

}
    