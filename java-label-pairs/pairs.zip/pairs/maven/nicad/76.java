
class Java_76{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 255, end: 291 */
public void testShouldNotInterpolateDependencyVersionWithInvalidReference()
    throws Exception {
    Model model = new Model();
    model.setVersion("3.8.1");

    Dependency dep = new Dependency();
    dep.setVersion("${something}");

    model.addDependency(dep);

    /*
     // This is the desired behaviour, however there are too many crappy
     poms in the repo and an issue with the
     // timing of executing the interpolation

     try
     {
     new RegexBasedModelInterpolator().interpolate( model, context );
     fail( "Should have failed to interpolate with invalid reference" );
     }
     catch ( ModelInterpolationException expected )
     {
     assertTrue( true );
     }
     */

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, new File("."), createModelBuildingRequest(context),
        collector);
    assertProblemFree(collector);

    assertEquals("${something}",
                 (out.getDependencies().get(0)).getVersion());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 314, end: 334 */
public void testBasedir() throws Exception {
    Model model = new Model();
    model.setVersion("3.8.1");
    model.setArtifactId("foo");

    Repository repository = new Repository();

    repository.setUrl("file://localhost/${basedir}/temp-repo");

    model.addRepository(repository);

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, null, createModelBuildingRequest(context), collector);
    assertProblemFree(collector);

    assertEquals("file://localhost/myBasedir/temp-repo",
                 (out.getRepositories().get(0)).getUrl());
}

}
    