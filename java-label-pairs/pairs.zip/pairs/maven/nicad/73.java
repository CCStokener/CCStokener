
class Java_73{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/737.java, start: 69, end: 82 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)obj;

    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) && version.equals(that.version);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/146.java, start: 43, end: 55 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof InversionArtifactFilter)) {
        return false;
    }

    InversionArtifactFilter other = (InversionArtifactFilter)obj;

    return toInvert.equals(other.toInvert);
}

}
    