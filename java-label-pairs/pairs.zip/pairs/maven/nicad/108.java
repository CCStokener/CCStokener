
class Java_108{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 147, end: 165 */
public void testShouldNotThrowExceptionOnReferenceToNonExistentValue()
    throws Exception {
    Model model = new Model();

    Scm scm = new Scm();
    scm.setConnection("${test}/somepath");

    model.setScm(scm);

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, new File("."), createModelBuildingRequest(context),
        collector);

    assertProblemFree(collector);
    assertEquals("${test}/somepath", out.getScm().getConnection());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/348.java, start: 255, end: 291 */
public void testShouldNotInterpolateDependencyVersionWithInvalidReference()
    throws Exception {
    Model model = new Model();
    model.setVersion("3.8.1");

    Dependency dep = new Dependency();
    dep.setVersion("${something}");

    model.addDependency(dep);

    /*
     // This is the desired behaviour, however there are too many crappy
     poms in the repo and an issue with the
     // timing of executing the interpolation

     try
     {
     new RegexBasedModelInterpolator().interpolate( model, context );
     fail( "Should have failed to interpolate with invalid reference" );
     }
     catch ( ModelInterpolationException expected )
     {
     assertTrue( true );
     }
     */

    ModelInterpolator interpolator = createInterpolator();

    final SimpleProblemCollector collector = new SimpleProblemCollector();
    Model out = interpolator.interpolateModel(
        model, new File("."), createModelBuildingRequest(context),
        collector);
    assertProblemFree(collector);

    assertEquals("${something}",
                 (out.getDependencies().get(0)).getVersion());
}

}
    