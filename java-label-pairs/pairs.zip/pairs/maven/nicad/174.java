
class Java_174{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 168, end: 184 */
public void
testResolveDependencyThrowsUnresolvableModelExceptionWhenUsingRangesWithoutUpperBound()
    throws Exception {
    final Dependency dependency = new Dependency();
    dependency.setGroupId("org.apache");
    dependency.setArtifactId("apache");
    dependency.setVersion("[1,)");

    try {
        this.newModelResolver().resolveModel(dependency);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "The requested dependency version range '[1,)' does not specify an upper bound",
            e.getMessage());
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/477.java, start: 63, end: 79 */
public void
testResolveParentThrowsUnresolvableModelExceptionWhenNoMatchingVersionFound()
    throws Exception {
    final Parent parent = new Parent();
    parent.setGroupId("ut.simple");
    parent.setArtifactId("artifact");
    parent.setVersion("[2.0,2.1)");

    try {
        this.newModelResolver().resolveModel(parent);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "No versions matched the requested parent version range '[2.0,2.1)'",
            e.getMessage());
    }
}

}
    