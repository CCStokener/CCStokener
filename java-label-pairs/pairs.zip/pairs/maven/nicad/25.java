
class Java_25{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 616, end: 628 */
protected void mergeModelBase_Reporting(ModelBase target, ModelBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    Reporting src = source.getReporting();
    if (src != null) {
        Reporting tgt = target.getReporting();
        if (tgt == null) {
            tgt = new Reporting();
            target.setReporting(tgt);
        }
        mergeReporting(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 693, end: 705 */
protected void mergeDistributionManagement_SnapshotRepository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getSnapshotRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getSnapshotRepository();
        if (tgt == null) {
            tgt = new DeploymentRepository();
            target.setSnapshotRepository(tgt);
        }
        mergeDeploymentRepository(tgt, src, sourceDominant, context);
    }
}

}
    