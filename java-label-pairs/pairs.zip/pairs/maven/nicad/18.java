
class Java_18{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 397, end: 409 */
protected void mergeModel_IssueManagement(Model target, Model source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    IssueManagement src = source.getIssueManagement();
    if (src != null) {
        IssueManagement tgt = target.getIssueManagement();
        if (tgt == null) {
            tgt = new IssueManagement();
            target.setIssueManagement(tgt);
        }
        mergeIssueManagement(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 679, end: 691 */
protected void mergeDistributionManagement_Repository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getRepository();
        if (tgt == null) {
            tgt = new DeploymentRepository();
            target.setRepository(tgt);
        }
        mergeDeploymentRepository(tgt, src, sourceDominant, context);
    }
}

}
    