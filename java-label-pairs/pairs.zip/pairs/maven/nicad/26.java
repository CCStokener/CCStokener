
class Java_26{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/253.java, start: 126, end: 153 */
protected void mergePlugin_Executions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<PluginExecution> src = source.getExecutions();
    if (!src.isEmpty()) {
        List<PluginExecution> tgt = target.getExecutions();
        Map<Object, PluginExecution> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (PluginExecution element : tgt) {
            Object key = getPluginExecutionKey(element);
            merged.put(key, element);
        }

        for (PluginExecution element : src) {
            Object key = getPluginExecutionKey(element);
            PluginExecution existing = merged.get(key);
            if (existing != null) {
                mergePluginExecution(existing, element, sourceDominant,
                                     context);
            } else {
                merged.put(key, element);
            }
        }

        target.setExecutions(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1903, end: 1927 */
protected void mergeCiManagement_Notifiers(CiManagement target,
                                           CiManagement source,
                                           boolean sourceDominant,
                                           Map<Object, Object> context) {
    List<Notifier> src = source.getNotifiers();
    if (!src.isEmpty()) {
        List<Notifier> tgt = target.getNotifiers();
        Map<Object, Notifier> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Notifier element : tgt) {
            Object key = getNotifierKey(element);
            merged.put(key, element);
        }

        for (Notifier element : src) {
            Object key = getNotifierKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setNotifiers(new ArrayList<>(merged.values()));
    }
}

}
    