
class Java_72{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 127, end: 140 */
protected void mergeModel_IssueManagement(Model target, Model source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    IssueManagement src = source.getIssueManagement();
    if (src != null) {
        IssueManagement tgt = target.getIssueManagement();
        if (tgt == null) {
            tgt = new IssueManagement();
            tgt.setLocation("", src.getLocation(""));
            target.setIssueManagement(tgt);
            mergeIssueManagement(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 389, end: 402 */
protected void mergeDistributionManagement_SnapshotRepository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getSnapshotRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getSnapshotRepository();
        if (sourceDominant || tgt == null) {
            tgt = new DeploymentRepository();
            tgt.setLocation("", src.getLocation(""));
            target.setSnapshotRepository(tgt);
            mergeDeploymentRepository(tgt, src, sourceDominant, context);
        }
    }
}

}
    