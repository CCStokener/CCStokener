
class Java_83{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 297, end: 320 */
protected void mergeModel_Licenses(Model target, Model source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    List<License> src = source.getLicenses();
    if (!src.isEmpty()) {
        List<License> tgt = target.getLicenses();
        Map<Object, License> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (License element : tgt) {
            Object key = getLicenseKey(element);
            merged.put(key, element);
        }

        for (License element : src) {
            Object key = getLicenseKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setLicenses(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2419, end: 2442 */
protected void mergePlugin_Dependencies(Plugin target, Plugin source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    List<Dependency> src = source.getDependencies();
    if (!src.isEmpty()) {
        List<Dependency> tgt = target.getDependencies();
        Map<Object, Dependency> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Dependency element : tgt) {
            Object key = getDependencyKey(element);
            merged.put(key, element);
        }

        for (Dependency element : src) {
            Object key = getDependencyKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setDependencies(new ArrayList<>(merged.values()));
    }
}

}
    