
class Java_138{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/787.java, start: 61, end: 73 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof ExclusionSetFilter)) {
        return false;
    }

    ExclusionSetFilter other = (ExclusionSetFilter)obj;

    return excludes.equals(other.excludes);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/786.java, start: 96, end: 108 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CumulativeScopeArtifactFilter)) {
        return false;
    }

    CumulativeScopeArtifactFilter that = (CumulativeScopeArtifactFilter)obj;

    return scopes.equals(that.scopes);
}

}
    