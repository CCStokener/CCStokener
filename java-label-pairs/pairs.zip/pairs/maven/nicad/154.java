
class Java_154{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 397, end: 409 */
protected void mergeModel_IssueManagement(Model target, Model source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    IssueManagement src = source.getIssueManagement();
    if (src != null) {
        IssueManagement tgt = target.getIssueManagement();
        if (tgt == null) {
            tgt = new IssueManagement();
            target.setIssueManagement(tgt);
        }
        mergeIssueManagement(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 707, end: 719 */
protected void mergeDistributionManagement_Site(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    Site src = source.getSite();
    if (src != null) {
        Site tgt = target.getSite();
        if (tgt == null) {
            tgt = new Site();
            target.setSite(tgt);
        }
        mergeSite(tgt, src, sourceDominant, context);
    }
}

}
    