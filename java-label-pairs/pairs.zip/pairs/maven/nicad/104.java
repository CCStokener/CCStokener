
class Java_104{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/253.java, start: 156, end: 184 */
protected void mergeReporting_Plugins(Reporting target,
                                      Reporting source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<ReportPlugin> src = source.getPlugins();
    if (!src.isEmpty()) {
        List<ReportPlugin> tgt = target.getPlugins();
        Map<Object, ReportPlugin> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (ReportPlugin element : tgt) {
            Object key = getReportPluginKey(element);
            merged.put(key, element);
        }

        for (ReportPlugin element : src) {
            Object key = getReportPluginKey(element);
            ReportPlugin existing = merged.get(key);
            if (existing == null) {
                merged.put(key, element);
            } else {
                mergeReportPlugin(existing, element, sourceDominant,
                                  context);
            }
        }

        target.setPlugins(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 575, end: 599 */
protected void
mergeModelBase_PluginRepositories(ModelBase target, ModelBase source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    List<Repository> src = source.getPluginRepositories();
    if (!src.isEmpty()) {
        List<Repository> tgt = target.getPluginRepositories();
        Map<Object, Repository> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Repository element : tgt) {
            Object key = getRepositoryKey(element);
            merged.put(key, element);
        }

        for (Repository element : src) {
            Object key = getRepositoryKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setPluginRepositories(new ArrayList<>(merged.values()));
    }
}

}
    