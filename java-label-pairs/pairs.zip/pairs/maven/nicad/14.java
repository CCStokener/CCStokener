
class Java_14{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/427.java, start: 84, end: 107 */
public void testValidateMirror() throws Exception {
    Settings settings = new Settings();
    Mirror mirror = new Mirror();
    mirror.setId("local");
    settings.addMirror(mirror);
    mirror = new Mirror();
    mirror.setId("illegal\\:/chars");
    mirror.setUrl("http://void");
    mirror.setMirrorOf("void");
    settings.addMirror(mirror);

    SimpleProblemCollector problems = new SimpleProblemCollector();
    validator.validate(settings, problems);
    assertEquals(4, problems.messages.size());
    assertContains(problems.messages.get(0),
                   "'mirrors.mirror.id' must not be 'local'");
    assertContains(problems.messages.get(1),
                   "'mirrors.mirror.url' for local is missing");
    assertContains(problems.messages.get(2),
                   "'mirrors.mirror.mirrorOf' for local is missing");
    assertContains(
        problems.messages.get(3),
        "'mirrors.mirror.id' must not contain any of these characters");
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/427.java, start: 169, end: 190 */
public void testValidateUniqueRepositoryId() throws Exception {
    Settings settings = new Settings();
    Profile profile = new Profile();
    profile.setId("pro");
    settings.addProfile(profile);
    Repository repo1 = new Repository();
    repo1.setUrl("http://apache.org/");
    repo1.setId("test");
    profile.addRepository(repo1);
    Repository repo2 = new Repository();
    repo2.setUrl("http://apache.org/");
    repo2.setId("test");
    profile.addRepository(repo2);

    SimpleProblemCollector problems = new SimpleProblemCollector();
    validator.validate(settings, problems);
    assertEquals(1, problems.messages.size());
    assertContains(
        problems.messages.get(0),
        "'profiles.profile[pro].repositories.repository.id' must be unique"
            + " but found duplicate repository with id test");
}

}
    