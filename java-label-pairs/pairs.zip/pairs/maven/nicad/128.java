
class Java_128{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 489, end: 519 */
protected void mergePlugin_Executions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<PluginExecution> src = source.getExecutions();
    if (!src.isEmpty()) {
        List<PluginExecution> tgt = target.getExecutions();
        Map<Object, PluginExecution> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (PluginExecution element : src) {
            if (sourceDominant ||
                (element.getInherited() != null ? element.isInherited()
                                                : source.isInherited())) {
                Object key = getPluginExecutionKey(element);
                merged.put(key, element);
            }
        }

        for (PluginExecution element : tgt) {
            Object key = getPluginExecutionKey(element);
            PluginExecution existing = merged.get(key);
            if (existing != null) {
                mergePluginExecution(element, existing, sourceDominant,
                                     context);
            }
            merged.put(key, element);
        }

        target.setExecutions(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1229, end: 1252 */
protected void mergeReporting_Plugins(Reporting target, Reporting source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<ReportPlugin> src = source.getPlugins();
    if (!src.isEmpty()) {
        List<ReportPlugin> tgt = target.getPlugins();
        Map<Object, ReportPlugin> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (ReportPlugin element : tgt) {
            Object key = getReportPluginKey(element);
            merged.put(key, element);
        }

        for (ReportPlugin element : src) {
            Object key = getReportPluginKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setPlugins(new ArrayList<>(merged.values()));
    }
}

}
    