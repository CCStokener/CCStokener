
class Java_79{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/266.java, start: 171, end: 194 */
private Xpp3Dom convert(ReportPlugin plugin) {
    Xpp3Dom dom = new Xpp3Dom("reportPlugin");

    addDom(dom, "groupId", plugin.getGroupId());
    addDom(dom, "artifactId", plugin.getArtifactId());
    addDom(dom, "version", plugin.getVersion());

    Xpp3Dom configuration = (Xpp3Dom)plugin.getConfiguration();
    if (configuration != null) {
        configuration = new Xpp3Dom(configuration);
        dom.addChild(configuration);
    }

    if (!plugin.getReportSets().isEmpty()) {
        Xpp3Dom reportSets = new Xpp3Dom("reportSets");
        for (ReportSet reportSet : plugin.getReportSets()) {
            Xpp3Dom rs = convert(reportSet);
            reportSets.addChild(rs);
        }
        dom.addChild(reportSets);
    }

    return dom;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/266.java, start: 196, end: 216 */
private Xpp3Dom convert(ReportSet reportSet) {
    Xpp3Dom dom = new Xpp3Dom("reportSet");

    addDom(dom, "id", reportSet.getId());

    Xpp3Dom configuration = (Xpp3Dom)reportSet.getConfiguration();
    if (configuration != null) {
        configuration = new Xpp3Dom(configuration);
        dom.addChild(configuration);
    }

    if (!reportSet.getReports().isEmpty()) {
        Xpp3Dom reports = new Xpp3Dom("reports");
        for (String report : reportSet.getReports()) {
            addDom(reports, "report", report);
        }
        dom.addChild(reports);
    }

    return dom;
}

}
    