
class Java_82{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/680.java, start: 46, end: 66 */
public File translatePath(File path) {
    File result = path;

    if (path != null && basedir != null) {
        if (path.isAbsolute()) {
            // path is already absolute, we're done
        } else if (path.getPath().startsWith(File.separator)) {
            // drive-relative Windows path, don't align with base dir but
            // with drive root
            result = path.getAbsoluteFile();
        } else {
            // an ordinary relative path, align with base dir
            result =
                new File(
                    new File(basedir, path.getPath()).toURI().normalize())
                    .getAbsoluteFile();
        }
    }

    return result;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/563.java, start: 404, end: 424 */
public File alignToBaseDirectory(File file) {
    // TODO Copied from the DefaultInterpolator. We likely want to resurrect
    // the PathTranslator or at least a similar component for re-usage
    if (file != null) {
        if (file.isAbsolute()) {
            // path was already absolute, just normalize file separator and
            // we're done
        } else if (file.getPath().startsWith(File.separator)) {
            // drive-relative Windows path, don't align with project
            // directory but with drive root
            file = file.getAbsoluteFile();
        } else {
            // an ordinary relative path, align with project directory
            file =
                new File(
                    new File(basedir, file.getPath()).toURI().normalize())
                    .getAbsoluteFile();
        }
    }
    return file;
}

}
    