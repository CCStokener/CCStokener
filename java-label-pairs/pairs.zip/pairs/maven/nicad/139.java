
class Java_139{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/313.java, start: 94, end: 121 */
protected void mergePlugin_Executions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    List<PluginExecution> src = source.getExecutions();
    if (!src.isEmpty()) {
        List<PluginExecution> tgt = target.getExecutions();

        Map<Object, PluginExecution> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (PluginExecution element : src) {
            Object key = getPluginExecutionKey(element);
            merged.put(key, element.clone());
        }

        for (PluginExecution element : tgt) {
            Object key = getPluginExecutionKey(element);
            PluginExecution existing = merged.get(key);
            if (existing != null) {
                mergePluginExecution(element, existing, sourceDominant,
                                     context);
            }
            merged.put(key, element);
        }

        target.setExecutions(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 347, end: 370 */
protected void mergeModel_Developers(Model target, Model source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Developer> src = source.getDevelopers();
    if (!src.isEmpty()) {
        List<Developer> tgt = target.getDevelopers();
        Map<Object, Developer> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Developer element : tgt) {
            Object key = getDeveloperKey(element);
            merged.put(key, element);
        }

        for (Developer element : src) {
            Object key = getDeveloperKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setDevelopers(new ArrayList<>(merged.values()));
    }
}

}
    