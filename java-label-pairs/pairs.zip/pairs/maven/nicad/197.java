
class Java_197{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/737.java, start: 69, end: 82 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)obj;

    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) && version.equals(that.version);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/588.java, start: 115, end: 134 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)o;

    return parentRealm == that.parentRealm &&
        CacheUtils.pluginEquals(plugin, that.plugin) &&
        eq(workspace, that.workspace) &&
        eq(localRepo, that.localRepo) &&
        CacheUtils.repositoriesEquals(this.repositories,
                                      that.repositories) &&
        eq(filter, that.filter) &&
        eq(foreignImports, that.foreignImports);
}

}
    