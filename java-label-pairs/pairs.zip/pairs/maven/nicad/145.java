
class Java_145{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/180.java, start: 51, end: 77 */
public void testArtifact() throws Exception {
    ArtifactRepository remoteRepository = remoteRepository();

    ArtifactRepository localRepository = localRepository();

    Artifact a = createArtifact("a", "0.0.1-SNAPSHOT");
    File file =
        new File(localRepository.getBasedir(), localRepository.pathOf(a));
    file.delete();
    a.setFile(file);

    File touchFile = updateCheckManager.getTouchfile(a);
    touchFile.delete();

    assertTrue(updateCheckManager.isUpdateRequired(a, remoteRepository));

    file.getParentFile().mkdirs();
    file.createNewFile();
    updateCheckManager.touch(a, remoteRepository, null);

    assertFalse(updateCheckManager.isUpdateRequired(a, remoteRepository));

    assertNull(updateCheckManager.readLastUpdated(
        touchFile, updateCheckManager.getRepositoryKey(remoteRepository)));

    assertFalse(updateCheckManager.getTouchfile(a).exists());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/180.java, start: 79, end: 102 */
public void testMissingArtifact() throws Exception {
    ArtifactRepository remoteRepository = remoteRepository();

    ArtifactRepository localRepository = localRepository();

    Artifact a = createArtifact("a", "0.0.1-SNAPSHOT");
    File file =
        new File(localRepository.getBasedir(), localRepository.pathOf(a));
    file.delete();
    a.setFile(file);

    File touchFile = updateCheckManager.getTouchfile(a);
    touchFile.delete();

    assertTrue(updateCheckManager.isUpdateRequired(a, remoteRepository));

    updateCheckManager.touch(a, remoteRepository, null);

    assertFalse(updateCheckManager.isUpdateRequired(a, remoteRepository));

    assertFalse(file.exists());
    assertNotNull(updateCheckManager.readLastUpdated(
        touchFile, updateCheckManager.getRepositoryKey(remoteRepository)));
}

}
    