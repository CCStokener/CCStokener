
class Java_154{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2394, end: 2404 */
protected void mergePlugin_Version(Plugin target, Plugin source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2480, end: 2491 */
protected void mergeConfigurationContainer_Inherited(
    ConfigurationContainer target, ConfigurationContainer source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getInherited();
    if (src != null) {
        if (sourceDominant || target.getInherited() == null) {
            target.setInherited(src);
            target.setLocation("inherited",
                               source.getLocation("inherited"));
        }
    }
}

}
    