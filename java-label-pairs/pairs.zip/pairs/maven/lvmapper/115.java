
class Java_115{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/801.java, start: 68, end: 74 */
public MetadataParseException(String message, int lineNumber,
                              int columnNumber, Throwable cause) {
    super(message);
    initCause(cause);
    this.lineNumber = lineNumber;
    this.columnNumber = columnNumber;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/423.java, start: 68, end: 74 */
public SettingsParseException(String message, int lineNumber,
                              int columnNumber, Throwable cause) {
    super(message);
    initCause(cause);
    this.lineNumber = lineNumber;
    this.columnNumber = columnNumber;
}

}
    