
class Java_65{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 334, end: 343 */
public MavenExecutionRequest
setRemoteRepositories(List<ArtifactRepository> remoteRepositories) {
    if (remoteRepositories != null) {
        this.remoteRepositories = new ArrayList<>(remoteRepositories);
    } else {
        this.remoteRepositories = null;
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/301.java, start: 127, end: 136 */
public DefaultModelBuildingResult
setActiveExternalProfiles(List<Profile> activeProfiles) {
    if (activeProfiles != null) {
        this.activeExternalProfiles = new ArrayList<>(activeProfiles);
    } else {
        this.activeExternalProfiles.clear();
    }

    return this;
}

}
    