
class Java_137{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1430, end: 1440 */
protected void mergeParent_Version(Parent target, Parent source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1877, end: 1888 */
protected void mergeCiManagement_System(CiManagement target,
                                        CiManagement source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getSystem();
    if (src != null) {
        if (sourceDominant || target.getSystem() == null) {
            target.setSystem(src);
            target.setLocation("system", source.getLocation("system"));
        }
    }
}

}
    