
class Java_120{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 334, end: 343 */
public MavenExecutionRequest
setRemoteRepositories(List<ArtifactRepository> remoteRepositories) {
    if (remoteRepositories != null) {
        this.remoteRepositories = new ArrayList<>(remoteRepositories);
    } else {
        this.remoteRepositories = null;
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 796, end: 804 */
public MavenExecutionRequest setPluginGroups(List<String> pluginGroups) {
    if (pluginGroups != null) {
        this.pluginGroups = new ArrayList<>(pluginGroups);
    } else {
        this.pluginGroups = null;
    }

    return this;
}

}
    