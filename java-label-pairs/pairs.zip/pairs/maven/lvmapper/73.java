
class Java_73{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 843, end: 853 */
protected void mergeSite_Name(Site target, Site source,
                              boolean sourceDominant,
                              Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1845, end: 1856 */
protected void mergeScm_DeveloperConnection(Scm target, Scm source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    String src = source.getDeveloperConnection();
    if (src != null) {
        if (sourceDominant || target.getDeveloperConnection() == null) {
            target.setDeveloperConnection(src);
            target.setLocation("developerConnection",
                               source.getLocation("developerConnection"));
        }
    }
}

}
    