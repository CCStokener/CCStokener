
class Java_105{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 195, end: 206 */
protected void mergeModel_ArtifactId(Model target, Model source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1858, end: 1867 */
protected void mergeScm_Tag(Scm target, Scm source, boolean sourceDominant,
                            Map<Object, Object> context) {
    String src = source.getTag();
    if (src != null) {
        if (sourceDominant || target.getTag() == null) {
            target.setTag(src);
            target.setLocation("tag", source.getLocation("tag"));
        }
    }
}

}
    