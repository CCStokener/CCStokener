
class Java_38{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 283, end: 295 */
protected void mergeModel_Organization(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    Organization src = source.getOrganization();
    if (src != null) {
        Organization tgt = target.getOrganization();
        if (tgt == null) {
            tgt = new Organization();
            target.setOrganization(tgt);
        }
        mergeOrganization(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1941, end: 1950 */
protected void mergeNotifier_Type(Notifier target, Notifier source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    String src = source.getType();
    if (src != null) {
        if (sourceDominant || target.getType() == null) {
            target.setType(src);
        }
    }
}

}
    