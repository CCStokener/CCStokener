
class Java_39{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 346, end: 356 */
public MavenExecutionRequest setPluginArtifactRepositories(
    List<ArtifactRepository> pluginArtifactRepositories) {
    if (pluginArtifactRepositories != null) {
        this.pluginArtifactRepositories =
            new ArrayList<>(pluginArtifactRepositories);
    } else {
        this.pluginArtifactRepositories = null;
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 674, end: 682 */
public MavenExecutionRequest setProxies(List<Proxy> proxies) {
    if (proxies != null) {
        this.proxies = new ArrayList<>(proxies);
    } else {
        this.proxies = null;
    }

    return this;
}

}
    