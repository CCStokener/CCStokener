
class Java_5{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1264, end: 1275 */
protected void mergeReportPlugin_GroupId(ReportPlugin target,
                                         ReportPlugin source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1596, end: 1606 */
protected void mergeMailingList_Post(MailingList target, MailingList source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getPost();
    if (src != null) {
        if (sourceDominant || target.getPost() == null) {
            target.setPost(src);
            target.setLocation("post", source.getLocation("post"));
        }
    }
}

}
    