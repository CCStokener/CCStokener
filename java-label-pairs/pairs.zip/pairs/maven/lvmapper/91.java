
class Java_91{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 666, end: 671 */
public List<Proxy> getProxies() {
    if (proxies == null) {
        proxies = new ArrayList<>();
    }
    return proxies;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 914, end: 919 */
public List<ArtifactRepository> getRemoteRepositories() {
    if (remoteRepositories == null) {
        remoteRepositories = new ArrayList<>();
    }
    return remoteRepositories;
}

}
    