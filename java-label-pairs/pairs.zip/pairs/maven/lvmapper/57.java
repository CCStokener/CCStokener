
class Java_57{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 364, end: 369 */
public List<String> getActiveProfiles() {
    if (activeProfiles == null) {
        activeProfiles = new ArrayList<>();
    }
    return activeProfiles;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/292.java, start: 199, end: 205 */
public List<String> getActiveProfileIds() {
    if (activeProfileIds == null) {
        activeProfileIds = new ArrayList<>();
    }

    return activeProfileIds;
}

}
    