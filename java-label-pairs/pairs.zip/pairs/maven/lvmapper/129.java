
class Java_129{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 721, end: 731 */
protected void mergeDistributionManagement_Status(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getStatus();
    if (src != null) {
        if (sourceDominant || target.getStatus() == null) {
            target.setStatus(src);
            target.setLocation("status", source.getLocation("status"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1277, end: 1289 */
protected void mergeReportPlugin_ArtifactId(ReportPlugin target,
                                            ReportPlugin source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}

}
    