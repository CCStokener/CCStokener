
class Java_61{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/743.java, start: 86, end: 92 */
public List<ModelProblem> getProblems() {
    if (problems == null) {
        problems = new ArrayList<>();
    }

    return problems;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 768, end: 773 */
public List<Profile> getProfiles() {
    if (profiles == null) {
        profiles = new ArrayList<>();
    }
    return profiles;
}

}
    