
class Java_181{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1534, end: 1544 */
protected void mergeLicense_Comments(License target, License source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getComments();
    if (src != null) {
        if (sourceDominant || target.getComments() == null) {
            target.setComments(src);
            target.setLocation("comments", source.getLocation("comments"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2153, end: 2164 */
protected void mergeExtension_ArtifactId(Extension target, Extension source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}

}
    