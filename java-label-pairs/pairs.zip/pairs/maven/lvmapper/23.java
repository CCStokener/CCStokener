
class Java_23{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/888.java, start: 266, end: 278 */
public void testBuildParentVersionRangeExternallyWithoutChildVersion()
    throws Exception {
    File f1 = getTestFile(
        "src/test/resources/projects/parent-version-range-external-child-without-version/pom.xml");

    try {
        this.getProjectFromRemoteRepository(f1);
        fail("Expected 'ProjectBuildingException' not thrown.");
    } catch (final ProjectBuildingException e) {
        assertNotNull(e.getMessage());
        assertTrue(e.getMessage().contains("Version must be a constant"));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/888.java, start: 286, end: 299 */
public void
testBuildParentVersionRangeExternallyWithChildVersionExpression()
    throws Exception {
    File f1 = getTestFile(
        "src/test/resources/projects/parent-version-range-external-child-version-expression/pom.xml");

    try {
        this.getProjectFromRemoteRepository(f1);
        fail("Expected 'ProjectBuildingException' not thrown.");
    } catch (final ProjectBuildingException e) {
        assertNotNull(e.getMessage());
        assertTrue(e.getMessage().contains("Version must be a constant"));
    }
}

}
    