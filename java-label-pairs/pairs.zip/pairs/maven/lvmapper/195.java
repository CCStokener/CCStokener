
class Java_195{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/217.java, start: 179, end: 198 */
public void testShouldInheritOnePluginWithExecution() {
    Plugin parent = new Plugin();
    parent.setArtifactId("testArtifact");
    parent.setGroupId("testGroup");
    parent.setVersion("1.0");

    PluginExecution parentExecution = new PluginExecution();
    parentExecution.setId("testExecution");

    parent.addExecution(parentExecution);

    Plugin child = new Plugin();
    child.setArtifactId("testArtifact");
    child.setGroupId("testGroup");
    child.setVersion("1.0");

    ModelUtils.mergePluginDefinitions(child, parent, false);

    assertEquals(1, child.getExecutions().size());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/217.java, start: 226, end: 258 */
public void
testShouldMergeOnePluginWithInheritExecutionWithoutDuplicatingPluginInList() {
    Plugin parent = new Plugin();
    parent.setArtifactId("testArtifact");
    parent.setGroupId("testGroup");
    parent.setVersion("1.0");

    PluginExecution parentExecution = new PluginExecution();
    parentExecution.setId("testExecution");

    parent.addExecution(parentExecution);

    Build parentContainer = new Build();
    parentContainer.addPlugin(parent);

    Plugin child = new Plugin();
    child.setArtifactId("testArtifact");
    child.setGroupId("testGroup");
    child.setVersion("1.0");

    Build childContainer = new Build();
    childContainer.addPlugin(child);

    ModelUtils.mergePluginLists(childContainer, parentContainer, true);

    List plugins = childContainer.getPlugins();

    assertEquals(1, plugins.size());

    Plugin plugin = (Plugin)plugins.get(0);

    assertEquals(1, plugin.getExecutions().size());
}

}
    