
class Java_127{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/92.java, start: 489, end: 505 */
private void injectMirror(ArtifactRepository repository, Mirror mirror) {
    if (mirror != null) {
        ArtifactRepository original = createArtifactRepository(
            repository.getId(), repository.getUrl(), repository.getLayout(),
            repository.getSnapshots(), repository.getReleases());

        repository.setMirroredRepositories(
            Collections.singletonList(original));

        repository.setId(mirror.getId());
        repository.setUrl(mirror.getUrl());

        if (StringUtils.isNotEmpty(mirror.getLayout())) {
            repository.setLayout(getLayout(mirror.getLayout()));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/696.java, start: 198, end: 214 */
private void injectMirror(ArtifactRepository repository, Mirror mirror) {
    if (mirror != null) {
        ArtifactRepository original = createArtifactRepository(
            repository.getId(), repository.getUrl(), repository.getLayout(),
            repository.getSnapshots(), repository.getReleases());

        repository.setMirroredRepositories(
            Collections.singletonList(original));

        repository.setId(mirror.getId());
        repository.setUrl(mirror.getUrl());

        if (StringUtils.isNotEmpty(mirror.getLayout())) {
            repository.setLayout(getLayout(mirror.getLayout()));
        }
    }
}

}
    