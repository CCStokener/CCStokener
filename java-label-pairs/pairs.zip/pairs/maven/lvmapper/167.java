
class Java_167{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2069, end: 2080 */
protected void mergeBuild_TestSourceDirectory(Build target, Build source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    String src = source.getTestSourceDirectory();
    if (src != null) {
        if (sourceDominant || target.getTestSourceDirectory() == null) {
            target.setTestSourceDirectory(src);
            target.setLocation("testSourceDirectory",
                               source.getLocation("testSourceDirectory"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2369, end: 2379 */
protected void mergePlugin_GroupId(Plugin target, Plugin source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}

}
    