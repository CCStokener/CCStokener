
class Java_97{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1556, end: 1566 */
protected void mergeMailingList_Name(MailingList target, MailingList source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1832, end: 1843 */
protected void mergeScm_Connection(Scm target, Scm source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getConnection();
    if (src != null) {
        if (sourceDominant || target.getConnection() == null) {
            target.setConnection(src);
            target.setLocation("connection",
                               source.getLocation("connection"));
        }
    }
}

}
    