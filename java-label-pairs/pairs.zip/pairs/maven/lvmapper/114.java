
class Java_114{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 542, end: 572 */
protected void mergeReportPlugin_ReportSets(ReportPlugin target,
                                            ReportPlugin source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    List<ReportSet> src = source.getReportSets();
    if (!src.isEmpty()) {
        List<ReportSet> tgt = target.getReportSets();
        Map<Object, ReportSet> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (ReportSet rset : src) {
            if (sourceDominant ||
                (rset.getInherited() != null ? rset.isInherited()
                                             : source.isInherited())) {
                Object key = getReportSetKey(rset);
                merged.put(key, rset);
            }
        }

        for (ReportSet element : tgt) {
            Object key = getReportSetKey(element);
            ReportSet existing = merged.get(key);
            if (existing != null) {
                mergeReportSet(element, existing, sourceDominant, context);
            }
            merged.put(key, element);
        }

        target.setReportSets(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 322, end: 345 */
protected void mergeModel_MailingLists(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    List<MailingList> src = source.getMailingLists();
    if (!src.isEmpty()) {
        List<MailingList> tgt = target.getMailingLists();
        Map<Object, MailingList> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (MailingList element : tgt) {
            Object key = getMailingListKey(element);
            merged.put(key, element);
        }

        for (MailingList element : src) {
            Object key = getMailingListKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setMailingLists(new ArrayList<>(merged.values()));
    }
}

}
    