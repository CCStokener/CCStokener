
class Java_133{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 411, end: 424 */
protected void mergeModel_Scm(Model target, Model source,
                              boolean sourceDominant,
                              Map<Object, Object> context) {
    Scm src = source.getScm();
    if (src != null) {
        Scm tgt = target.getScm();
        if (tgt == null) {
            tgt = new Scm();
            tgt.setTag(null);
            target.setScm(tgt);
        }
        mergeScm(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1952, end: 1961 */
protected void mergeNotifier_Address(Notifier target, Notifier source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getAddress();
    if (src != null) {
        if (sourceDominant || target.getAddress() == null) {
            target.setAddress(src);
        }
    }
}

}
    