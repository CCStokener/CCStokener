
class Java_0{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1680, end: 1691 */
protected void mergeContributor_Email(Contributor target,
                                      Contributor source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getEmail();
    if (src != null) {
        if (sourceDominant || target.getEmail() == null) {
            target.setEmail(src);
            target.setLocation("email", source.getLocation("email"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1719, end: 1731 */
protected void
mergeContributor_OrganizationUrl(Contributor target, Contributor source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getOrganizationUrl();
    if (src != null) {
        if (sourceDominant || target.getOrganizationUrl() == null) {
            target.setOrganizationUrl(src);
            target.setLocation("organizationUrl",
                               source.getLocation("organizationUrl"));
        }
    }
}

}
    