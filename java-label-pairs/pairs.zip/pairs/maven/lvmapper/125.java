
class Java_125{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1057, end: 1067 */
protected void mergeDependency_Version(Dependency target, Dependency source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1509, end: 1519 */
protected void mergeLicense_Url(License target, License source,
                                boolean sourceDominant,
                                Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant || target.getUrl() == null) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        }
    }
}

}
    