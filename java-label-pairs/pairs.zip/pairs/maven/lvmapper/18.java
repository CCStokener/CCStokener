
class Java_18{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/503.java, start: 341, end: 349 */
public Properties getExecutionProperties() {
    if (executionProperties == null) {
        executionProperties = new Properties();
        executionProperties.putAll(request.getSystemProperties());
        executionProperties.putAll(request.getUserProperties());
    }

    return executionProperties;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/292.java, start: 241, end: 247 */
public Properties getSystemProperties() {
    if (systemProperties == null) {
        systemProperties = new Properties();
    }

    return systemProperties;
}

}
    