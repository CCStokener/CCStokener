
class Java_131{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/432.java, start: 181, end: 187 */
public Log getLog() {
    if (log == null) {
        log = new SystemStreamLog();
    }

    return log;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/408.java, start: 97, end: 103 */
public Properties getSystemProperties() {
    if (systemProperties == null) {
        systemProperties = new Properties();
    }

    return systemProperties;
}

}
    