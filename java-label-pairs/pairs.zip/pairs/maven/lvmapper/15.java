
class Java_15{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/251.java, start: 164, end: 174 */
public DefaultProfileActivationContext
setUserProperties(Properties userProperties) {
    if (userProperties != null) {
        this.userProperties =
            Collections.unmodifiableMap((Map)userProperties);
    } else {
        this.userProperties = Collections.emptyMap();
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/251.java, start: 222, end: 233 */
public DefaultProfileActivationContext
setProjectProperties(Properties projectProperties) {
    if (projectProperties != null) {

        this.projectProperties =
            Collections.unmodifiableMap(toMap(projectProperties));
    } else {
        this.projectProperties = Collections.emptyMap();
    }

    return this;
}

}
    