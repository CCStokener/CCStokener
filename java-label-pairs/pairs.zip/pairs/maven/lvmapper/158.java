
class Java_158{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 78, end: 88 */
protected void mergeModel_Name(Model target, Model source,
                               boolean sourceDominant,
                               Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 991, end: 1002 */
protected void mergeRepositoryPolicy_UpdatePolicy(
    RepositoryPolicy target, RepositoryPolicy source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getUpdatePolicy();
    if (src != null) {
        if (sourceDominant || target.getUpdatePolicy() == null) {
            target.setUpdatePolicy(src);
            target.setLocation("updatePolicy",
                               source.getLocation("updatePolicy"));
        }
    }
}

}
    