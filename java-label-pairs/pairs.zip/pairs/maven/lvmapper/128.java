
class Java_128{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 905, end: 924 */
public void testOrderOfPluginConfigurationElementsWithoutPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-config-order/wo-plugin-mgmt");
    assertEquals(
        "one",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[1]"));
    assertEquals(
        "two",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[2]"));
    assertEquals(
        "three",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[3]"));
    assertEquals(
        "four",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[4]"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 927, end: 946 */
public void testOrderOfPluginConfigurationElementsWithPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-config-order/w-plugin-mgmt");
    assertEquals(
        "one",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[1]"));
    assertEquals(
        "two",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[2]"));
    assertEquals(
        "three",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[3]"));
    assertEquals(
        "four",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[4]"));
}

}
    