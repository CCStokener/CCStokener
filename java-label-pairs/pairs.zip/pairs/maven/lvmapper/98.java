
class Java_98{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1654, end: 1666 */
protected void mergeContributor(Contributor target, Contributor source,
                                boolean sourceDominant,
                                Map<Object, Object> context) {
    mergeContributor_Name(target, source, sourceDominant, context);
    mergeContributor_Email(target, source, sourceDominant, context);
    mergeContributor_Url(target, source, sourceDominant, context);
    mergeContributor_Organization(target, source, sourceDominant, context);
    mergeContributor_OrganizationUrl(target, source, sourceDominant,
                                     context);
    mergeContributor_Timezone(target, source, sourceDominant, context);
    mergeContributor_Roles(target, source, sourceDominant, context);
    mergeContributor_Properties(target, source, sourceDominant, context);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1813, end: 1819 */
protected void mergeScm(Scm target, Scm source, boolean sourceDominant,
                        Map<Object, Object> context) {
    mergeScm_Url(target, source, sourceDominant, context);
    mergeScm_Connection(target, source, sourceDominant, context);
    mergeScm_DeveloperConnection(target, source, sourceDominant, context);
    mergeScm_Tag(target, source, sourceDominant, context);
}

}
    