
class Java_189{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/589.java, start: 77, end: 85 */
protected PluginManagerException(MojoDescriptor mojoDescriptor,
                                 MavenProject project, String message) {
    super(message);
    this.project = project;
    pluginGroupId = mojoDescriptor.getPluginDescriptor().getGroupId();
    pluginArtifactId = mojoDescriptor.getPluginDescriptor().getArtifactId();
    pluginVersion = mojoDescriptor.getPluginDescriptor().getVersion();
    goal = mojoDescriptor.getGoal();
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/589.java, start: 87, end: 96 */
protected PluginManagerException(MojoDescriptor mojoDescriptor,
                                 MavenProject project, String message,
                                 Throwable cause) {
    super(message, cause);
    this.project = project;
    pluginGroupId = mojoDescriptor.getPluginDescriptor().getGroupId();
    pluginArtifactId = mojoDescriptor.getPluginDescriptor().getArtifactId();
    pluginVersion = mojoDescriptor.getPluginDescriptor().getVersion();
    goal = mojoDescriptor.getGoal();
}

}
    