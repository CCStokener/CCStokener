
class Java_94{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/824.java, start: 159, end: 165 */
static Dependency toDependency(MavenProject mavenProject) {
    final Dependency dependency = new Dependency();
    dependency.setArtifactId(mavenProject.getArtifactId());
    dependency.setGroupId(mavenProject.getGroupId());
    dependency.setVersion(mavenProject.getVersion());
    return dependency;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/116.java, start: 135, end: 143 */
private static org.apache.maven.model.RepositoryPolicy
convertRepositoryPolicy(RepositoryPolicy profileXmlRepo) {
    org.apache.maven.model.RepositoryPolicy policy =
        new org.apache.maven.model.RepositoryPolicy();
    policy.setEnabled(profileXmlRepo.isEnabled());
    policy.setUpdatePolicy(profileXmlRepo.getUpdatePolicy());
    policy.setChecksumPolicy(profileXmlRepo.getChecksumPolicy());
    return policy;
}

}
    