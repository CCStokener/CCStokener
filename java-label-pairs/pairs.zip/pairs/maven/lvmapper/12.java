
class Java_12{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2153, end: 2164 */
protected void mergeExtension_ArtifactId(Extension target, Extension source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2593, end: 2602 */
protected void mergeResource_MergeId(Resource target, Resource source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getMergeId();
    if (src != null) {
        if (sourceDominant || target.getMergeId() == null) {
            target.setMergeId(src);
        }
    }
}

}
    