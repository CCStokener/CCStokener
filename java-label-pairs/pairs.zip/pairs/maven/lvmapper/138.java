
class Java_138{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 755, end: 765 */
protected void mergeRelocation_GroupId(Relocation target, Relocation source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1668, end: 1678 */
protected void mergeContributor_Name(Contributor target, Contributor source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}

}
    