
class Java_16{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 472, end: 482 */
public void testOrderOfPluginExecutionsWithPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-exec-order/w-plugin-mgmt");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/executions")).size());
    assertEquals("b", pom.getValue("build/plugins[1]/executions[1]/id"));
    assertEquals("a", pom.getValue("build/plugins[1]/executions[2]/id"));
    assertEquals("d", pom.getValue("build/plugins[1]/executions[3]/id"));
    assertEquals("c", pom.getValue("build/plugins[1]/executions[4]/id"));
    assertEquals("e", pom.getValue("build/plugins[1]/executions[5]/id"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 1215, end: 1226 */
public void testUrlAppendWithChildPathAdjustment() throws Exception {
    PomTestWrapper pom = this.buildPom("url-append/child");
    assertEquals("http://project.url/child", pom.getValue("url"));
    assertEquals("http://viewvc.project.url/child",
                 pom.getValue("scm/url"));
    assertEquals("http://scm.project.url/child",
                 pom.getValue("scm/connection"));
    assertEquals("https://scm.project.url/child",
                 pom.getValue("scm/developerConnection"));
    assertEquals("http://site.project.url/child",
                 pom.getValue("distributionManagement/site/url"));
}

}
    