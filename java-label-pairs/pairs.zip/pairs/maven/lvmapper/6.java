
class Java_6{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/459.java, start: 88, end: 100 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }
    if (null == obj || !getClass().equals(obj.getClass())) {
        return false;
    }

    Key that = (Key)obj;
    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) && version.equals(that.version) &&
        tag.equals(that.tag);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/148.java, start: 65, end: 77 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof OrArtifactFilter)) {
        return false;
    }

    OrArtifactFilter other = (OrArtifactFilter)obj;

    return filters.equals(other.filters);
}

}
    