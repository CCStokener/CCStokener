
class Java_119{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/886.java, start: 170, end: 183 */
public void testMatchingGroupIdsDifferentArtifactIds()
    throws CycleDetectedException, DuplicateProjectException {
    List<MavenProject> projects = new ArrayList<>();
    MavenProject project1 = createProject("groupId", "artifactId1", "1.0");
    projects.add(project1);
    MavenProject project2 = createProject("groupId", "artifactId2", "1.0");
    projects.add(project2);
    project1.getDependencies().add(createDependency(project2));

    projects = new ProjectSorter(projects).getSortedProjects();

    assertEquals(project2, projects.get(0));
    assertEquals(project1, projects.get(1));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/886.java, start: 338, end: 356 */
public void
testDependencyPrecedesProjectThatUsesUnresolvedDependencyVersion()
    throws Exception {
    List<MavenProject> projects = new ArrayList<>();

    MavenProject usingProject = createProject("group", "project", "1.0");
    projects.add(usingProject);
    usingProject.getModel().addDependency(
        createDependency("group", "dependency", "[1.0,)"));

    MavenProject pluginProject =
        createProject("group", "dependency", "1.0");
    projects.add(pluginProject);

    projects = new ProjectSorter(projects).getSortedProjects();

    assertEquals(pluginProject, projects.get(0));
    assertEquals(usingProject, projects.get(1));
}

}
    