
class Java_99{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/792.java, start: 260, end: 266 */
public List<Mirror> getMirrors() {
    if (mirrors == null) {
        mirrors = new ArrayList<>();
    }

    return mirrors;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/792.java, start: 274, end: 280 */
public List<Proxy> getProxies() {
    if (proxies == null) {
        proxies = new ArrayList<>();
    }

    return proxies;
}

}
    