
class Java_149{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/313.java, start: 67, end: 91 */
private void mergePluginContainer_Plugins(PluginContainer target,
                                          PluginContainer source) {
    List<Plugin> src = source.getPlugins();
    if (!src.isEmpty()) {
        List<Plugin> tgt = target.getPlugins();

        Map<Object, Plugin> managedPlugins =
            new LinkedHashMap<>(src.size() * 2);

        Map<Object, Object> context = Collections.emptyMap();

        for (Plugin element : src) {
            Object key = getPluginKey(element);
            managedPlugins.put(key, element);
        }

        for (Plugin element : tgt) {
            Object key = getPluginKey(element);
            Plugin managedPlugin = managedPlugins.get(key);
            if (managedPlugin != null) {
                mergePlugin(element, managedPlugin, false, context);
            }
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2108, end: 2131 */
protected void mergeBuild_Extensions(Build target, Build source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    List<Extension> src = source.getExtensions();
    if (!src.isEmpty()) {
        List<Extension> tgt = target.getExtensions();
        Map<Object, Extension> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Extension element : tgt) {
            Object key = getExtensionKey(element);
            merged.put(key, element);
        }

        for (Extension element : src) {
            Object key = getExtensionKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setExtensions(new ArrayList<>(merged.values()));
    }
}

}
    