
class Java_36{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2381, end: 2392 */
protected void mergePlugin_ArtifactId(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2531, end: 2542 */
protected void mergePluginExecution_Phase(PluginExecution target,
                                          PluginExecution source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getPhase();
    if (src != null) {
        if (sourceDominant || target.getPhase() == null) {
            target.setPhase(src);
            target.setLocation("phase", source.getLocation("phase"));
        }
    }
}

}
    