
class Java_196{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1121, end: 1132 */
protected void mergeDependency_Optional(Dependency target,
                                        Dependency source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getOptional();
    if (src != null) {
        if (sourceDominant || target.getOptional() == null) {
            target.setOptional(src);
            target.setLocation("optional", source.getLocation("optional"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2611, end: 2622 */
protected void mergeFileSet_Directory(FileSet target, FileSet source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}

}
    