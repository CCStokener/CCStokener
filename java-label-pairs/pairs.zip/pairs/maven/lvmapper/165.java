
class Java_165{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 233, end: 243 */
protected void mergeModel_Name(Model target, Model source,
                               boolean sourceDominant,
                               Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2055, end: 2067 */
protected void
mergeBuild_ScriptSourceDirectory(Build target, Build source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getScriptSourceDirectory();
    if (src != null) {
        if (sourceDominant || target.getScriptSourceDirectory() == null) {
            target.setScriptSourceDirectory(src);
            target.setLocation("scriptSourceDirectory",
                               source.getLocation("scriptSourceDirectory"));
        }
    }
}

}
    