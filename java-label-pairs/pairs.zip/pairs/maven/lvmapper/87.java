
class Java_87{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1890, end: 1901 */
protected void mergeCiManagement_Url(CiManagement target,
                                     CiManagement source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant || target.getUrl() == null) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1941, end: 1950 */
protected void mergeNotifier_Type(Notifier target, Notifier source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    String src = source.getType();
    if (src != null) {
        if (sourceDominant || target.getType() == null) {
            target.setType(src);
        }
    }
}

}
    