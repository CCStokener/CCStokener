
class Java_135{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/255.java, start: 81, end: 96 */
public boolean presentInConfig(Profile profile,
                               ProfileActivationContext context,
                               ModelProblemCollector problems) {
    Activation activation = profile.getActivation();

    if (activation == null) {
        return false;
    }

    String jdk = activation.getJdk();

    if (jdk == null) {
        return false;
    }
    return true;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/254.java, start: 101, end: 116 */
public boolean presentInConfig(Profile profile,
                               ProfileActivationContext context,
                               ModelProblemCollector problems) {
    Activation activation = profile.getActivation();

    if (activation == null) {
        return false;
    }

    ActivationProperty property = activation.getProperty();

    if (property == null) {
        return false;
    }
    return true;
}

}
    