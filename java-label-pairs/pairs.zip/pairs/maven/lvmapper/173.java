
class Java_173{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1043, end: 1055 */
protected void mergeDependency_ArtifactId(Dependency target,
                                          Dependency source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1787, end: 1798 */
protected void mergeIssueManagement_System(IssueManagement target,
                                           IssueManagement source,
                                           boolean sourceDominant,
                                           Map<Object, Object> context) {
    String src = source.getSystem();
    if (src != null) {
        if (sourceDominant || target.getSystem() == null) {
            target.setSystem(src);
            target.setLocation("system", source.getLocation("system"));
        }
    }
}

}
    