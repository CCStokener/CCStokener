
class Java_170{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1031, end: 1041 */
protected void mergeDependency_GroupId(Dependency target, Dependency source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1521, end: 1532 */
protected void mergeLicense_Distribution(License target, License source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getDistribution();
    if (src != null) {
        if (sourceDominant || target.getDistribution() == null) {
            target.setDistribution(src);
            target.setLocation("distribution",
                               source.getLocation("distribution"));
        }
    }
}

}
    