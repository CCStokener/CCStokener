
class Java_7{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 422, end: 438 */
public void testOrderOfGoalsFromPluginExecutionWithoutPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-exec-goals-order/wo-plugin-mgmt");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/executions[1]/goals"))
               .size());
    assertEquals("b",
                 pom.getValue("build/plugins[1]/executions[1]/goals[1]"));
    assertEquals("a",
                 pom.getValue("build/plugins[1]/executions[1]/goals[2]"));
    assertEquals("d",
                 pom.getValue("build/plugins[1]/executions[1]/goals[3]"));
    assertEquals("c",
                 pom.getValue("build/plugins[1]/executions[1]/goals[4]"));
    assertEquals("e",
                 pom.getValue("build/plugins[1]/executions[1]/goals[5]"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 472, end: 482 */
public void testOrderOfPluginExecutionsWithPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-exec-order/w-plugin-mgmt");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/executions")).size());
    assertEquals("b", pom.getValue("build/plugins[1]/executions[1]/id"));
    assertEquals("a", pom.getValue("build/plugins[1]/executions[2]/id"));
    assertEquals("d", pom.getValue("build/plugins[1]/executions[3]/id"));
    assertEquals("c", pom.getValue("build/plugins[1]/executions[4]/id"));
    assertEquals("e", pom.getValue("build/plugins[1]/executions[5]/id"));
}

}
    