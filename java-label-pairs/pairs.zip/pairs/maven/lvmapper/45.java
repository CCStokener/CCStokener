
class Java_45{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 452, end: 467 */
protected void mergeScm_Connection(Scm target, Scm source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getConnection();
    if (src != null) {
        if (sourceDominant) {
            target.setConnection(src);
            target.setLocation("connection",
                               source.getLocation("connection"));
        } else if (target.getConnection() == null) {
            target.setConnection(extrapolateChildUrl(src, context));
            target.setLocation("connection",
                               source.getLocation("connection"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2381, end: 2392 */
protected void mergePlugin_ArtifactId(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}

}
    