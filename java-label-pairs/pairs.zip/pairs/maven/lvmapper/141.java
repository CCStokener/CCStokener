
class Java_141{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/461.java, start: 118, end: 131 */
public void initService(ServiceLocator locator) {
    setRemoteRepositoryManager(
        locator.getService(RemoteRepositoryManager.class));
    setVersionResolver(locator.getService(VersionResolver.class));
    setVersionRangeResolver(locator.getService(VersionRangeResolver.class));
    setArtifactResolver(locator.getService(ArtifactResolver.class));
    modelBuilder = locator.getService(ModelBuilder.class);
    if (modelBuilder == null) {
        setModelBuilder(new DefaultModelBuilderFactory().newInstance());
    }
    setRepositoryEventDispatcher(
        locator.getService(RepositoryEventDispatcher.class));
    setLoggerFactory(locator.getService(LoggerFactory.class));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/451.java, start: 112, end: 118 */
public void initService(ServiceLocator locator) {
    setLoggerFactory(locator.getService(LoggerFactory.class));
    setMetadataResolver(locator.getService(MetadataResolver.class));
    setSyncContextFactory(locator.getService(SyncContextFactory.class));
    setRepositoryEventDispatcher(
        locator.getService(RepositoryEventDispatcher.class));
}

}
    