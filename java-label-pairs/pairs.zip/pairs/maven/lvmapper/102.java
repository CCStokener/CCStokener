
class Java_102{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 598, end: 611 */
public void
testOverridingOfInheritedPluginExecutionsWithoutPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-exec-merging/wo-plugin-mgmt/sub");
    assertEquals(
        2, ((List<?>)pom.getValue("build/plugins[1]/executions")).size());
    assertEquals(
        "child-default",
        pom.getValue("build/plugins[1]/executions[@id='default']/phase"));
    assertEquals(
        "child-non-default",
        pom.getValue(
            "build/plugins[1]/executions[@id='non-default']/phase"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 1092, end: 1099 */
public void testDependencyOrderWithoutPluginManagement() throws Exception {
    PomTestWrapper pom = buildPom("dependency-order/wo-plugin-mgmt");
    assertEquals(4, ((List<?>)pom.getValue("dependencies")).size());
    assertEquals("a", pom.getValue("dependencies[1]/artifactId"));
    assertEquals("c", pom.getValue("dependencies[2]/artifactId"));
    assertEquals("b", pom.getValue("dependencies[3]/artifactId"));
    assertEquals("d", pom.getValue("dependencies[4]/artifactId"));
}

}
    