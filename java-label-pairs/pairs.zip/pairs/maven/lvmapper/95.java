
class Java_95{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 441, end: 457 */
public void testOrderOfGoalsFromPluginExecutionWithPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-exec-goals-order/w-plugin-mgmt");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/executions[1]/goals"))
               .size());
    assertEquals("b",
                 pom.getValue("build/plugins[1]/executions[1]/goals[1]"));
    assertEquals("a",
                 pom.getValue("build/plugins[1]/executions[1]/goals[2]"));
    assertEquals("d",
                 pom.getValue("build/plugins[1]/executions[1]/goals[3]"));
    assertEquals("c",
                 pom.getValue("build/plugins[1]/executions[1]/goals[4]"));
    assertEquals("e",
                 pom.getValue("build/plugins[1]/executions[1]/goals[5]"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 1184, end: 1198 */
public void testManagedProfileDependency() throws Exception {
    PomTestWrapper pom =
        this.buildPom("managed-profile-dependency/sub", "maven-core-it");
    assertEquals(1, ((List<?>)pom.getValue("dependencies")).size());
    assertEquals("org.apache.maven.its",
                 pom.getValue("dependencies[1]/groupId"));
    assertEquals("maven-core-it-support",
                 pom.getValue("dependencies[1]/artifactId"));
    assertEquals("1.3", pom.getValue("dependencies[1]/version"));
    assertEquals("runtime", pom.getValue("dependencies[1]/scope"));
    assertEquals(
        1, ((List<?>)pom.getValue("dependencies[1]/exclusions")).size());
    assertEquals("commons-lang",
                 pom.getValue("dependencies[1]/exclusions[1]/groupId"));
}

}
    