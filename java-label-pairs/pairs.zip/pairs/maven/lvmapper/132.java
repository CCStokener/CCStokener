
class Java_132{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 1161, end: 1168 */
public void testProfileInjectedDependencies() throws Exception {
    PomTestWrapper pom = buildPom("profile-injected-dependencies");
    assertEquals(4, ((List<?>)pom.getValue("dependencies")).size());
    assertEquals("a", pom.getValue("dependencies[1]/artifactId"));
    assertEquals("c", pom.getValue("dependencies[2]/artifactId"));
    assertEquals("b", pom.getValue("dependencies[3]/artifactId"));
    assertEquals("d", pom.getValue("dependencies[4]/artifactId"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 1733, end: 1741 */
public void testPropertiesInheritance() throws Exception {
    PomTestWrapper pom = buildPom("properties-inheritance/sub");
    assertEquals("parent-property",
                 pom.getValue("properties/parentProperty"));
    assertEquals("child-property",
                 pom.getValue("properties/childProperty"));
    assertEquals("child-override",
                 pom.getValue("properties/overriddenProperty"));
}

}
    