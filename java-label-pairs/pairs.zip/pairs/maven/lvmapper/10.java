
class Java_10{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/782.java, start: 89, end: 95 */
public Set<Artifact> getArtifacts() {
    if (artifacts == null) {
        artifacts = new LinkedHashSet<>();
    }

    return artifacts;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/421.java, start: 93, end: 99 */
public List<Proxy> getProxies() {
    if (proxies == null) {
        proxies = new ArrayList<>();
    }

    return proxies;
}

}
    