
class Java_179{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 508, end: 524 */
public void testOrderOfMergedPluginExecutionsWithoutPluginManagement()
    throws Exception {
    PomTestWrapper pom =
        buildPom("merged-plugin-exec-order/wo-plugin-mgmt/sub");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/executions")).size());
    assertEquals("parent-1",
                 pom.getValue("build/plugins[1]/executions[1]/goals[1]"));
    assertEquals("parent-2",
                 pom.getValue("build/plugins[1]/executions[2]/goals[1]"));
    assertEquals("child-default",
                 pom.getValue("build/plugins[1]/executions[3]/goals[1]"));
    assertEquals("child-1",
                 pom.getValue("build/plugins[1]/executions[4]/goals[1]"));
    assertEquals("child-2",
                 pom.getValue("build/plugins[1]/executions[5]/goals[1]"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 1161, end: 1168 */
public void testProfileInjectedDependencies() throws Exception {
    PomTestWrapper pom = buildPom("profile-injected-dependencies");
    assertEquals(4, ((List<?>)pom.getValue("dependencies")).size());
    assertEquals("a", pom.getValue("dependencies[1]/artifactId"));
    assertEquals("c", pom.getValue("dependencies[2]/artifactId"));
    assertEquals("b", pom.getValue("dependencies[3]/artifactId"));
    assertEquals("d", pom.getValue("dependencies[4]/artifactId"));
}

}
    