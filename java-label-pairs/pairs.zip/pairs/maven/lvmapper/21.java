
class Java_21{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 719, end: 731 */
public MavenExecutionRequest addServer(Server server) {
    Validate.notNull(server, "server cannot be null");

    for (Server p : getServers()) {
        if (p.getId() != null && p.getId().equals(server.getId())) {
            return this;
        }
    }

    getServers().add(server);

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 899, end: 911 */
public MavenExecutionRequest
addRemoteRepository(ArtifactRepository repository) {
    for (ArtifactRepository repo : getRemoteRepositories()) {
        if (repo.getId() != null &&
            repo.getId().equals(repository.getId())) {
            return this;
        }
    }

    getRemoteRepositories().add(repository);

    return this;
}

}
    