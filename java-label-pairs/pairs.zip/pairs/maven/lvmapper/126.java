
class Java_126{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 733, end: 744 */
protected void mergeDistributionManagement_DownloadUrl(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getDownloadUrl();
    if (src != null) {
        if (sourceDominant || target.getDownloadUrl() == null) {
            target.setDownloadUrl(src);
            target.setLocation("downloadUrl",
                               source.getLocation("downloadUrl"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1475, end: 1486 */
protected void mergeOrganization_Url(Organization target,
                                     Organization source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant || target.getUrl() == null) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        }
    }
}

}
    