
class Java_93{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/653.java, start: 219, end: 225 */
public void print(double d) {
    final PrintStream currentStream = getOutputStreamForCurrentThread();
    synchronized (currentStream) {
        currentStream.print(d);
        currentStream.notifyAll();
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/653.java, start: 237, end: 243 */
public void print(float f) {
    final PrintStream currentStream = getOutputStreamForCurrentThread();
    synchronized (currentStream) {
        currentStream.print(f);
        currentStream.notifyAll();
    }
}

}
    