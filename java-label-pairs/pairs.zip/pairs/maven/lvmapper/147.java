
class Java_147{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 508, end: 524 */
public void testOrderOfMergedPluginExecutionsWithoutPluginManagement()
    throws Exception {
    PomTestWrapper pom =
        buildPom("merged-plugin-exec-order/wo-plugin-mgmt/sub");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/executions")).size());
    assertEquals("parent-1",
                 pom.getValue("build/plugins[1]/executions[1]/goals[1]"));
    assertEquals("parent-2",
                 pom.getValue("build/plugins[1]/executions[2]/goals[1]"));
    assertEquals("child-default",
                 pom.getValue("build/plugins[1]/executions[3]/goals[1]"));
    assertEquals("child-1",
                 pom.getValue("build/plugins[1]/executions[4]/goals[1]"));
    assertEquals("child-2",
                 pom.getValue("build/plugins[1]/executions[5]/goals[1]"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 905, end: 924 */
public void testOrderOfPluginConfigurationElementsWithoutPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-config-order/wo-plugin-mgmt");
    assertEquals(
        "one",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[1]"));
    assertEquals(
        "two",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[2]"));
    assertEquals(
        "three",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[3]"));
    assertEquals(
        "four",
        pom.getValue(
            "build/plugins[1]/configuration/stringParams/stringParam[4]"));
}

}
    