
class Java_41{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/158.java, start: 92, end: 103 */
public boolean equals(Object o) {
    if (this == o) {
        return true;
    }
    if (o == null || getClass() != o.getClass()) {
        return false;
    }

    final ArtifactStatus that = (ArtifactStatus)o;

    return rank == that.rank;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/146.java, start: 43, end: 55 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof InversionArtifactFilter)) {
        return false;
    }

    InversionArtifactFilter other = (InversionArtifactFilter)obj;

    return toInvert.equals(other.toInvert);
}

}
    