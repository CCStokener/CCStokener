
class Java_192{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 1928, end: 1936 */
public void testValidationErrorUponNonUniquePluginRepositoryId()
    throws Exception {
    try {
        buildPom("unique-repo-id/plugin-repo");
        fail("Non-unique repository ids did not cause validation error");
    } catch (ProjectBuildingException e) {
        // expected
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 2138, end: 2146 */
public void testProjectArtifactIdIsNotInheritedButMandatory()
    throws Exception {
    try {
        buildPom("artifact-id-inheritance/child");
        fail("Missing artifactId did not cause validation error");
    } catch (ProjectBuildingException e) {
        // expected
    }
}

}
    