
class Java_96{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1668, end: 1678 */
protected void mergeContributor_Name(Contributor target, Contributor source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2204, end: 2215 */
protected void mergeBuildBase_Directory(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}

}
    