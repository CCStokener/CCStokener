
class Java_60{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 437, end: 449 */
protected void mergeScm_Url(Scm target, Scm source, boolean sourceDominant,
                            Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        } else if (target.getUrl() == null) {
            target.setUrl(extrapolateChildUrl(src, context));
            target.setLocation("url", source.getLocation("url"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 843, end: 853 */
protected void mergeSite_Name(Site target, Site source,
                              boolean sourceDominant,
                              Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}

}
    