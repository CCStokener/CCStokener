
class Java_88{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 270, end: 281 */
protected void mergeModel_InceptionYear(Model target, Model source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getInceptionYear();
    if (src != null) {
        if (sourceDominant || target.getInceptionYear() == null) {
            target.setInceptionYear(src);
            target.setLocation("inceptionYear",
                               source.getLocation("inceptionYear"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1521, end: 1532 */
protected void mergeLicense_Distribution(License target, License source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getDistribution();
    if (src != null) {
        if (sourceDominant || target.getDistribution() == null) {
            target.setDistribution(src);
            target.setLocation("distribution",
                               source.getLocation("distribution"));
        }
    }
}

}
    