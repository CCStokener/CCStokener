
class Java_2{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1069, end: 1079 */
protected void mergeDependency_Type(Dependency target, Dependency source,
                                    boolean sourceDominant,
                                    Map<Object, Object> context) {
    String src = source.getType();
    if (src != null) {
        if (sourceDominant || target.getType() == null) {
            target.setType(src);
            target.setLocation("type", source.getLocation("type"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1264, end: 1275 */
protected void mergeReportPlugin_GroupId(ReportPlugin target,
                                         ReportPlugin source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}

}
    