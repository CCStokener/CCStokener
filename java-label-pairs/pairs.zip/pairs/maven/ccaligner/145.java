
class Java_145{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2480, end: 2491 */
protected void mergeConfigurationContainer_Inherited(
    ConfigurationContainer target, ConfigurationContainer source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getInherited();
    if (src != null) {
        if (sourceDominant || target.getInherited() == null) {
            target.setInherited(src);
            target.setLocation("inherited",
                               source.getLocation("inherited"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2580, end: 2591 */
protected void mergeResource_Filtering(Resource target, Resource source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getFiltering();
    if (src != null) {
        if (sourceDominant || target.getFiltering() == null) {
            target.setFiltering(src);
            target.setLocation("filtering",
                               source.getLocation("filtering"));
        }
    }
}

}
    