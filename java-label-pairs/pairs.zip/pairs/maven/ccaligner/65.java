
class Java_65{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1800, end: 1811 */
protected void mergeIssueManagement_Url(IssueManagement target,
                                        IssueManagement source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant || target.getUrl() == null) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2406, end: 2417 */
protected void mergePlugin_Extensions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getExtensions();
    if (src != null) {
        if (sourceDominant || target.getExtensions() == null) {
            target.setExtensions(src);
            target.setLocation("extensions",
                               source.getLocation("extensions"));
        }
    }
}

}
    