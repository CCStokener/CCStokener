
class Java_182{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 928, end: 939 */
protected void mergeRepositoryBase_Url(RepositoryBase target,
                                       RepositoryBase source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant || target.getUrl() == null) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1642, end: 1652 */
protected void mergeDeveloper_Id(Developer target, Developer source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getId();
    if (src != null) {
        if (sourceDominant || target.getId() == null) {
            target.setId(src);
            target.setLocation("id", source.getLocation("id"));
        }
    }
}

}
    