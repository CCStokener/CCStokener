
class Java_86{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/875.java, start: 90, end: 108 */
private String getPath(Metadata metadata, String repositoryKey) {
    StringBuilder path = new StringBuilder(128);

    if (metadata.getGroupId().length() > 0) {
        path.append(metadata.getGroupId().replace('.', '/')).append('/');

        if (metadata.getArtifactId().length() > 0) {
            path.append(metadata.getArtifactId()).append('/');

            if (metadata.getVersion().length() > 0) {
                path.append(metadata.getVersion()).append('/');
            }
        }
    }

    path.append(insertRepositoryKey(metadata.getType(), repositoryKey));

    return path.toString();
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/196.java, start: 90, end: 108 */
private String getPath(Metadata metadata, String repositoryKey) {
    StringBuilder path = new StringBuilder(128);

    if (metadata.getGroupId().length() > 0) {
        path.append(metadata.getGroupId().replace('.', '/')).append('/');

        if (metadata.getArtifactId().length() > 0) {
            path.append(metadata.getArtifactId()).append('/');

            if (metadata.getVersion().length() > 0) {
                path.append(metadata.getVersion()).append('/');
            }
        }
    }

    path.append(insertRepositoryKey(metadata.getType(), repositoryKey));

    return path.toString();
}

}
    