
class Java_50{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2406, end: 2417 */
protected void mergePlugin_Extensions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getExtensions();
    if (src != null) {
        if (sourceDominant || target.getExtensions() == null) {
            target.setExtensions(src);
            target.setLocation("extensions",
                               source.getLocation("extensions"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2580, end: 2591 */
protected void mergeResource_Filtering(Resource target, Resource source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getFiltering();
    if (src != null) {
        if (sourceDominant || target.getFiltering() == null) {
            target.setFiltering(src);
            target.setLocation("filtering",
                               source.getLocation("filtering"));
        }
    }
}

}
    