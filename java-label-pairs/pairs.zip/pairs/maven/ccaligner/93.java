
class Java_93{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 245, end: 256 */
protected void mergeModel_Description(Model target, Model source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getDescription();
    if (src != null) {
        if (sourceDominant || target.getDescription() == null) {
            target.setDescription(src);
            target.setLocation("description",
                               source.getLocation("description"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2055, end: 2067 */
protected void
mergeBuild_ScriptSourceDirectory(Build target, Build source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getScriptSourceDirectory();
    if (src != null) {
        if (sourceDominant || target.getScriptSourceDirectory() == null) {
            target.setScriptSourceDirectory(src);
            target.setLocation("scriptSourceDirectory",
                               source.getLocation("scriptSourceDirectory"));
        }
    }
}

}
    