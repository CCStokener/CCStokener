
class Java_147{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/782.java, start: 199, end: 210 */
public ArtifactResolutionResult
addMetadataResolutionException(ArtifactResolutionException e) {
    metadataResolutionExceptions = initList(metadataResolutionExceptions);

    metadataResolutionExceptions.add(e);

    exceptions = initList(exceptions);

    exceptions.add(e);

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/72.java, start: 237, end: 248 */
public MetadataResolutionResult
addCircularDependencyException(CyclicDependencyException e) {
    circularDependencyExceptions = initList(circularDependencyExceptions);

    circularDependencyExceptions.add(e);

    exceptions = initList(exceptions);

    exceptions.add(e);

    return this;
}

}
    