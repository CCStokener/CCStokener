
class Java_90{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 793, end: 803 */
protected void mergeRelocation_Message(Relocation target, Relocation source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getMessage();
    if (src != null) {
        if (sourceDominant || target.getMessage() == null) {
            target.setMessage(src);
            target.setLocation("message", source.getLocation("message"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2580, end: 2591 */
protected void mergeResource_Filtering(Resource target, Resource source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getFiltering();
    if (src != null) {
        if (sourceDominant || target.getFiltering() == null) {
            target.setFiltering(src);
            target.setLocation("filtering",
                               source.getLocation("filtering"));
        }
    }
}

}
    