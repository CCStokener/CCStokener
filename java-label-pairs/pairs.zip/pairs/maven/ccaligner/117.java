
class Java_117{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 941, end: 952 */
protected void mergeRepositoryBase_Name(RepositoryBase target,
                                        RepositoryBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2531, end: 2542 */
protected void mergePluginExecution_Phase(PluginExecution target,
                                          PluginExecution source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getPhase();
    if (src != null) {
        if (sourceDominant || target.getPhase() == null) {
            target.setPhase(src);
            target.setLocation("phase", source.getLocation("phase"));
        }
    }
}

}
    