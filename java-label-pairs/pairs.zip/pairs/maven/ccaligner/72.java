
class Java_72{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/786.java, start: 96, end: 108 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CumulativeScopeArtifactFilter)) {
        return false;
    }

    CumulativeScopeArtifactFilter that = (CumulativeScopeArtifactFilter)obj;

    return scopes.equals(that.scopes);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/736.java, start: 74, end: 88 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof CacheKey)) {
        return false;
    }

    CacheKey that = (CacheKey)obj;

    return artifactId.equals(that.artifactId) &&
        groupId.equals(that.groupId) && version.equals(that.version) &&
        tag.equals(that.tag);
}

}
    