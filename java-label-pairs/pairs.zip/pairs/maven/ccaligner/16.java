
class Java_16{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 954, end: 965 */
protected void mergeRepositoryBase_Layout(RepositoryBase target,
                                          RepositoryBase source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getLayout();
    if (src != null) {
        if (sourceDominant || target.getLayout() == null) {
            target.setLayout(src);
            target.setLocation("layout", source.getLocation("layout"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1733, end: 1744 */
protected void mergeContributor_Timezone(Contributor target,
                                         Contributor source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getTimezone();
    if (src != null) {
        if (sourceDominant || target.getTimezone() == null) {
            target.setTimezone(src);
            target.setLocation("timezone", source.getLocation("timezone"));
        }
    }
}

}
    