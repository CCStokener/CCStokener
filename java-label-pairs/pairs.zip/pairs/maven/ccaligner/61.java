
class Java_61{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1168, end: 1178 */
protected void mergeExclusion_GroupId(Exclusion target, Exclusion source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1215, end: 1227 */
protected void mergeReporting_ExcludeDefaults(Reporting target,
                                              Reporting source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    String src = source.getExcludeDefaults();
    if (src != null) {
        if (sourceDominant || target.getExcludeDefaults() == null) {
            target.setExcludeDefaults(src);
            target.setLocation("excludeDefaults",
                               source.getLocation("excludeDefaults"));
        }
    }
}

}
    