
class Java_165{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1546, end: 1554 */
protected void mergeMailingList(MailingList target, MailingList source,
                                boolean sourceDominant,
                                Map<Object, Object> context) {
    mergeMailingList_Name(target, source, sourceDominant, context);
    mergeMailingList_Subscribe(target, source, sourceDominant, context);
    mergeMailingList_Unsubscribe(target, source, sourceDominant, context);
    mergeMailingList_Post(target, source, sourceDominant, context);
    mergeMailingList_OtherArchives(target, source, sourceDominant, context);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2178, end: 2188 */
protected void mergeBuildBase(BuildBase target, BuildBase source,
                              boolean sourceDominant,
                              Map<Object, Object> context) {
    mergePluginConfiguration(target, source, sourceDominant, context);
    mergeBuildBase_DefaultGoal(target, source, sourceDominant, context);
    mergeBuildBase_FinalName(target, source, sourceDominant, context);
    mergeBuildBase_Directory(target, source, sourceDominant, context);
    mergeBuildBase_Resources(target, source, sourceDominant, context);
    mergeBuildBase_TestResources(target, source, sourceDominant, context);
    mergeBuildBase_Filters(target, source, sourceDominant, context);
}

}
    