
class Java_10{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1680, end: 1691 */
protected void mergeContributor_Email(Contributor target,
                                      Contributor source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getEmail();
    if (src != null) {
        if (sourceDominant || target.getEmail() == null) {
            target.setEmail(src);
            target.setLocation("email", source.getLocation("email"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2204, end: 2215 */
protected void mergeBuildBase_Directory(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}

}
    