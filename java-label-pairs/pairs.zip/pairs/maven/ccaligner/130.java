
class Java_130{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 855, end: 865 */
protected void mergeSite_Url(Site target, Site source,
                             boolean sourceDominant,
                             Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant || target.getUrl() == null) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 978, end: 989 */
protected void mergeRepositoryPolicy_Enabled(RepositoryPolicy target,
                                             RepositoryPolicy source,
                                             boolean sourceDominant,
                                             Map<Object, Object> context) {
    String src = source.getEnabled();
    if (src != null) {
        if (sourceDominant || target.getEnabled() == null) {
            target.setEnabled(src);
            target.setLocation("enabled", source.getLocation("enabled"));
        }
    }
}

}
    