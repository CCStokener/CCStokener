
class Java_15{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/731.java, start: 130, end: 140 */
public ProjectBuildingRequest setPluginArtifactRepositories(
    List<ArtifactRepository> pluginArtifactRepositories) {
    if (pluginArtifactRepositories != null) {
        this.pluginArtifactRepositories =
            new ArrayList<>(pluginArtifactRepositories);
    } else {
        this.pluginArtifactRepositories.clear();
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/731.java, start: 218, end: 224 */
public void setActiveProfileIds(List<String> activeProfileIds) {
    if (activeProfileIds != null) {
        this.activeProfileIds = new ArrayList<>(activeProfileIds);
    } else {
        this.activeProfileIds.clear();
    }
}

}
    