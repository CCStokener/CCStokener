
class Java_108{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1338, end: 1348 */
protected void mergeReportSet_Id(ReportSet target, ReportSet source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getId();
    if (src != null) {
        if (sourceDominant || target.getId() == null) {
            target.setId(src);
            target.setLocation("id", source.getLocation("id"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1705, end: 1717 */
protected void mergeContributor_Organization(Contributor target,
                                             Contributor source,
                                             boolean sourceDominant,
                                             Map<Object, Object> context) {
    String src = source.getOrganization();
    if (src != null) {
        if (sourceDominant || target.getOrganization() == null) {
            target.setOrganization(src);
            target.setLocation("organization",
                               source.getLocation("organization"));
        }
    }
}

}
    