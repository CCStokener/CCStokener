
class Java_63{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/251.java, start: 89, end: 99 */
public DefaultProfileActivationContext
setInactiveProfileIds(List<String> inactiveProfileIds) {
    if (inactiveProfileIds != null) {
        this.inactiveProfileIds =
            Collections.unmodifiableList(inactiveProfileIds);
    } else {
        this.inactiveProfileIds = Collections.emptyList();
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/251.java, start: 137, end: 147 */
public DefaultProfileActivationContext
setSystemProperties(Map<String, String> systemProperties) {
    if (systemProperties != null) {
        this.systemProperties =
            Collections.unmodifiableMap(systemProperties);
    } else {
        this.systemProperties = Collections.emptyMap();
    }

    return this;
}

}
    