
class Java_26{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/796.java, start: 230, end: 241 */
private String insertRepositoryKey(String filename,
                                   String repositoryKey) {
    String result;
    int idx = filename.indexOf('.');
    if (idx < 0) {
        result = filename + '-' + repositoryKey;
    } else {
        result = filename.substring(0, idx) + '-' + repositoryKey +
                 filename.substring(idx);
    }
    return result;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/196.java, start: 110, end: 120 */
private String insertRepositoryKey(String filename, String repositoryKey) {
    String result;
    int idx = filename.indexOf('.');
    if (idx < 0) {
        result = filename + '-' + repositoryKey;
    } else {
        result = filename.substring(0, idx) + '-' + repositoryKey +
                 filename.substring(idx);
    }
    return result;
}

}
    