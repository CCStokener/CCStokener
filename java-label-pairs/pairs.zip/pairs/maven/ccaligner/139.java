
class Java_139{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/456.java, start: 53, end: 59 */
public String getGroupId() {
    if (groupId != null) {
        return groupId;
    } else {
        return artifact.getGroupId();
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/456.java, start: 69, end: 75 */
public String getVersion() {
    if (version != null) {
        return version;
    } else {
        return artifact.getVersion();
    }
}

}
    