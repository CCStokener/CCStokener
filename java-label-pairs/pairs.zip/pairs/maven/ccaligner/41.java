
class Java_41{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1180, end: 1191 */
protected void mergeExclusion_ArtifactId(Exclusion target, Exclusion source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1941, end: 1950 */
protected void mergeNotifier_Type(Notifier target, Notifier source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    String src = source.getType();
    if (src != null) {
        if (sourceDominant || target.getType() == null) {
            target.setType(src);
        }
    }
}

}
    