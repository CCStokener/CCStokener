
class Java_126{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2190, end: 2202 */
protected void mergeBuildBase_DefaultGoal(BuildBase target,
                                          BuildBase source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getDefaultGoal();
    if (src != null) {
        if (sourceDominant || target.getDefaultGoal() == null) {
            target.setDefaultGoal(src);
            target.setLocation("defaultGoal",
                               source.getLocation("defaultGoal"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2611, end: 2622 */
protected void mergeFileSet_Directory(FileSet target, FileSet source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}

}
    