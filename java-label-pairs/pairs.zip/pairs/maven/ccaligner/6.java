
class Java_6{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2016, end: 2027 */
protected void mergePrerequisites_Maven(Prerequisites target,
                                        Prerequisites source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getMaven();
    if (src != null) {
        if (sourceDominant || target.getMaven() == null) {
            target.setMaven(src);
            target.setLocation("maven", source.getLocation("maven"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2055, end: 2067 */
protected void
mergeBuild_ScriptSourceDirectory(Build target, Build source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getScriptSourceDirectory();
    if (src != null) {
        if (sourceDominant || target.getScriptSourceDirectory() == null) {
            target.setScriptSourceDirectory(src);
            target.setLocation("scriptSourceDirectory",
                               source.getLocation("scriptSourceDirectory"));
        }
    }
}

}
    