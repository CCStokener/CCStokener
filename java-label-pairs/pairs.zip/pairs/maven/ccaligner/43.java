
class Java_43{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/731.java, start: 115, end: 124 */
public ProjectBuildingRequest
setRemoteRepositories(List<ArtifactRepository> remoteRepositories) {
    if (remoteRepositories != null) {
        this.remoteRepositories = new ArrayList<>(remoteRepositories);
    } else {
        this.remoteRepositories.clear();
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/292.java, start: 229, end: 238 */
public DefaultModelBuildingRequest
setInactiveProfileIds(List<String> inactiveProfileIds) {
    if (inactiveProfileIds != null) {
        this.inactiveProfileIds = new ArrayList<>(inactiveProfileIds);
    } else {
        this.inactiveProfileIds = null;
    }

    return this;
}

}
    