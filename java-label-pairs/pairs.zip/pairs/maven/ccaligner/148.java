
class Java_148{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 270, end: 281 */
protected void mergeModel_InceptionYear(Model target, Model source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getInceptionYear();
    if (src != null) {
        if (sourceDominant || target.getInceptionYear() == null) {
            target.setInceptionYear(src);
            target.setLocation("inceptionYear",
                               source.getLocation("inceptionYear"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1582, end: 1594 */
protected void mergeMailingList_Unsubscribe(MailingList target,
                                            MailingList source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    String src = source.getUnsubscribe();
    if (src != null) {
        if (sourceDominant || target.getUnsubscribe() == null) {
            target.setUnsubscribe(src);
            target.setLocation("unsubscribe",
                               source.getLocation("unsubscribe"));
        }
    }
}

}
    