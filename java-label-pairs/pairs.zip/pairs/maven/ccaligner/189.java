
class Java_189{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1107, end: 1119 */
protected void mergeDependency_SystemPath(Dependency target,
                                          Dependency source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getSystemPath();
    if (src != null) {
        if (sourceDominant || target.getSystemPath() == null) {
            target.setSystemPath(src);
            target.setLocation("systemPath",
                               source.getLocation("systemPath"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1417, end: 1428 */
protected void mergeParent_ArtifactId(Parent target, Parent source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}

}
    