
class Java_36{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 991, end: 1002 */
protected void mergeRepositoryPolicy_UpdatePolicy(
    RepositoryPolicy target, RepositoryPolicy source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getUpdatePolicy();
    if (src != null) {
        if (sourceDominant || target.getUpdatePolicy() == null) {
            target.setUpdatePolicy(src);
            target.setLocation("updatePolicy",
                               source.getLocation("updatePolicy"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1832, end: 1843 */
protected void mergeScm_Connection(Scm target, Scm source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getConnection();
    if (src != null) {
        if (sourceDominant || target.getConnection() == null) {
            target.setConnection(src);
            target.setLocation("connection",
                               source.getLocation("connection"));
        }
    }
}

}
    