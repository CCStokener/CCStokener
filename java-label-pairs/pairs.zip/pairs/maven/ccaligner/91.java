
class Java_91{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 954, end: 965 */
protected void mergeRepositoryBase_Layout(RepositoryBase target,
                                          RepositoryBase source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getLayout();
    if (src != null) {
        if (sourceDominant || target.getLayout() == null) {
            target.setLayout(src);
            target.setLocation("layout", source.getLocation("layout"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2611, end: 2622 */
protected void mergeFileSet_Directory(FileSet target, FileSet source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}

}
    