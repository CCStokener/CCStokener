
class Java_186{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/591.java, start: 132, end: 142 */
public void flush() {
    for (CacheRecord record : cache.values()) {
        ClassRealm realm = record.realm;
        try {
            realm.getWorld().disposeRealm(realm.getId());
        } catch (NoSuchRealmException e) {
            // ignore
        }
    }
    cache.clear();
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/588.java, start: 171, end: 181 */
public void flush() {
    for (CacheRecord record : cache.values()) {
        ClassRealm realm = record.realm;
        try {
            realm.getWorld().disposeRealm(realm.getId());
        } catch (NoSuchRealmException e) {
            // ignore
        }
    }
    cache.clear();
}

}
    