
class Java_171{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1043, end: 1055 */
protected void mergeDependency_ArtifactId(Dependency target,
                                          Dependency source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2095, end: 2106 */
protected void mergeBuild_TestOutputDirectory(Build target, Build source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    String src = source.getTestOutputDirectory();
    if (src != null) {
        if (sourceDominant || target.getTestOutputDirectory() == null) {
            target.setTestOutputDirectory(src);
            target.setLocation("testOutputDirectory",
                               source.getLocation("testOutputDirectory"));
        }
    }
}

}
    