
class Java_113{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 220, end: 231 */
protected void mergeModel_Packaging(Model target, Model source,
                                    boolean sourceDominant,
                                    Map<Object, Object> context) {
    String src = source.getPackaging();
    if (src != null) {
        if (sourceDominant || target.getPackaging() == null) {
            target.setPackaging(src);
            target.setLocation("packaging",
                               source.getLocation("packaging"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2082, end: 2093 */
protected void mergeBuild_OutputDirectory(Build target, Build source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getOutputDirectory();
    if (src != null) {
        if (sourceDominant || target.getOutputDirectory() == null) {
            target.setOutputDirectory(src);
            target.setLocation("outputDirectory",
                               source.getLocation("outputDirectory"));
        }
    }
}

}
    