
class Java_105{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1430, end: 1440 */
protected void mergeParent_Version(Parent target, Parent source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2095, end: 2106 */
protected void mergeBuild_TestOutputDirectory(Build target, Build source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    String src = source.getTestOutputDirectory();
    if (src != null) {
        if (sourceDominant || target.getTestOutputDirectory() == null) {
            target.setTestOutputDirectory(src);
            target.setLocation("testOutputDirectory",
                               source.getLocation("testOutputDirectory"));
        }
    }
}

}
    