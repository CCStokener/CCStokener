
class Java_172{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1582, end: 1594 */
protected void mergeMailingList_Unsubscribe(MailingList target,
                                            MailingList source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    String src = source.getUnsubscribe();
    if (src != null) {
        if (sourceDominant || target.getUnsubscribe() == null) {
            target.setUnsubscribe(src);
            target.setLocation("unsubscribe",
                               source.getLocation("unsubscribe"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2580, end: 2591 */
protected void mergeResource_Filtering(Resource target, Resource source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getFiltering();
    if (src != null) {
        if (sourceDominant || target.getFiltering() == null) {
            target.setFiltering(src);
            target.setLocation("filtering",
                               source.getLocation("filtering"));
        }
    }
}

}
    