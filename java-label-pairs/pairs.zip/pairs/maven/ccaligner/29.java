
class Java_29{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 411, end: 424 */
protected void mergeModel_Scm(Model target, Model source,
                              boolean sourceDominant,
                              Map<Object, Object> context) {
    Scm src = source.getScm();
    if (src != null) {
        Scm tgt = target.getScm();
        if (tgt == null) {
            tgt = new Scm();
            tgt.setTag(null);
            target.setScm(tgt);
        }
        mergeScm(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 426, end: 438 */
protected void mergeModel_CiManagement(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    CiManagement src = source.getCiManagement();
    if (src != null) {
        CiManagement tgt = target.getCiManagement();
        if (tgt == null) {
            tgt = new CiManagement();
            target.setCiManagement(tgt);
        }
        mergeCiManagement(tgt, src, sourceDominant, context);
    }
}

}
    