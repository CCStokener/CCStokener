
class Java_40{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 111, end: 124 */
protected void mergeModel_Organization(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    Organization src = source.getOrganization();
    if (src != null) {
        Organization tgt = target.getOrganization();
        if (tgt == null) {
            tgt = new Organization();
            tgt.setLocation("", src.getLocation(""));
            target.setOrganization(tgt);
            mergeOrganization(tgt, src, sourceDominant, context);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 693, end: 705 */
protected void mergeDistributionManagement_SnapshotRepository(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    DeploymentRepository src = source.getSnapshotRepository();
    if (src != null) {
        DeploymentRepository tgt = target.getSnapshotRepository();
        if (tgt == null) {
            tgt = new DeploymentRepository();
            target.setSnapshotRepository(tgt);
        }
        mergeDeploymentRepository(tgt, src, sourceDominant, context);
    }
}

}
    