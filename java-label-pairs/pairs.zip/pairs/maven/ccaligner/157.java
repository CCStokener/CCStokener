
class Java_157{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1180, end: 1191 */
protected void mergeExclusion_ArtifactId(Exclusion target, Exclusion source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2069, end: 2080 */
protected void mergeBuild_TestSourceDirectory(Build target, Build source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    String src = source.getTestSourceDirectory();
    if (src != null) {
        if (sourceDominant || target.getTestSourceDirectory() == null) {
            target.setTestSourceDirectory(src);
            target.setLocation("testSourceDirectory",
                               source.getLocation("testSourceDirectory"));
        }
    }
}

}
    