
class Java_14{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1069, end: 1079 */
protected void mergeDependency_Type(Dependency target, Dependency source,
                                    boolean sourceDominant,
                                    Map<Object, Object> context) {
    String src = source.getType();
    if (src != null) {
        if (sourceDominant || target.getType() == null) {
            target.setType(src);
            target.setLocation("type", source.getLocation("type"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1497, end: 1507 */
protected void mergeLicense_Name(License target, License source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}

}
    