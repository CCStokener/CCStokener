
class Java_37{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/217.java, start: 260, end: 297 */
public void
testShouldMergePluginWithDifferentExecutionFromParentWithoutDuplicatingPluginInList() {
    Plugin parent = new Plugin();
    parent.setArtifactId("testArtifact");
    parent.setGroupId("testGroup");
    parent.setVersion("1.0");

    PluginExecution parentExecution = new PluginExecution();
    parentExecution.setId("testExecution");

    parent.addExecution(parentExecution);

    Build parentContainer = new Build();
    parentContainer.addPlugin(parent);

    Plugin child = new Plugin();
    child.setArtifactId("testArtifact");
    child.setGroupId("testGroup");
    child.setVersion("1.0");

    PluginExecution childExecution = new PluginExecution();
    childExecution.setId("testExecution2");

    child.addExecution(childExecution);

    Build childContainer = new Build();
    childContainer.addPlugin(child);

    ModelUtils.mergePluginLists(childContainer, parentContainer, true);

    List plugins = childContainer.getPlugins();

    assertEquals(1, plugins.size());

    Plugin plugin = (Plugin)plugins.get(0);

    assertEquals(2, plugin.getExecutions().size());
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/217.java, start: 299, end: 319 */
public void testShouldNOTMergeInheritedPluginHavingInheritEqualFalse() {
    Plugin parent = new Plugin();
    parent.setArtifactId("testArtifact");
    parent.setGroupId("testGroup");
    parent.setVersion("1.0");
    parent.setInherited("false");

    PluginExecution parentExecution = new PluginExecution();
    parentExecution.setId("testExecution");

    parent.addExecution(parentExecution);

    Plugin child = new Plugin();
    child.setArtifactId("testArtifact");
    child.setGroupId("testGroup");
    child.setVersion("1.0");

    ModelUtils.mergePluginDefinitions(child, parent, true);

    assertEquals(0, child.getExecutions().size());
}

}
    