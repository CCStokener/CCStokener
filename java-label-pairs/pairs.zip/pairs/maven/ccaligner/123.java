
class Java_123{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1031, end: 1041 */
protected void mergeDependency_GroupId(Dependency target, Dependency source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1952, end: 1961 */
protected void mergeNotifier_Address(Notifier target, Notifier source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getAddress();
    if (src != null) {
        if (sourceDominant || target.getAddress() == null) {
            target.setAddress(src);
        }
    }
}

}
    