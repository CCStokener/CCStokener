
class Java_191{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 721, end: 731 */
protected void mergeDistributionManagement_Status(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getStatus();
    if (src != null) {
        if (sourceDominant || target.getStatus() == null) {
            target.setStatus(src);
            target.setLocation("status", source.getLocation("status"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 978, end: 989 */
protected void mergeRepositoryPolicy_Enabled(RepositoryPolicy target,
                                             RepositoryPolicy source,
                                             boolean sourceDominant,
                                             Map<Object, Object> context) {
    String src = source.getEnabled();
    if (src != null) {
        if (sourceDominant || target.getEnabled() == null) {
            target.setEnabled(src);
            target.setLocation("enabled", source.getLocation("enabled"));
        }
    }
}

}
    