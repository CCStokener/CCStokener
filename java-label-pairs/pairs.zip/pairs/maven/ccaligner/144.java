
class Java_144{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 72, end: 88 */
public void
testResolveParentThrowsUnresolvableModelExceptionWhenNoMatchingVersionFound()
    throws Exception {
    final Parent parent = new Parent();
    parent.setGroupId("org.apache");
    parent.setArtifactId("apache");
    parent.setVersion("[2.0,2.1)");

    try {
        this.newModelResolver().resolveModel(parent);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "No versions matched the requested parent version range '[2.0,2.1)'",
            e.getMessage());
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 150, end: 166 */
public void
testResolveDependencyThrowsUnresolvableModelExceptionWhenNoMatchingVersionFound()
    throws Exception {
    final Dependency dependency = new Dependency();
    dependency.setGroupId("org.apache");
    dependency.setArtifactId("apache");
    dependency.setVersion("[2.0,2.1)");

    try {
        this.newModelResolver().resolveModel(dependency);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "No versions matched the requested dependency version range '[2.0,2.1)'",
            e.getMessage());
    }
}

}
    