
class Java_73{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/260.java, start: 78, end: 88 */
protected void mergeModel_Name(Model target, Model source,
                               boolean sourceDominant,
                               Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2406, end: 2417 */
protected void mergePlugin_Extensions(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getExtensions();
    if (src != null) {
        if (sourceDominant || target.getExtensions() == null) {
            target.setExtensions(src);
            target.setLocation("extensions",
                               source.getLocation("extensions"));
        }
    }
}

}
    