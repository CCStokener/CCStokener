
class Java_89{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1608, end: 1619 */
protected void mergeMailingList_Archive(MailingList target,
                                        MailingList source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getArchive();
    if (src != null) {
        if (sourceDominant || target.getArchive() == null) {
            target.setArchive(src);
            target.setLocation("archive", source.getLocation("archive"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2531, end: 2542 */
protected void mergePluginExecution_Phase(PluginExecution target,
                                          PluginExecution source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getPhase();
    if (src != null) {
        if (sourceDominant || target.getPhase() == null) {
            target.setPhase(src);
            target.setLocation("phase", source.getLocation("phase"));
        }
    }
}

}
    