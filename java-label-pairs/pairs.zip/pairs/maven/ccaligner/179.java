
class Java_179{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 991, end: 1002 */
protected void mergeRepositoryPolicy_UpdatePolicy(
    RepositoryPolicy target, RepositoryPolicy source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getUpdatePolicy();
    if (src != null) {
        if (sourceDominant || target.getUpdatePolicy() == null) {
            target.setUpdatePolicy(src);
            target.setLocation("updatePolicy",
                               source.getLocation("updatePolicy"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2166, end: 2176 */
protected void mergeExtension_Version(Extension target, Extension source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}

}
    