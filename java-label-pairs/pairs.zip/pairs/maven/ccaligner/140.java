
class Java_140{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 220, end: 231 */
protected void mergeModel_Packaging(Model target, Model source,
                                    boolean sourceDominant,
                                    Map<Object, Object> context) {
    String src = source.getPackaging();
    if (src != null) {
        if (sourceDominant || target.getPackaging() == null) {
            target.setPackaging(src);
            target.setLocation("packaging",
                               source.getLocation("packaging"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1121, end: 1132 */
protected void mergeDependency_Optional(Dependency target,
                                        Dependency source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getOptional();
    if (src != null) {
        if (sourceDominant || target.getOptional() == null) {
            target.setOptional(src);
            target.setLocation("optional", source.getLocation("optional"));
        }
    }
}

}
    