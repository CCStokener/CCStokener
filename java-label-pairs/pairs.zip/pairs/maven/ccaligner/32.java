
class Java_32{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 941, end: 952 */
protected void mergeRepositoryBase_Name(RepositoryBase target,
                                        RepositoryBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2217, end: 2228 */
protected void mergeBuildBase_FinalName(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getFinalName();
    if (src != null) {
        if (sourceDominant || target.getFinalName() == null) {
            target.setFinalName(src);
            target.setLocation("finalName",
                               source.getLocation("finalName"));
        }
    }
}

}
    