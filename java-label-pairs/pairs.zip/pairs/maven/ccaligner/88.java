
class Java_88{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 233, end: 243 */
protected void mergeModel_Name(Model target, Model source,
                               boolean sourceDominant,
                               Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1168, end: 1178 */
protected void mergeExclusion_GroupId(Exclusion target, Exclusion source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}

}
    