
class Java_120{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 755, end: 765 */
protected void mergeRelocation_GroupId(Relocation target, Relocation source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1845, end: 1856 */
protected void mergeScm_DeveloperConnection(Scm target, Scm source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    String src = source.getDeveloperConnection();
    if (src != null) {
        if (sourceDominant || target.getDeveloperConnection() == null) {
            target.setDeveloperConnection(src);
            target.setLocation("developerConnection",
                               source.getLocation("developerConnection"));
        }
    }
}

}
    