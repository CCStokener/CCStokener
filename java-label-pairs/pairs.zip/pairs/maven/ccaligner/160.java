
class Java_160{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1043, end: 1055 */
protected void mergeDependency_ArtifactId(Dependency target,
                                          Dependency source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1680, end: 1691 */
protected void mergeContributor_Email(Contributor target,
                                      Contributor source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getEmail();
    if (src != null) {
        if (sourceDominant || target.getEmail() == null) {
            target.setEmail(src);
            target.setLocation("email", source.getLocation("email"));
        }
    }
}

}
    