
class Java_4{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 767, end: 779 */
protected void mergeRelocation_ArtifactId(Relocation target,
                                          Relocation source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1733, end: 1744 */
protected void mergeContributor_Timezone(Contributor target,
                                         Contributor source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getTimezone();
    if (src != null) {
        if (sourceDominant || target.getTimezone() == null) {
            target.setTimezone(src);
            target.setLocation("timezone", source.getLocation("timezone"));
        }
    }
}

}
    