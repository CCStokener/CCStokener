
class Java_77{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1081, end: 1093 */
protected void mergeDependency_Classifier(Dependency target,
                                          Dependency source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getClassifier();
    if (src != null) {
        if (sourceDominant || target.getClassifier() == null) {
            target.setClassifier(src);
            target.setLocation("classifier",
                               source.getLocation("classifier"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1521, end: 1532 */
protected void mergeLicense_Distribution(License target, License source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getDistribution();
    if (src != null) {
        if (sourceDominant || target.getDistribution() == null) {
            target.setDistribution(src);
            target.setLocation("distribution",
                               source.getLocation("distribution"));
        }
    }
}

}
    