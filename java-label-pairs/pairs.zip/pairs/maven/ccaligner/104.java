
class Java_104{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1556, end: 1566 */
protected void mergeMailingList_Name(MailingList target, MailingList source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1608, end: 1619 */
protected void mergeMailingList_Archive(MailingList target,
                                        MailingList source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getArchive();
    if (src != null) {
        if (sourceDominant || target.getArchive() == null) {
            target.setArchive(src);
            target.setLocation("archive", source.getLocation("archive"));
        }
    }
}

}
    