
class Java_20{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1521, end: 1532 */
protected void mergeLicense_Distribution(License target, License source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getDistribution();
    if (src != null) {
        if (sourceDominant || target.getDistribution() == null) {
            target.setDistribution(src);
            target.setLocation("distribution",
                               source.getLocation("distribution"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1556, end: 1566 */
protected void mergeMailingList_Name(MailingList target, MailingList source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}

}
    