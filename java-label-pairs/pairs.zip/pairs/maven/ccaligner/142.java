
class Java_142{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 90, end: 106 */
public void
testResolveParentThrowsUnresolvableModelExceptionWhenUsingRangesWithoutUpperBound()
    throws Exception {
    final Parent parent = new Parent();
    parent.setGroupId("org.apache");
    parent.setArtifactId("apache");
    parent.setVersion("[1,)");

    try {
        this.newModelResolver().resolveModel(parent);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "The requested parent version range '[1,)' does not specify an upper bound",
            e.getMessage());
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 132, end: 148 */
public void
testResolveDependencyThrowsUnresolvableModelExceptionWhenNotFound()
    throws Exception {
    final Dependency dependency = new Dependency();
    dependency.setGroupId("org.apache");
    dependency.setArtifactId("apache");
    dependency.setVersion("0");

    try {
        this.newModelResolver().resolveModel(dependency);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertNotNull(e.getMessage());
        assertTrue(e.getMessage().startsWith(
            "Could not find artifact org.apache:apache:pom:0 in central"));
    }
}

}
    