
class Java_175{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 183, end: 193 */
protected void mergeModel_GroupId(Model target, Model source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2567, end: 2578 */
protected void mergeResource_TargetPath(Resource target, Resource source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getTargetPath();
    if (src != null) {
        if (sourceDominant || target.getTargetPath() == null) {
            target.setTargetPath(src);
            target.setLocation("targetPath",
                               source.getLocation("targetPath"));
        }
    }
}

}
    