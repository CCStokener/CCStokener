
class Java_85{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 941, end: 952 */
protected void mergeRepositoryBase_Name(RepositoryBase target,
                                        RepositoryBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1215, end: 1227 */
protected void mergeReporting_ExcludeDefaults(Reporting target,
                                              Reporting source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    String src = source.getExcludeDefaults();
    if (src != null) {
        if (sourceDominant || target.getExcludeDefaults() == null) {
            target.setExcludeDefaults(src);
            target.setLocation("excludeDefaults",
                               source.getLocation("excludeDefaults"));
        }
    }
}

}
    