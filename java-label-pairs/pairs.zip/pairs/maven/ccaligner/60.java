
class Java_60{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 270, end: 281 */
protected void mergeModel_InceptionYear(Model target, Model source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getInceptionYear();
    if (src != null) {
        if (sourceDominant || target.getInceptionYear() == null) {
            target.setInceptionYear(src);
            target.setLocation("inceptionYear",
                               source.getLocation("inceptionYear"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1642, end: 1652 */
protected void mergeDeveloper_Id(Developer target, Developer source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getId();
    if (src != null) {
        if (sourceDominant || target.getId() == null) {
            target.setId(src);
            target.setLocation("id", source.getLocation("id"));
        }
    }
}

}
    