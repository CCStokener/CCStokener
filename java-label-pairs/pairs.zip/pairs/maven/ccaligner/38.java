
class Java_38{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 155, end: 166 */
protected void mergeModel_ModelVersion(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getModelVersion();
    if (src != null) {
        if (sourceDominant || target.getModelVersion() == null) {
            target.setModelVersion(src);
            target.setLocation("modelVersion",
                               source.getLocation("modelVersion"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1264, end: 1275 */
protected void mergeReportPlugin_GroupId(ReportPlugin target,
                                         ReportPlugin source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}

}
    