
class Java_164{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/782.java, start: 259, end: 270 */
public ArtifactResolutionResult
addCircularDependencyException(CyclicDependencyException e) {
    circularDependencyExceptions = initList(circularDependencyExceptions);

    circularDependencyExceptions.add(e);

    exceptions = initList(exceptions);

    exceptions.add(e);

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/72.java, start: 182, end: 193 */
public MetadataResolutionResult
addMetadataResolutionException(ArtifactResolutionException e) {
    metadataResolutionExceptions = initList(metadataResolutionExceptions);

    metadataResolutionExceptions.add(e);

    exceptions = initList(exceptions);

    exceptions.add(e);

    return this;
}

}
    