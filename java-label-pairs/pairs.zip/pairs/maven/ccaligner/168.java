
class Java_168{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 270, end: 281 */
protected void mergeModel_InceptionYear(Model target, Model source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getInceptionYear();
    if (src != null) {
        if (sourceDominant || target.getInceptionYear() == null) {
            target.setInceptionYear(src);
            target.setLocation("inceptionYear",
                               source.getLocation("inceptionYear"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2217, end: 2228 */
protected void mergeBuildBase_FinalName(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getFinalName();
    if (src != null) {
        if (sourceDominant || target.getFinalName() == null) {
            target.setFinalName(src);
            target.setLocation("finalName",
                               source.getLocation("finalName"));
        }
    }
}

}
    