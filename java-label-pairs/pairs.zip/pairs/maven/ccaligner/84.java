
class Java_84{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 511, end: 520 */
public MavenExecutionRequest
setSelectedProjects(List<String> selectedProjects) {
    if (selectedProjects != null) {
        this.selectedProjects = new ArrayList<>(selectedProjects);
    } else {
        this.selectedProjects = null;
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/301.java, start: 127, end: 136 */
public DefaultModelBuildingResult
setActiveExternalProfiles(List<Profile> activeProfiles) {
    if (activeProfiles != null) {
        this.activeExternalProfiles = new ArrayList<>(activeProfiles);
    } else {
        this.activeExternalProfiles.clear();
    }

    return this;
}

}
    