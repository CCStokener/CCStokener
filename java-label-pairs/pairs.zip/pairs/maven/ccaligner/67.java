
class Java_67{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 372, end: 395 */
protected void mergeModel_Contributors(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    List<Contributor> src = source.getContributors();
    if (!src.isEmpty()) {
        List<Contributor> tgt = target.getContributors();
        Map<Object, Contributor> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Contributor element : tgt) {
            Object key = getContributorKey(element);
            merged.put(key, element);
        }

        for (Contributor element : src) {
            Object key = getContributorKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setContributors(new ArrayList<>(merged.values()));
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2324, end: 2348 */
protected void mergePluginContainer_Plugins(PluginContainer target,
                                            PluginContainer source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    List<Plugin> src = source.getPlugins();
    if (!src.isEmpty()) {
        List<Plugin> tgt = target.getPlugins();
        Map<Object, Plugin> merged =
            new LinkedHashMap<>((src.size() + tgt.size()) * 2);

        for (Plugin element : tgt) {
            Object key = getPluginKey(element);
            merged.put(key, element);
        }

        for (Plugin element : src) {
            Object key = getPluginKey(element);
            if (sourceDominant || !merged.containsKey(key)) {
                merged.put(key, element);
            }
        }

        target.setPlugins(new ArrayList<>(merged.values()));
    }
}

}
    