
class Java_109{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 397, end: 409 */
protected void mergeModel_IssueManagement(Model target, Model source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    IssueManagement src = source.getIssueManagement();
    if (src != null) {
        IssueManagement tgt = target.getIssueManagement();
        if (tgt == null) {
            tgt = new IssueManagement();
            target.setIssueManagement(tgt);
        }
        mergeIssueManagement(tgt, src, sourceDominant, context);
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2303, end: 2315 */
protected void mergePluginConfiguration_PluginManagement(
    PluginConfiguration target, PluginConfiguration source,
    boolean sourceDominant, Map<Object, Object> context) {
    PluginManagement src = source.getPluginManagement();
    if (src != null) {
        PluginManagement tgt = target.getPluginManagement();
        if (tgt == null) {
            tgt = new PluginManagement();
            target.setPluginManagement(tgt);
        }
        mergePluginManagement(tgt, src, sourceDominant, context);
    }
}

}
    