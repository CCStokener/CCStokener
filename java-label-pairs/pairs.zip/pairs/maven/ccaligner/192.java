
class Java_192{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/338.java, start: 163, end: 192 */
public void testVersionRangeInclusiveLowerBound() throws Exception {
    Profile profile = newProfile("[1.5,)");

    assertActivation(false, profile,
                     newContext(null, newProperties("1.4")));
    assertActivation(false, profile,
                     newContext(null, newProperties("1.4.2")));
    assertActivation(false, profile,
                     newContext(null, newProperties("1.4.2_09")));
    assertActivation(false, profile,
                     newContext(null, newProperties("1.4.2_09-b03")));

    assertActivation(true, profile, newContext(null, newProperties("1.5")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.5.0")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.5.0_09")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.5.0_09-b03")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.5.1")));

    assertActivation(true, profile, newContext(null, newProperties("1.6")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.6.0")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.6.0_09")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.6.0_09-b03")));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/338.java, start: 194, end: 215 */
public void testVersionRangeExclusiveUpperBound() throws Exception {
    Profile profile = newProfile("(,1.6)");

    assertActivation(true, profile, newContext(null, newProperties("1.5")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.5.0")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.5.0_09")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.5.0_09-b03")));
    assertActivation(true, profile,
                     newContext(null, newProperties("1.5.1")));

    assertActivation(false, profile,
                     newContext(null, newProperties("1.6")));
    assertActivation(false, profile,
                     newContext(null, newProperties("1.6.0")));
    assertActivation(false, profile,
                     newContext(null, newProperties("1.6.0_09")));
    assertActivation(false, profile,
                     newContext(null, newProperties("1.6.0_09-b03")));
}

}
    