
class Java_176{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1760, end: 1777 */
protected void mergeContributor_Properties(Contributor target,
                                           Contributor source,
                                           boolean sourceDominant,
                                           Map<Object, Object> context) {
    Properties merged = new Properties();
    if (sourceDominant) {
        merged.putAll(target.getProperties());
        merged.putAll(source.getProperties());
    } else {
        merged.putAll(source.getProperties());
        merged.putAll(target.getProperties());
    }
    target.setProperties(merged);
    target.setLocation("properties",
                       InputLocation.merge(target.getLocation("properties"),
                                           source.getLocation("properties"),
                                           sourceDominant));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1963, end: 1975 */
protected void mergeNotifier_Configuration(Notifier target, Notifier source,
                                           boolean sourceDominant,
                                           Map<Object, Object> context) {
    Properties merged = new Properties();
    if (sourceDominant) {
        merged.putAll(target.getConfiguration());
        merged.putAll(source.getConfiguration());
    } else {
        merged.putAll(source.getConfiguration());
        merged.putAll(target.getConfiguration());
    }
    target.setConfiguration(merged);
}

}
    