
class Java_107{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1509, end: 1519 */
protected void mergeLicense_Url(License target, License source,
                                boolean sourceDominant,
                                Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant || target.getUrl() == null) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1845, end: 1856 */
protected void mergeScm_DeveloperConnection(Scm target, Scm source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    String src = source.getDeveloperConnection();
    if (src != null) {
        if (sourceDominant || target.getDeveloperConnection() == null) {
            target.setDeveloperConnection(src);
            target.setLocation("developerConnection",
                               source.getLocation("developerConnection"));
        }
    }
}

}
    