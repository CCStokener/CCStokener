
class Java_162{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1121, end: 1132 */
protected void mergeDependency_Optional(Dependency target,
                                        Dependency source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getOptional();
    if (src != null) {
        if (sourceDominant || target.getOptional() == null) {
            target.setOptional(src);
            target.setLocation("optional", source.getLocation("optional"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1568, end: 1580 */
protected void mergeMailingList_Subscribe(MailingList target,
                                          MailingList source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getSubscribe();
    if (src != null) {
        if (sourceDominant || target.getSubscribe() == null) {
            target.setSubscribe(src);
            target.setLocation("subscribe",
                               source.getLocation("subscribe"));
        }
    }
}

}
    