
class Java_79{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/787.java, start: 61, end: 73 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof ExclusionSetFilter)) {
        return false;
    }

    ExclusionSetFilter other = (ExclusionSetFilter)obj;

    return excludes.equals(other.excludes);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/148.java, start: 65, end: 77 */
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }

    if (!(obj instanceof OrArtifactFilter)) {
        return false;
    }

    OrArtifactFilter other = (OrArtifactFilter)obj;

    return filters.equals(other.filters);
}

}
    