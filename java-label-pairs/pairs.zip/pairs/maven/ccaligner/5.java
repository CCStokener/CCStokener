
class Java_5{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1705, end: 1717 */
protected void mergeContributor_Organization(Contributor target,
                                             Contributor source,
                                             boolean sourceDominant,
                                             Map<Object, Object> context) {
    String src = source.getOrganization();
    if (src != null) {
        if (sourceDominant || target.getOrganization() == null) {
            target.setOrganization(src);
            target.setLocation("organization",
                               source.getLocation("organization"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2518, end: 2529 */
protected void mergePluginExecution_Id(PluginExecution target,
                                       PluginExecution source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getId();
    if (src != null) {
        if (sourceDominant || target.getId() == null) {
            target.setId(src);
            target.setLocation("id", source.getLocation("id"));
        }
    }
}

}
    