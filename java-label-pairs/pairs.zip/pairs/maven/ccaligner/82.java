
class Java_82{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 915, end: 926 */
protected void mergeRepositoryBase_Id(RepositoryBase target,
                                      RepositoryBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getId();
    if (src != null) {
        if (sourceDominant || target.getId() == null) {
            target.setId(src);
            target.setLocation("id", source.getLocation("id"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1821, end: 1830 */
protected void mergeScm_Url(Scm target, Scm source, boolean sourceDominant,
                            Map<Object, Object> context) {
    String src = source.getUrl();
    if (src != null) {
        if (sourceDominant || target.getUrl() == null) {
            target.setUrl(src);
            target.setLocation("url", source.getLocation("url"));
        }
    }
}

}
    