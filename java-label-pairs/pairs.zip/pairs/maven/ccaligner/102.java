
class Java_102{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1031, end: 1041 */
protected void mergeDependency_GroupId(Dependency target, Dependency source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1733, end: 1744 */
protected void mergeContributor_Timezone(Contributor target,
                                         Contributor source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getTimezone();
    if (src != null) {
        if (sourceDominant || target.getTimezone() == null) {
            target.setTimezone(src);
            target.setLocation("timezone", source.getLocation("timezone"));
        }
    }
}

}
    