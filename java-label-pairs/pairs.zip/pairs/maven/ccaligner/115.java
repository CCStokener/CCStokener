
class Java_115{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 155, end: 166 */
protected void mergeModel_ModelVersion(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getModelVersion();
    if (src != null) {
        if (sourceDominant || target.getModelVersion() == null) {
            target.setModelVersion(src);
            target.setLocation("modelVersion",
                               source.getLocation("modelVersion"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 978, end: 989 */
protected void mergeRepositoryPolicy_Enabled(RepositoryPolicy target,
                                             RepositoryPolicy source,
                                             boolean sourceDominant,
                                             Map<Object, Object> context) {
    String src = source.getEnabled();
    if (src != null) {
        if (sourceDominant || target.getEnabled() == null) {
            target.setEnabled(src);
            target.setLocation("enabled", source.getLocation("enabled"));
        }
    }
}

}
    