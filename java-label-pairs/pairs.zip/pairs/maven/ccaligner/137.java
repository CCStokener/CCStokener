
class Java_137{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1941, end: 1950 */
protected void mergeNotifier_Type(Notifier target, Notifier source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    String src = source.getType();
    if (src != null) {
        if (sourceDominant || target.getType() == null) {
            target.setType(src);
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2381, end: 2392 */
protected void mergePlugin_ArtifactId(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}

}
    