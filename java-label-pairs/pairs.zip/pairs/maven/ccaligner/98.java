
class Java_98{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 721, end: 731 */
protected void mergeDistributionManagement_Status(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getStatus();
    if (src != null) {
        if (sourceDominant || target.getStatus() == null) {
            target.setStatus(src);
            target.setLocation("status", source.getLocation("status"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1845, end: 1856 */
protected void mergeScm_DeveloperConnection(Scm target, Scm source,
                                            boolean sourceDominant,
                                            Map<Object, Object> context) {
    String src = source.getDeveloperConnection();
    if (src != null) {
        if (sourceDominant || target.getDeveloperConnection() == null) {
            target.setDeveloperConnection(src);
            target.setLocation("developerConnection",
                               source.getLocation("developerConnection"));
        }
    }
}

}
    