
class Java_58{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1291, end: 1302 */
protected void mergeReportPlugin_Version(ReportPlugin target,
                                         ReportPlugin source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2518, end: 2529 */
protected void mergePluginExecution_Id(PluginExecution target,
                                       PluginExecution source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getId();
    if (src != null) {
        if (sourceDominant || target.getId() == null) {
            target.setId(src);
            target.setLocation("id", source.getLocation("id"));
        }
    }
}

}
    