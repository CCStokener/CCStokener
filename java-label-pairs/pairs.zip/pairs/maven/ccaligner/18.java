
class Java_18{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1534, end: 1544 */
protected void mergeLicense_Comments(License target, License source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getComments();
    if (src != null) {
        if (sourceDominant || target.getComments() == null) {
            target.setComments(src);
            target.setLocation("comments", source.getLocation("comments"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1680, end: 1691 */
protected void mergeContributor_Email(Contributor target,
                                      Contributor source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getEmail();
    if (src != null) {
        if (sourceDominant || target.getEmail() == null) {
            target.setEmail(src);
            target.setLocation("email", source.getLocation("email"));
        }
    }
}

}
    