
class Java_1{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 459, end: 469 */
public void testOrderOfPluginExecutionsWithoutPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-exec-order/wo-plugin-mgmt");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/executions")).size());
    assertEquals("b", pom.getValue("build/plugins[1]/executions[1]/id"));
    assertEquals("a", pom.getValue("build/plugins[1]/executions[2]/id"));
    assertEquals("d", pom.getValue("build/plugins[1]/executions[3]/id"));
    assertEquals("c", pom.getValue("build/plugins[1]/executions[4]/id"));
    assertEquals("e", pom.getValue("build/plugins[1]/executions[5]/id"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 1995, end: 2011 */
public void testPluginInheritanceOrder() throws Exception {
    PomTestWrapper pom = buildPom("plugin-inheritance-order/child");

    assertEquals("maven-it-plugin-log-file",
                 pom.getValue("build/plugins[1]/artifactId"));
    assertEquals("maven-it-plugin-expression",
                 pom.getValue("build/plugins[2]/artifactId"));
    assertEquals("maven-it-plugin-configuration",
                 pom.getValue("build/plugins[3]/artifactId"));

    assertEquals("maven-it-plugin-log-file",
                 pom.getValue("reporting/plugins[1]/artifactId"));
    assertEquals("maven-it-plugin-expression",
                 pom.getValue("reporting/plugins[2]/artifactId"));
    assertEquals("maven-it-plugin-configuration",
                 pom.getValue("reporting/plugins[3]/artifactId"));
}

}
    