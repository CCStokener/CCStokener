
class Java_21{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 208, end: 218 */
protected void mergeModel_Version(Model target, Model source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1004, end: 1015 */
protected void mergeRepositoryPolicy_ChecksumPolicy(
    RepositoryPolicy target, RepositoryPolicy source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getChecksumPolicy();
    if (src != null) {
        if (sourceDominant || target.getChecksumPolicy() == null) {
            target.setChecksumPolicy(src);
            target.setLocation("checksumPolicy",
                               source.getLocation("checksumPolicy"));
        }
    }
}

}
    