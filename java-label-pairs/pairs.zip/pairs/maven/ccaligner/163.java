
class Java_163{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 941, end: 952 */
protected void mergeRepositoryBase_Name(RepositoryBase target,
                                        RepositoryBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1442, end: 1453 */
protected void mergeParent_RelativePath(Parent target, Parent source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getRelativePath();
    if (src != null) {
        if (sourceDominant || target.getRelativePath() == null) {
            target.setRelativePath(src);
            target.setLocation("relativePath",
                               source.getLocation("relativePath"));
        }
    }
}

}
    