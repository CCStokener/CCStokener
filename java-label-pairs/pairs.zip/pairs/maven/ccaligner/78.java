
class Java_78{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/886.java, start: 47, end: 54 */
private Parent createParent(String groupId, String artifactId,
                            String version) {
    Parent plugin = new Parent();
    plugin.setGroupId(groupId);
    plugin.setArtifactId(artifactId);
    plugin.setVersion(version);
    return plugin;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/50.java, start: 176, end: 195 */
public MetadataGraphVertex addVertex(ArtifactMetadata md) {
    if (md == null) {
        return null;
    }

    checkVertices();

    MetadataGraphVertex v = findVertex(md);
    if (v != null) {
        return v;
    }

    v = new MetadataGraphVertex(md);

    v.setCompareVersion(versionedVertices);
    v.setCompareScope(scopedVertices);

    vertices.add(v);
    return v;
}

}
    