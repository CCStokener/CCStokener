
class Java_149{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/893.java, start: 72, end: 88 */
public void
testResolveParentThrowsUnresolvableModelExceptionWhenNoMatchingVersionFound()
    throws Exception {
    final Parent parent = new Parent();
    parent.setGroupId("org.apache");
    parent.setArtifactId("apache");
    parent.setVersion("[2.0,2.1)");

    try {
        this.newModelResolver().resolveModel(parent);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "No versions matched the requested parent version range '[2.0,2.1)'",
            e.getMessage());
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/477.java, start: 81, end: 97 */
public void
testResolveParentThrowsUnresolvableModelExceptionWhenUsingRangesWithoutUpperBound()
    throws Exception {
    final Parent parent = new Parent();
    parent.setGroupId("ut.simple");
    parent.setArtifactId("artifact");
    parent.setVersion("[1.0,)");

    try {
        this.newModelResolver().resolveModel(parent);
        fail("Expected 'UnresolvableModelException' not thrown.");
    } catch (final UnresolvableModelException e) {
        assertEquals(
            "The requested parent version range '[1.0,)' does not specify an upper bound",
            e.getMessage());
    }
}

}
    