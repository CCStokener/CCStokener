
class Java_185{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1107, end: 1119 */
protected void mergeDependency_SystemPath(Dependency target,
                                          Dependency source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getSystemPath();
    if (src != null) {
        if (sourceDominant || target.getSystemPath() == null) {
            target.setSystemPath(src);
            target.setLocation("systemPath",
                               source.getLocation("systemPath"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2567, end: 2578 */
protected void mergeResource_TargetPath(Resource target, Resource source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getTargetPath();
    if (src != null) {
        if (sourceDominant || target.getTargetPath() == null) {
            target.setTargetPath(src);
            target.setLocation("targetPath",
                               source.getLocation("targetPath"));
        }
    }
}

}
    