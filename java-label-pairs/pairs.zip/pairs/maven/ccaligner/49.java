
class Java_49{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1668, end: 1678 */
protected void mergeContributor_Name(Contributor target, Contributor source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getName();
    if (src != null) {
        if (sourceDominant || target.getName() == null) {
            target.setName(src);
            target.setLocation("name", source.getLocation("name"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2069, end: 2080 */
protected void mergeBuild_TestSourceDirectory(Build target, Build source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    String src = source.getTestSourceDirectory();
    if (src != null) {
        if (sourceDominant || target.getTestSourceDirectory() == null) {
            target.setTestSourceDirectory(src);
            target.setLocation("testSourceDirectory",
                               source.getLocation("testSourceDirectory"));
        }
    }
}

}
    