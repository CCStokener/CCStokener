
class Java_34{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/732.java, start: 60, end: 72 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return extensionRealms.equals(other.extensionRealms);
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/591.java, start: 83, end: 97 */
public boolean equals(Object o) {
    if (o == this) {
        return true;
    }

    if (!(o instanceof CacheKey)) {
        return false;
    }

    CacheKey other = (CacheKey)o;

    return ids.equals(other.ids) && files.equals(other.files) &&
        timestamps.equals(other.timestamps) &&
        sizes.equals(other.sizes);
}

}
    