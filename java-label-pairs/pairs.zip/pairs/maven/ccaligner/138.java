
class Java_138{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 183, end: 193 */
protected void mergeModel_GroupId(Model target, Model source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2082, end: 2093 */
protected void mergeBuild_OutputDirectory(Build target, Build source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getOutputDirectory();
    if (src != null) {
        if (sourceDominant || target.getOutputDirectory() == null) {
            target.setOutputDirectory(src);
            target.setLocation("outputDirectory",
                               source.getLocation("outputDirectory"));
        }
    }
}

}
    