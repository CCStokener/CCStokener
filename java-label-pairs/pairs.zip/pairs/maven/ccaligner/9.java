
class Java_9{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2369, end: 2379 */
protected void mergePlugin_GroupId(Plugin target, Plugin source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2611, end: 2622 */
protected void mergeFileSet_Directory(FileSet target, FileSet source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}

}
    