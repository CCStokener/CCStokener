
class Java_183{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1705, end: 1717 */
protected void mergeContributor_Organization(Contributor target,
                                             Contributor source,
                                             boolean sourceDominant,
                                             Map<Object, Object> context) {
    String src = source.getOrganization();
    if (src != null) {
        if (sourceDominant || target.getOrganization() == null) {
            target.setOrganization(src);
            target.setLocation("organization",
                               source.getLocation("organization"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2381, end: 2392 */
protected void mergePlugin_ArtifactId(Plugin target, Plugin source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getArtifactId();
    if (src != null) {
        if (sourceDominant || target.getArtifactId() == null) {
            target.setArtifactId(src);
            target.setLocation("artifactId",
                               source.getLocation("artifactId"));
        }
    }
}

}
    