
class Java_92{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 155, end: 166 */
protected void mergeModel_ModelVersion(Model target, Model source,
                                       boolean sourceDominant,
                                       Map<Object, Object> context) {
    String src = source.getModelVersion();
    if (src != null) {
        if (sourceDominant || target.getModelVersion() == null) {
            target.setModelVersion(src);
            target.setLocation("modelVersion",
                               source.getLocation("modelVersion"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1291, end: 1302 */
protected void mergeReportPlugin_Version(ReportPlugin target,
                                         ReportPlugin source,
                                         boolean sourceDominant,
                                         Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}

}
    