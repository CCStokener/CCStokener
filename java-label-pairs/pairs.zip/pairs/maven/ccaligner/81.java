
class Java_81{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/582.java, start: 38, end: 61 */
private static String format(LocalRepository localRepository,
                             List<RemoteRepository> remoteRepositories) {
    String repos = "[";

    if (localRepository != null) {
        repos += localRepository.getId() + " (" +
                 localRepository.getBasedir() + ")";
    }

    if (remoteRepositories != null && !remoteRepositories.isEmpty()) {
        for (RemoteRepository repository : remoteRepositories) {
            repos += ", ";

            if (repository != null) {
                repos +=
                    repository.getId() + " (" + repository.getUrl() + ")";
            }
        }
    }

    repos += "]";

    return repos;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/552.java, start: 73, end: 96 */
private static String format(LocalRepository localRepository,
                             List<RemoteRepository> remoteRepositories) {
    String repos = "[";

    if (localRepository != null) {
        repos += localRepository.getId() + " (" +
                 localRepository.getBasedir() + ")";
    }

    if (remoteRepositories != null && !remoteRepositories.isEmpty()) {
        for (RemoteRepository repository : remoteRepositories) {
            repos += ", ";

            if (repository != null) {
                repos +=
                    repository.getId() + " (" + repository.getUrl() + ")";
            }
        }
    }

    repos += "]";

    return repos;
}

}
    