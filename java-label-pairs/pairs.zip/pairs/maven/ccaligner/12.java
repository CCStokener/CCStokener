
class Java_12{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1442, end: 1453 */
protected void mergeParent_RelativePath(Parent target, Parent source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getRelativePath();
    if (src != null) {
        if (sourceDominant || target.getRelativePath() == null) {
            target.setRelativePath(src);
            target.setLocation("relativePath",
                               source.getLocation("relativePath"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1787, end: 1798 */
protected void mergeIssueManagement_System(IssueManagement target,
                                           IssueManagement source,
                                           boolean sourceDominant,
                                           Map<Object, Object> context) {
    String src = source.getSystem();
    if (src != null) {
        if (sourceDominant || target.getSystem() == null) {
            target.setSystem(src);
            target.setLocation("system", source.getLocation("system"));
        }
    }
}

}
    