
class Java_119{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 95, end: 105 */
public void testProfileModules() throws Exception {
    PomTestWrapper pom = buildPom("profile-module", "a");
    assertEquals(
        "test-prop",
        pom.getValue("properties[1]/b")); // verifies profile applied
    assertEquals(4, ((List<?>)pom.getValue("modules")).size());
    assertEquals("module-2", pom.getValue("modules[1]"));
    assertEquals("module-1", pom.getValue("modules[2]"));
    assertEquals("module-3", pom.getValue("modules[3]"));
    assertEquals("module-4", pom.getValue("modules[4]"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 659, end: 685 */
public void testOrderOfMergedPluginDependenciesWithPluginManagement()
    throws Exception {
    PomTestWrapper pom =
        buildPom("merged-plugin-class-path-order/w-plugin-mgmt/sub");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/dependencies")).size());
    assertEquals(
        "c", pom.getValue("build/plugins[1]/dependencies[1]/artifactId"));
    assertEquals("1",
                 pom.getValue("build/plugins[1]/dependencies[1]/version"));
    assertEquals(
        "a", pom.getValue("build/plugins[1]/dependencies[2]/artifactId"));
    assertEquals("2",
                 pom.getValue("build/plugins[1]/dependencies[2]/version"));
    assertEquals(
        "b", pom.getValue("build/plugins[1]/dependencies[3]/artifactId"));
    assertEquals("1",
                 pom.getValue("build/plugins[1]/dependencies[3]/version"));
    assertEquals(
        "e", pom.getValue("build/plugins[1]/dependencies[4]/artifactId"));
    assertEquals("1",
                 pom.getValue("build/plugins[1]/dependencies[4]/version"));
    assertEquals(
        "d", pom.getValue("build/plugins[1]/dependencies[5]/artifactId"));
    assertEquals("1",
                 pom.getValue("build/plugins[1]/dependencies[5]/version"));
}

}
    