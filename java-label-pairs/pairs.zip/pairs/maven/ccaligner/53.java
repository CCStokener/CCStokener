
class Java_53{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2204, end: 2215 */
protected void mergeBuildBase_Directory(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2480, end: 2491 */
protected void mergeConfigurationContainer_Inherited(
    ConfigurationContainer target, ConfigurationContainer source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getInherited();
    if (src != null) {
        if (sourceDominant || target.getInherited() == null) {
            target.setInherited(src);
            target.setLocation("inherited",
                               source.getLocation("inherited"));
        }
    }
}

}
    