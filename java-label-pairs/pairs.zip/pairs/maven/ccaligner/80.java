
class Java_80{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1430, end: 1440 */
protected void mergeParent_Version(Parent target, Parent source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1952, end: 1961 */
protected void mergeNotifier_Address(Notifier target, Notifier source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getAddress();
    if (src != null) {
        if (sourceDominant || target.getAddress() == null) {
            target.setAddress(src);
        }
    }
}

}
    