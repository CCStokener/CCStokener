
class Java_136{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2166, end: 2176 */
protected void mergeExtension_Version(Extension target, Extension source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getVersion();
    if (src != null) {
        if (sourceDominant || target.getVersion() == null) {
            target.setVersion(src);
            target.setLocation("version", source.getLocation("version"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2204, end: 2215 */
protected void mergeBuildBase_Directory(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}

}
    