
class Java_23{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 183, end: 193 */
protected void mergeModel_GroupId(Model target, Model source,
                                  boolean sourceDominant,
                                  Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 220, end: 231 */
protected void mergeModel_Packaging(Model target, Model source,
                                    boolean sourceDominant,
                                    Map<Object, Object> context) {
    String src = source.getPackaging();
    if (src != null) {
        if (sourceDominant || target.getPackaging() == null) {
            target.setPackaging(src);
            target.setLocation("packaging",
                               source.getLocation("packaging"));
        }
    }
}

}
    