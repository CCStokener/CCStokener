
class Java_155{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 270, end: 281 */
protected void mergeModel_InceptionYear(Model target, Model source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getInceptionYear();
    if (src != null) {
        if (sourceDominant || target.getInceptionYear() == null) {
            target.setInceptionYear(src);
            target.setLocation("inceptionYear",
                               source.getLocation("inceptionYear"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 915, end: 926 */
protected void mergeRepositoryBase_Id(RepositoryBase target,
                                      RepositoryBase source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getId();
    if (src != null) {
        if (sourceDominant || target.getId() == null) {
            target.setId(src);
            target.setLocation("id", source.getLocation("id"));
        }
    }
}

}
    