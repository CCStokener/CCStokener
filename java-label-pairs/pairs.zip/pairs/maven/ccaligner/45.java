
class Java_45{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1201, end: 1213 */
protected void mergeReporting_OutputDirectory(Reporting target,
                                              Reporting source,
                                              boolean sourceDominant,
                                              Map<Object, Object> context) {
    String src = source.getOutputDirectory();
    if (src != null) {
        if (sourceDominant || target.getOutputDirectory() == null) {
            target.setOutputDirectory(src);
            target.setLocation("outputDirectory",
                               source.getLocation("outputDirectory"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2141, end: 2151 */
protected void mergeExtension_GroupId(Extension target, Extension source,
                                      boolean sourceDominant,
                                      Map<Object, Object> context) {
    String src = source.getGroupId();
    if (src != null) {
        if (sourceDominant || target.getGroupId() == null) {
            target.setGroupId(src);
            target.setLocation("groupId", source.getLocation("groupId"));
        }
    }
}

}
    