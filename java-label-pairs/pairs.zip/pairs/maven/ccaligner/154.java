
class Java_154{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1095, end: 1105 */
protected void mergeDependency_Scope(Dependency target, Dependency source,
                                     boolean sourceDominant,
                                     Map<Object, Object> context) {
    String src = source.getScope();
    if (src != null) {
        if (sourceDominant || target.getScope() == null) {
            target.setScope(src);
            target.setLocation("scope", source.getLocation("scope"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2055, end: 2067 */
protected void
mergeBuild_ScriptSourceDirectory(Build target, Build source,
                                 boolean sourceDominant,
                                 Map<Object, Object> context) {
    String src = source.getScriptSourceDirectory();
    if (src != null) {
        if (sourceDominant || target.getScriptSourceDirectory() == null) {
            target.setScriptSourceDirectory(src);
            target.setLocation("scriptSourceDirectory",
                               source.getLocation("scriptSourceDirectory"));
        }
    }
}

}
    