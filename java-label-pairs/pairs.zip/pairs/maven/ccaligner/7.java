
class Java_7{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 220, end: 231 */
protected void mergeModel_Packaging(Model target, Model source,
                                    boolean sourceDominant,
                                    Map<Object, Object> context) {
    String src = source.getPackaging();
    if (src != null) {
        if (sourceDominant || target.getPackaging() == null) {
            target.setPackaging(src);
            target.setLocation("packaging",
                               source.getLocation("packaging"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 1832, end: 1843 */
protected void mergeScm_Connection(Scm target, Scm source,
                                   boolean sourceDominant,
                                   Map<Object, Object> context) {
    String src = source.getConnection();
    if (src != null) {
        if (sourceDominant || target.getConnection() == null) {
            target.setConnection(src);
            target.setLocation("connection",
                               source.getLocation("connection"));
        }
    }
}

}
    