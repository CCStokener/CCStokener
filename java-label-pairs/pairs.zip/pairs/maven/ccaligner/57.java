
class Java_57{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/504.java, start: 491, end: 500 */
public MavenExecutionRequest setUserProperties(Properties userProperties) {
    if (userProperties != null) {
        this.userProperties = new Properties();
        this.userProperties.putAll(userProperties);
    } else {
        this.userProperties = null;
    }

    return this;
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/292.java, start: 276, end: 286 */
public DefaultModelBuildingRequest
setUserProperties(Properties userProperties) {
    if (userProperties != null) {
        this.userProperties = new Properties();
        this.userProperties.putAll(userProperties);
    } else {
        this.userProperties = null;
    }

    return this;
}

}
    