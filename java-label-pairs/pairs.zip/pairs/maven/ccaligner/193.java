
class Java_193{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2016, end: 2027 */
protected void mergePrerequisites_Maven(Prerequisites target,
                                        Prerequisites source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getMaven();
    if (src != null) {
        if (sourceDominant || target.getMaven() == null) {
            target.setMaven(src);
            target.setLocation("maven", source.getLocation("maven"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2204, end: 2215 */
protected void mergeBuildBase_Directory(BuildBase target, BuildBase source,
                                        boolean sourceDominant,
                                        Map<Object, Object> context) {
    String src = source.getDirectory();
    if (src != null) {
        if (sourceDominant || target.getDirectory() == null) {
            target.setDirectory(src);
            target.setLocation("directory",
                               source.getLocation("directory"));
        }
    }
}

}
    