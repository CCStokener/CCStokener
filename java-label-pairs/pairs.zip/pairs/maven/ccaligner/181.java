
class Java_181{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 733, end: 744 */
protected void mergeDistributionManagement_DownloadUrl(
    DistributionManagement target, DistributionManagement source,
    boolean sourceDominant, Map<Object, Object> context) {
    String src = source.getDownloadUrl();
    if (src != null) {
        if (sourceDominant || target.getDownloadUrl() == null) {
            target.setDownloadUrl(src);
            target.setLocation("downloadUrl",
                               source.getLocation("downloadUrl"));
        }
    }
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/2.java, start: 2082, end: 2093 */
protected void mergeBuild_OutputDirectory(Build target, Build source,
                                          boolean sourceDominant,
                                          Map<Object, Object> context) {
    String src = source.getOutputDirectory();
    if (src != null) {
        if (sourceDominant || target.getOutputDirectory() == null) {
            target.setOutputDirectory(src);
            target.setLocation("outputDirectory",
                               source.getLocation("outputDirectory"));
        }
    }
}

}
    