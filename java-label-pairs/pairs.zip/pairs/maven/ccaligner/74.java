
class Java_74{
    /**sim: 0.00**/
    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 422, end: 438 */
public void testOrderOfGoalsFromPluginExecutionWithoutPluginManagement()
    throws Exception {
    PomTestWrapper pom = buildPom("plugin-exec-goals-order/wo-plugin-mgmt");
    assertEquals(
        5, ((List<?>)pom.getValue("build/plugins[1]/executions[1]/goals"))
               .size());
    assertEquals("b",
                 pom.getValue("build/plugins[1]/executions[1]/goals[1]"));
    assertEquals("a",
                 pom.getValue("build/plugins[1]/executions[1]/goals[2]"));
    assertEquals("d",
                 pom.getValue("build/plugins[1]/executions[1]/goals[3]"));
    assertEquals("c",
                 pom.getValue("build/plugins[1]/executions[1]/goals[4]"));
    assertEquals("e",
                 pom.getValue("build/plugins[1]/executions[1]/goals[5]"));
}


    /*============================*/

    /**path: /home/wwj/dataset/8projects/java_format/maven/892.java, start: 723, end: 748 */
public void testAppendArtifactIdOfParentAndChildToInheritedUrls()
    throws Exception {
    PomTestWrapper pom = buildPom("url-inheritance/another-parent/sub");
    assertEquals("http://parent.url/ap/child", pom.getValue("url"));
    assertEquals("http://parent.url/org", pom.getValue("organization/url"));
    assertEquals("http://parent.url/license.txt",
                 pom.getValue("licenses[1]/url"));
    assertEquals("http://parent.url/viewvc/ap/child",
                 pom.getValue("scm/url"));
    assertEquals("http://parent.url/scm/ap/child",
                 pom.getValue("scm/connection"));
    assertEquals("https://parent.url/scm/ap/child",
                 pom.getValue("scm/developerConnection"));
    assertEquals("http://parent.url/issues",
                 pom.getValue("issueManagement/url"));
    assertEquals("http://parent.url/ci", pom.getValue("ciManagement/url"));
    assertEquals("http://parent.url/dist",
                 pom.getValue("distributionManagement/repository/url"));
    assertEquals(
        "http://parent.url/snaps",
        pom.getValue("distributionManagement/snapshotRepository/url"));
    assertEquals("http://parent.url/site/ap/child",
                 pom.getValue("distributionManagement/site/url"));
    assertEquals("http://parent.url/download",
                 pom.getValue("distributionManagement/downloadUrl"));
}

}
    