This directory contains some helper apps and scripts for setting
up Microsoft Access, SQL Server or Sybase databases to use with 
the examples in examples/Table.  For details see the online
documentation in:

    http://java.sun.com/products/jfc/swingdoc-current/db.html


