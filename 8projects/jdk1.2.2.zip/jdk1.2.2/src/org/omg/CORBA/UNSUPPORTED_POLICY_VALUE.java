/*
 * @(#)UNSUPPORTED_POLICY_VALUE.java	1.3 01/11/29
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package org.omg.CORBA;

public interface UNSUPPORTED_POLICY_VALUE {
    final short value = (short) (4L);
};
