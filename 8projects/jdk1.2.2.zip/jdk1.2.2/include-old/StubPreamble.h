/*
 * @(#)StubPreamble.h	1.11 01/11/29
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _JAVASOFT_STUB_PREAMBLE_
#define _JAVASOFT_STUB_PREAMBLE_

/*
 * Preamble for stubs.
 *
 * NOTE: This file should include only those
 * declarations that can be used by java stub 
 * routines.
 */

#include "oobj.h"
#include "interpreter.h"

#endif /* !_JAVASOFT_STUB_PREAMBLE_ */
