/*
 * @(#)byteorder_md.h	1.11 01/11/29
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/*
 * Solaris-dependent byte order include
 */

#ifndef _JAVASOFT_SOLARIS_BYTE_MD_H_
#define _JAVASOFT_SOLARIS_BYTE_MD_H_

#include <netinet/in.h>

#endif /* !_JAVASOFT_SOLARIS_BYTE_MD_H_ */
