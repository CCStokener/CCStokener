/*
 * @(#)jmath_md.h	1.12 01/11/29
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#include <math.h>

#define DREM(a,b) fmod(a,b)
