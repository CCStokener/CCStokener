/*
 * @(#)path_md.h	1.23 01/11/29
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/*
 * Solaris-dependent search path definitions and API
 */

#ifndef _JAVASOFT_SOLARIS_PATH_MD_H_
#define _JAVASOFT_SOLARIS_PATH_MD_H_

#define PATH_SEPARATOR          ":"
#define PATH_CURDIR             "."

#define	DIR_SEPARATOR		'/'
#define	LOCAL_DIR_SEPARATOR	'/'

#endif /* !_JAVASOFT_SOLARIS_PATH_MD_H_ */
