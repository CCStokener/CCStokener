int
inet_aton(const char *cp, struct in_addr *addr);
