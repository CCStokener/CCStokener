/*-------------------------------------------------------------------------
 *
 * machine.h--
 *    
 *
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 * machine.h,v 1.1.1.1 1994/11/07 05:19:38 andrew Exp
 *
 *-------------------------------------------------------------------------
 */
#ifndef MACHINE_H
#define MACHINE_H

#define BLCKSZ	8192

#endif

