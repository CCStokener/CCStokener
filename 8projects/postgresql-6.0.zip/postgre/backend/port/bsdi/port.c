/*-------------------------------------------------------------------------
 *
 * port.c--
 *    Linux-specific routines
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 *
 * IDENTIFICATION
 *    /usr/local/devel/pglite/cvs/src/backend/port/linux/port.c,v 1.1.1.1 1994/11/07 05:19:38 andrew Exp
 *
 *-------------------------------------------------------------------------
 */
