/*-------------------------------------------------------------------------
 *
 * item.h--
 *    POSTGRES disk item definitions.
 *
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 * $Id: item.h,v 1.2 1996/10/31 09:49:49 scrappy Exp $
 *
 *-------------------------------------------------------------------------
 */
#ifndef	ITEM_H
#define ITEM_H

typedef Pointer	Item;

#endif	/* ITEM_H */
