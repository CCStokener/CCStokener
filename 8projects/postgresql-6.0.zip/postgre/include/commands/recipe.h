/*-------------------------------------------------------------------------
 *
 * recipe.h--
 *    recipe handling routines
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 * $Id: recipe.h,v 1.1 1996/08/28 07:21:50 scrappy Exp $
 *
 *-------------------------------------------------------------------------
 */
#ifndef RECIPE_H
#define RECIPE_H

extern void beginRecipe(RecipeStmt* stmt);

#endif /* RECIPE_H */
