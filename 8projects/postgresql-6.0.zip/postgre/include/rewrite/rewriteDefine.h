/*-------------------------------------------------------------------------
 *
 * rewriteDefine.h--
 *    
 *
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 * $Id: rewriteDefine.h,v 1.1 1996/08/28 07:24:06 scrappy Exp $
 *
 *-------------------------------------------------------------------------
 */
#ifndef	REWRITEDEFINE_H
#define	REWRITEDEFINE_H

extern void DefineQueryRewrite(RuleStmt *args); 

#endif	/* REWRITEDEFINE_H */
