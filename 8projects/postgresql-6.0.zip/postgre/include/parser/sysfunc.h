/*-------------------------------------------------------------------------
 * 
 * sysfunc.h--
 *    support for system functions
 * 
 * -------------------------------------------------------------------------
 */

extern	char	*SystemFunctionHandler(char *funct);

